using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace SignalRWebPack.ShapeHubs
{
    public class ShapeHub : Hub
    {
        public async Task MoveShape(int x , int y)
        {
            await Clients.All.SendAsync("shapeMoved", x, y);
        }
    }
}