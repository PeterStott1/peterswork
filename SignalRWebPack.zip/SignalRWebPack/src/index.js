"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./css/main.css");
var signalR = require("@microsoft/signalr");
var divMessages = document.querySelector("#divMessages");
var tbMessage = document.querySelector("#tbMessage");
var btnSend = document.querySelector("#btnSend");
var divShape = document.querySelector("#divShape");
var username = new Date().getTime();
//chat stuff
var connection = new signalR.HubConnectionBuilder()
    .withUrl("/Hub")
    .build();
connection.on("messageReceived", function (username, message) {
    var m = document.createElement("div");
    m.innerHTML =
        "<div class=\"message-author\">" + username + "</div><div>" + message + "</div>";
    divMessages.appendChild(m);
    divMessages.scrollTop = divMessages.scrollHeight;
});
connection.start().catch(function (err) { return document.write(err); });
tbMessage.addEventListener("keyup", function (e) {
    if (e.key === "Enter") {
        send();
    }
});
btnSend.addEventListener("click", send);
function send() {
    connection.send("newMessage", username, tbMessage.value)
        .then(function () { return tbMessage.value = ""; });
}
//move shape stuff
var shapeconnection = new signalR.HubConnectionBuilder()
    .withUrl("/ShapeHub")
    .build();
shapeconnection.on('shapeMoved', function (x, y) {
    var div = document.getElementById('divShape');
    div.style.position = "absolute";
    div.style.top = x.toString() + "px";
    div.style.left = y.toString() + "px";
});
shapeconnection.start().catch(function (err) { return document.write(err); });
divShape.addEventListener("mousedown", function (e) {
    // console.log(e.pageX);
});
divShape.addEventListener("dragend", function (e) {
    console.log("dragend");
    console.log(e);
    shapeconnection.send("MoveShape", e.screenX, e.screenY);
});
divShape.addEventListener("click", function (e) {
    moveBy();
});
function moveBy() {
    console.log("hello");
}
