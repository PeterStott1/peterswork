import "./css/main.css";
import * as signalR from "@microsoft/signalr";



const divMessages: HTMLDivElement = document.querySelector("#divMessages");
const tbMessage: HTMLInputElement = document.querySelector("#tbMessage");
const btnSend: HTMLButtonElement = document.querySelector("#btnSend");
const divShape: HTMLDivElement = document.querySelector("#divShape");
const username = new Date().getTime();

//chat stuff
const connection = new signalR.HubConnectionBuilder()
    .withUrl("/Hub")
    .build();

connection.on("messageReceived", (username: string, message: string) => {
    let m = document.createElement("div");

    m.innerHTML =
        `<div class="message-author">${username}</div><div>${message}</div>`;

    divMessages.appendChild(m);
    divMessages.scrollTop = divMessages.scrollHeight;
});

connection.start().catch(err => document.write(err));

tbMessage.addEventListener("keyup", (e: KeyboardEvent) => {
    if (e.key === "Enter") {
        send();
    }
});

btnSend.addEventListener("click", send);

function send() {
    connection.send("newMessage", username, tbMessage.value)
    .then(() => tbMessage.value = "");
}
//move shape stuff
const shapeconnection = new signalR.HubConnectionBuilder()
    .withUrl("/ShapeHub")
    .build();

shapeconnection.on('shapeMoved', (x: number, y: number) => {
    var div = document.getElementById('divShape');
    div.style.position = "absolute";
    div.style.top = x.toString() +"px";
    div.style.left = y.toString()+"px";
});
shapeconnection.start().catch(err => document.write(err));
divShape.addEventListener("mousedown", (e: DragEvent)=> {
   // console.log(e.pageX);
})
divShape.addEventListener("dragend", (e: DragEvent)=>{

    console.log("dragend");
    console.log(e);
    shapeconnection.send("MoveShape",  e.screenX, e.screenY);
});
divShape.addEventListener("click", (e: MouseEvent) => {
    moveBy();
});

function moveBy() {

    console.log("hello");
   
}
