<?php
//@@return include the xajax library class
require_once("xajax.inc.php");


//@@return instatiate the object for  use
$xajax = new xajax();

//@@return register the function with the xajax object without this it will not be registered as a function for xajax
$xajax->registerFunction("nextMonth");
$xajax->registerFunction("PrevMonth");
//@@this can be any function you like as long as it is registered 
function nextMonth()
{
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	$recordId .= "<form action=\"get\" method=Get>";
	$recordId .= "<P>hello julian</p>";
	$recordId .= "</form>";
	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}


function PrevMonth()
{

	//@@now add it to the display string &
	// put it into a variable like $recordId
	
	
	$recordId .= "<table border=1>";
	$recordId .= "<tr>";
	$recordId .= "<td>you da man</td>";
	$recordId .= "</tr>";
	$recordId .= "</table >";
	
	
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response

	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@return process the request
$xajax->processRequests();

?>
<html>
<head>
<?php 

//@@Also add the Xajax subdirectory name as an argument if you have the Xajax files, etc. within a subdirectory
$xajax->printJavascript(); 

?>
</head>
<body>
<!--this is the elemnet id that will be used to show the results//-->
<div id="showRec">To begin to select a letter can you please click on the button provide and select a property to asociate with the letter.....
<form action="get">
<button type="button" name="Submit" value="Refresh" onclick="xajax_nextMonth()"></button>
<button type="button" name="Submit" value="Refresh" onclick="xajax_PrevMonth()"></button>
</form>


</div>

</body>
