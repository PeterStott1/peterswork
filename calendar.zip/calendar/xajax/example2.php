<?php
//@@return include the xajax library class
require_once("xajax.inc.php");


//@@return instatiate the object for  use
$xajax = new xajax();

//@@return register the function with the xajax object without this it will not be registered as a function for xajax
$xajax->registerFunction("MyFunction");
//@@this can be any function you like as long as it is registered 
function MyFunction($arg)
{
	// do some stuff based on $arg like query data from a database and
	$dbconnect = mysql_connect('192.168.13.240','root','letmein');
    mysql_select_db('ep3dev');
	$query = "select * from ven_property_info where property_id =".$arg;
	//results set here
    $result = mysql_query($query,$dbconnect);
	//@@return while loop results
	while($row = mysql_fetch_assoc($result))
	{
		$prop_id = $row['property_id'];
		$branch_id = $row['branch_id'];
	}
	//@@now add it to the display string &
	// put it into a variable like $recordId
	$recordId .= "the Value of the property_id is:".$prop_id;
	$recordId .= "the branch id is:".$branch_id;
	//xajax requires this to send a response to the function call you must always use this response object or will not get a response
	// Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	// add a command to the response to assign the innerHTML attribute of
    // the element with id="SomeElementId" to whatever the new content is
	//showRec is a function within  
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@return process the request
$xajax->processRequests();

?>
<html>
<head>
<?php 

// Also add the Xajax subdirectory name as an argument if you have the Xajax files, etc. within a subdirectory
$xajax->printJavascript(); 

?>
</head>
<body>
<!--this is the elemnet id that will be used to show the results//-->
<div id="showRec">this will be replaced when the onclick function is accessed by the user..... </div>
<form action="get">
<button type="button" value="Refresh" onclick="xajax_MyFunction('10');">
</form>
</body>
