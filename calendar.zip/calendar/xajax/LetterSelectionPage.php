<?php
//@@return include the xajax library class
require("xajax.inc.php");
require_once('../newclasses/XMLBUilder/mysqlclass.php');
require_once('../newclasses/XMLBUilder/DataAccess.class.php');
require_once('../newclasses/XMLBUilder/WorkOrderDescriptor.class.php');
require_once('../newclasses/XMLBUilder/TriggerEngine.class.php');
require_once('../newclasses/Config.class.php');

//@@return instatiate the object for  use
$xajax = new xajax();

//@@return register the function with the xajax object without this it will not be registered as a function for xajax
$xajax->registerFunction("SelectProperty");
$xajax->registerFunction("GetFirstValues");
$xajax->registerFunction("RecipientCollection");
$xajax->registerFunction("RecipientSolicitorCollection");
$xajax->registerFunction("FinalStep");



//@@this can be any function you like as long as it is registered 
//@@step1
function SelectProperty()
{
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	$recordId .= "select a property for the letter to be asiciated with";
	$recordId .= "<form action=\"get\" method=Get>";
	$recordId .= "<select name=\"cmbdata\" size=\"1\" class=\"box-large\" id=\"cmbdata\" onChange=\"xajax_GetFirstValues(this.value);\" style=\"width:100%;\">";
    $recordId .= "<option value=\"n/a\" selected=\"selected\">-------------</option>";        
			   //@@first internal soap call for collection of data
				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
					$return = $client->__soapCall("getAllPropDetails",array());
				 	//print_r($return);
					$return_array =explode("\n",$return);
					$arrayLength = count($return_array);
					for($i = 1; $i <= $arrayLength; $i++)
					{
						$recordId .= "<option value=\"$i\">";
						$recordId .= $return_array[$i];
						$recordId .= "</option>\n\r";
					}								
	$recordId .= "</select>";
	$recordId .= "</form>";
	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();
	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@step2
function GetFirstValues($arg)
{
	//@@now add it to the display string &
	// put it into a variable like $recordId
	//$recordId .= "the Value of the property_id is :".$arg."\n<br>";
	$dbconnect = mysql_connect('192.168.13.240','root','letmein');
    mysql_select_db('ep3dev');
	$query = "select * from ven_property_info where property_id =".$arg;
	//results set here
    $result = mysql_query($query,$dbconnect);
	//@@return while loop results
	while($row = mysql_fetch_assoc($result))
	{
		$prop_id = $row['property_id'];
		$branch_id = $row['branch_id'];
		$vendorno = $row['vendorno'];
	}
	//@@now add it to the display string &
	//@@put it into a variable like $recordId
//	$recordId .= "the Value of the property_id is:".$prop_id."\n<br>";
//	$recordId .= "the branch id is:".$branch_id."\n<br>";
//	$recordId .= "the vendor number is:".$vendorno."\n<br>";
	$recordId .= "now select the recipient for the letter to go to";
	$recordId .= "<form id=\"form1\" name=\"form1\" action=\"get\">";
	$recordId .= "<input id=\"applicant\" name=\"checkbox[]\" type=\"checkbox\" value=\"applicant\" >";
	$recordId .= "<label for=\"applicant\">applicant</label>";
	$recordId .= "<input id=\"Vendor\" name=\"checkbox[]\" type=\"checkbox\" value=\"Vendor\">";
	$recordId .= "<label for=\"Vendor\">Vendor</label>";
	$recordId .= "<input type=\"hidden\" value=\"$vendorno\" name=\"VendorNumber\">";
	$recordId .= "<input type=\"hidden\" value=\"$prop_id\" name=\"PropertyNumber\">";
	$recordId .= "<input type=\"hidden\" value=\"$branch_id\" name=\"BranchNumber\">";
	$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_RecipientCollection(xajax.getFormValues('form1'));\"></button>";
	$recordId .= "</form>";

	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	//@@Instantiate the xajaxResponse object
		$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
		$objResponse->addAssign("showRec","innerHTML",$recordId);
	
	//@@return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}

//@@second process to collect the recipient without solicitors
//@@step three
function RecipientCollection($aFormValues)
{
	
	$prop_id = $aFormValues['PropertyNumber'];
	$branch_id = $aFormValues['BranchNumber'];
	$vendorno = $aFormValues['VendorNumber'];
//	$recordId .= print_r($aFormValues);
	$recordId .= "now select the applicant";

	
			if($aFormValues['checkbox'][0]=='applicant')
				{
					$recordId .= "<form id=\"form2\" name=\"form2\" action=\"get\" method=Get>";
					$recordId .= "<select name=\"cmbdata\" size=\"1\" class=\"box-large\" id=\"cmbdata\" style=\"width:50%;\">";
			    	$recordId .= "<option value=\"n/a\" selected=\"selected\">-------------</option>";        
						   //@@first internal soap call for collection of data
							$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
								$return = $client->__soapCall("GetApplicant",array());
							 	//print_r($return);
								$return_array =explode("\n",$return);
								$arrayLength = count($return_array);
								for($i = 1; $i <= $arrayLength; $i++)
								{
									$intAId=explode("/", $return_array[$i]);
									$recordId .= "<option value=\"$intAId[0]\">";
									$recordId .=	$return_array[$i];
									$recordId .= "</option>\n\r<br>";
								}								
					$recordId .= "</select>";
					$recordId .= "<input type=\"hidden\" value=\"$vendorno\" name=\"VendorNumber\">";
					$recordId .= "<input type=\"hidden\" value=\"$prop_id\" name=\"PropertyNumber\">";
					$recordId .= "<input type=\"hidden\" value=\"$branch_id\" name=\"BranchNumber\">";
					$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_RecipientSolicitorCollection(xajax.getFormValues('form2'));\"></button>";
					$recordId .= "</form>";
									
				}
				//@@return if the aplicant slicitor is required then 
				//@@collect the applicant solocitor based on the applicant number if no applecant nnumber exists then
				//@@collect all the applicant solcitor list for selection
				
				else if($aFormValues['checkbox'][1]=='Vendor')
				{
					$recordId .= "<form id=\"form2\" name=\"form2\" action=\"get\" method=Get>";
					$intId = $aFormValues['VendorNumber'];
					$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
					$return = $client->__soapCall("GetVendor",array($intId));
					$temp = explode("/", $return);
					//$recordId .= $temp[0];
					$recordId .= "<br>This is the vendor that you have selected for the letter to go to".$temp[1]."<br>";
					$recordId .= "<input type=\"hidden\" value=\"$vendorno\" name=\"VendorNumber\">";
					$recordId .= "<input type=\"hidden\" value=\"$prop_id\" name=\"PropertyNumber\">";
					$recordId .= "<input type=\"hidden\" value=\"$branch_id\" name=\"BranchNumber\">";
					$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_RecipientSolicitorCollection(xajax.getFormValues('form2'));\"></button>";
					$recordId .= "</form>";
				}
				else if(($aFormValues['checkbox'][0]=='applicant')&&($aFormValues['checkbox'][1]=='Vendor'))
				{
					$intId = $aFormValues['VendorNumber'];
					$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
					$return = $client->__soapCall("GetVendor",array($intId));
					$temp = explode("/", $return);
					//$recordId .= $temp[0];
					$recordId .= "<br>This is the vendor that you have selected for the letter to go to".$temp[1]."<br>";
					$recordId .= "<form id=\"form2\" name=\"form2\" action=\"get\" method=Get>";
					$recordId .= "<select name=\"cmbdata\" size=\"1\" class=\"box-large\" id=\"cmbdata\" style=\"width:50%;\">";
			    	$recordId .= "<option value=\"n/a\" selected=\"selected\">-------------</option>";        
						   //@@first internal soap call for collection of data
							$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
								$return = $client->__soapCall("GetApplicant",array());
							 	//print_r($return);
								$return_array =explode("\n",$return);
								$arrayLength = count($return_array);
								for($i = 1; $i <= $arrayLength; $i++)
								{
									$intAId=explode("/", $return_array[$i]);
									$recordId .= "<option value=\"$intAId[0]\">$return_array[$i]</option>\n\r<br>";
									
								}								
					$recordId .= "</select>";
					$recordId .= "<input type=\"hidden\" value=\"$vendorno\" name=\"VendorNumber\">";
					$recordId .= "<input type=\"hidden\" value=\"$prop_id\" name=\"PropertyNumber\">";
					$recordId .= "<input type=\"hidden\" value=\"$branch_id\" name=\"BranchNumber\">";
					$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_RecipientSolicitorCollection(xajax.getFormValues('form2'));\"></button>";
					$recordId .= "</form>";
					
					
				}
	
	$recordId .= "the applicant number should be posted with the form information to the next process step";
	
	
	$objResponse = new xajaxResponse();
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);

	return $objResponse;
}
//@@third process to collect the solicitors
//@@step 4
function RecipientSolicitorCollection($bFormValues)
 {
 	
 	$prop_id = $bFormValues['PropertyNumber'];
	$branch_id = $bFormValues['BranchNumber'];
	$vendorno = $bFormValues['VendorNumber'];
	$applicantno = $bFormValues['cmbdata'];
 
 	$recordId .= "this is the final process selection for the letter recipient";
 	$recordId .= "<form id=\"form3\"  name=\"form3\" action=\"get\">";
 	$recordId .= "<input id=\"applicantSol\" name=\"checkbox[]\" type=\"checkbox\" value=\"applicantSol\">";
	$recordId .= "<label for=\"applicantSol\">applicant Solicitor</label>";
	$recordId .= "<input id=\"VendorSol\" name=\"checkbox[]\" type=\"checkbox\" value=\"VendorSol\">";
	$recordId .= "<label for=\"VendorSol\">Vendor Solicitor</label>";
	$recordId .= "<input type=\"hidden\" value=\"$vendorno\" name=\"VendorNumber\">";
	$recordId .= "<input type=\"hidden\" value=\"$prop_id\" name=\"PropertyNumber\">";
	$recordId .= "<input type=\"hidden\" value=\"$branch_id\" name=\"BranchNumber\">";
	$recordId .= "<input type=\"hidden\" value=\"$applicantno\" name=\"ApplicantNumber\">";
	$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_FinalStep(xajax.getFormValues('form3'));\"></button>";
	$recordId .= "</form>";

 	
 	$objResponse = new xajaxResponse();
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	//$objResponse->addAlert("inputData: " . print_r($bFormValues, true));

	
	return $objResponse;
	
	
	
 }
 
 //@step 5
function FinalStep($cFormValues)
{
	$prop_id = $cFormValues['PropertyNumber'];
	$branch_id = $cFormValues['BranchNumber'];
	$vendorno = $cFormValues['VendorNumber'];
	$applicantno = $cFormValues['ApplicantNumber'];
	
	//$recordId .= "the vendor nnumber is :".$vendorno."the branch number is: ".$branch_id."the proeprty number is :".$prop_id."the applicant number is :".$applicantno;
	
	$db=Config::CreateDbConn();	
		//$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3dev'));
		$TestDataAccess = new DataAccess($db);
		
		$TestWorkOrderDescriptor = new WorkOrderDescriptor();
		
		$TestWorkOrderDescriptor->strPropertyId = "10";
		$TestWorkOrderDescriptor->strBranchId = "";
		$TestWorkOrderDescriptor->strUserId = "";
		$TestWorkOrderDescriptor->strApplicantId ="";
		$TestWorkOrderDescriptor->strApplicantSolicitorId = "";
		$TestWorkOrderDescriptor->strVendorId = "";
		$TestWorkOrderDescriptor->strVendorSolicitorId = "";
		$TestWorkOrderDescriptor->boolWorkOrderLive = true;
		$TestWorkOrderDescriptor->strTemplate = "";
		$TestWorkOrderDescriptor->boolIncludeRooms = false;
		$TestWorkOrderDescriptor->strDocType="Letter";

		$TestTrigger = new TriggerEngine($TestDataAccess);
		$workOrderId = $TestTrigger->getTriggerID($TestWorkOrderDescriptor);
		$recordId .= "<a href=../newclasses/site/wplugin_initiator.php?triggerId='".$workOrderId."'>Click here</a>";	
	$objResponse = new xajaxResponse();
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	//$objResponse->addAlert("inputData: " . print_r($cFormValues, true));

	
	return $objResponse;
	
	
}
//@@return process the request
$xajax->processRequests();

?>
<html>
<head>
<?php 
//@@Also add the Xajax subdirectory name as an argument if you have the Xajax files, etc. within a subdirectory
$xajax->printJavascript(); 
?>
</head>
<body>
<!--this is the elemnet id that will be used to show the results//-->
<div id="showRec">To begin to select a letter can you please click on the button provide and select a property to asociate with the letter.....</div>

<form action="get">
<button type="button" name="Submit" value="Refresh" onclick="xajax_SelectProperty()"></button>
</form>
</body>
