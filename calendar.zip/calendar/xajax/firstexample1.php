<?php
//@@return include the xajax library class
require_once("xajax.inc.php");


//@@return instatiate the object for  use
$xajax = new xajax();

//@@return register the function with the xajax object without this it will not be registered as a function for xajax
$xajax->registerFunction("MyFunction");
$xajax->registerFunction("NewFunction");
//@@this can be any function you like as long as it is registered 
function MyFunction()
{
	//@@do some stuff based on $arg like query data from a database and
//	$dbconnect = mysql_connect('192.168.13.240','root','letmein');
//    mysql_select_db('ep3dev');
//	$query = "select * from ven_property_info where property_id =".$arg;
//	//results set here
//    $result = mysql_query($query,$dbconnect);
//	//@@return while loop results
//	while($row = mysql_fetch_assoc($result))
//	{
//		$prop_id = $row['property_id'];
//		$branch_id = $row['branch_id'];
//	}
//	//@@now add it to the display string &
//	// put it into a variable like $recordId
//	$recordId .= "the Value of the property_id is:".$prop_id;
//	$recordId .= "the branch id is:".$branch_id;
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	
	$recordId .= "<form action=\"get\" method=Get>";
	$recordId .= "<select name=\"cmbdata\" size=\"20\" class=\"box-large\" id=\"cmbdata\" onChange=\"xajax_NewFunction(this.value);\" style=\"width:100%;\">";
              
			   //@@first internal soap call for collection of data
				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'    => 1 ));
		
					$return = $client->__soapCall("getAllPropDetails",array());
				 	//print_r($return);
					
					$return_array =explode("\n",$return);
					$arrayLength = count($return_array);
					for($i = 1; $i <= $arrayLength; $i++)
					{
						$recordId .= "<option value=\"$i\" selected=\"selected\">";
						$recordId .= $return_array[$i];
						$recordId .= "</option>\n\r";
						
					}						
						
	$recordId .= "</select>";
	$recordId .= "<button type=\"button\" name=\"Submit\" value=\"$i\" onClick=\"xajax_NewFunction()\"></button>";
	$recordId .= "</form>";
	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}


function NewFunction($arg)
{

	//@@now add it to the display string &
	// put it into a variable like $recordId
	$recordId .= "the Value of the property_id is :".$arg;
	
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	

	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@return process the request
$xajax->processRequests();

?>
<html>
<head>
<?php 

//@@Also add the Xajax subdirectory name as an argument if you have the Xajax files, etc. within a subdirectory
$xajax->printJavascript(); 

?>
</head>
<body>
<!--this is the elemnet id that will be used to show the results//-->
<div id="showRec">To begin to select a letter can you please click on the button provide and select a property to asociate with the letter.....</div>
<form action="get">

<!--<?
//echo "<select name=\"cmbdata\" size=\"20\" class=\"box-large\" id=\"cmbdata\" onChange=\"fncforUpdate(this);\" style=\"width:100%;\">";
//              
//			   //@@first internal soap call for collection of data
//				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'    => 1 ));
//		
//					$return = $client->__soapCall("getAllPropDetails",array());
//				 	print_r($return);
//					
//					$return_array =explode("\n",$return);
//					$arrayLength = count($return_array);
//					for($i = 1; $i <= $arrayLength; $i++)
//					{
//						
//						echo "<option value=\"$return_array[$i]\" selected>\n\r";
//						echo $return_array[$i];
//						echo "</option>\n\r";
//						
//					}						
				
				
echo "</select>";
?>-->
<button type="button" name="Submit" value="Refresh" onclick="xajax_MyFunction()"></button>
</form>
</body>
