<?php
// Called via an xajax request - other-upload.
// Allows the user to modify the room names, by displaying a drop down list box, with a list of the rooms.
// When the room name is selected from the list box, the database will be updated !.

function updateRoomName($picTxtDiv, $newRoomName, $imgIdIn)
{
	header("pragma: no-cache");
	include("incConnection.php");
	// Update the text for the image.
	$query = "UPDATE prop_gen_photo SET imgname = \"".$newRoomName."\" WHERE gpr_id = ".$imgIdIn;
	mysql_query($query);
    $objResponse = new xajaxResponse();
	$objResponse->addAssign($picTxtDiv,"innerHTML", "<span onClick=\"xajax_showRoomList('".$picTxtDiv."', ".$imgIdIn.");\" title=\"Click to change room name\" >".$newRoomName."</span>");
	// Now check if the floorplans order button should be enabled.
	// First get the property ID for the current image.
	$query = "SELECT prop_id FROM prop_gen_photo WHERE gpr_id = ".$imgIdIn;
	$result = mysql_query($query);
	$a_row = mysql_fetch_assoc($result);
	// Now check to see if any of the images for the property have the default "unknown" text.
	$query = "SELECT COUNT(*) AS count FROM prop_gen_photo WHERE imgname LIKE \"unknown\" AND prop_id = ".$a_row['prop_id'];
	$result = mysql_query($query);
	$a_row = mysql_fetch_assoc($result);
	if ($a_row['count'] == 0)
	{
		// Floor plans button enabled.
		$orderButton = "<a href=\"#p16\" class=\"brown-btn\" style=\"{cursor:pointer}\" title=\"Click to order floor plan\">Order FloorPlans</a>";
	}
	else
	{
		// Floor plans order button disabled.
		$orderButton = "<a href=\"#p16\" class=\"brown-btn\" style=\"{cursor:default}\" title=\"Ordering disabled as not all image names have been updated\"><i>Order FloorPlans</i></a>";
	}
	$objResponse->addAssign("orderfp", "innerHTML", $orderButton);
	return $objResponse;
}

function showRoomList($picTxtDiv, $imgId)
{
	header("pragma: no-cache");
	include("incConnection.php");
	$objResponse = new xajaxResponse();
	$query = "SELECT r_id, roomname FROM lib_room ORDER BY roomname ASC";
	$result = mysql_query($query);
	$rows = mysql_num_rows($result);
	$selectBoxHtml = "<select name=\"select_".$picTxtDiv."\" class=\"box\" onChange=\"xajax_updateRoomName('".$picTxtDiv."', this.value, ".$imgId.");\">";
	while ($a_row = mysql_fetch_assoc($result))
	{
		$selectBoxHtml = $selectBoxHtml."<option value=\"".$a_row['roomname']."\">".$a_row['roomname']."</option>";
	}
	$selectBoxHtml = $selectBoxHtml."</select>";
	//$selectBoxHtml = "Helloworld";
	$objResponse->addAssign($picTxtDiv, "innerHTML", $selectBoxHtml);
	return $objResponse;
}
?>