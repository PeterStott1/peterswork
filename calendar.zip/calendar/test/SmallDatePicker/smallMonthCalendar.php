<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
    <title>Rent before you buy</title>
    
</head>

<style>
	body
	{
		padding: 0px;
		margin: 0px;
		text-align: center;
		color: white;
		
	}
	div#page_container
	{
		margin-left: auto;
		margin-right: auto;
		
	}
	td
	{
		font-weight: bold;
		border: solid white 1px;
	}
	p
	{
		padding: 0px;
		margin: 0px;
	}
	table#calendar
	{
		width: 70%;
		height: 600px;
		
		background-color: #5CC1FC;
	}
	

</style>













<body>
<div id="page_container">
<?php

//if no $_GET value is present we default to the current month and year
if(!isset($_GET['action']))
{
$_SESSION['month'] = date("n");
$_SESSION['year'] = date("Y");
$month = $_SESSION['month'];
$year = $_SESSION['year'];
}

//if the forward link is clicked and it's December..month must become January and year must increase by 1
if(($_GET['action'] == "fwd") and ($_SESSION['month'] == 12))
 {
   $_SESSION['month'] = 1;
   $_SESSION['year'] = $_SESSION['year'] + 1;
   $month = $_SESSION['month'];
   $year = $_SESSION['year'];
 }

//if the forward link is clicked and it's not Decmeber the month just increases by 1 and the year stays the same
else if(($_GET['action'] == "fwd") and ($_SESSION['month'] !== 12))
 {
   $_SESSION['month'] = $_SESSION['month'] + 1;
   $month = $_SESSION['month'];
   $year = $_SESSION['year'];
 } 
 
 //if the back link is clicked and it's January the month becomes December and the year decreases by 1
if(($_GET['action'] == "bck") and ($_SESSION['month'] == 1))
 {
   $_SESSION['month'] = 12;
   $_SESSION['year'] = $_SESSION['year'] - 1;
   $month = $_SESSION['month'];
   $year = $_SESSION['year'];
 }

//if the back link is cliced and it's not January the month decreases by 1 and the year stays the same
else if(($_GET['action'] == "bck") and ($_SESSION['month'] !== 1))
 {
   $_SESSION['month'] = $_SESSION['month'] - 1;
   $month = $_SESSION['month'];
   $year = $_SESSION['year'];
 }

$firstDayNumber = date("w",mktime(0,0,0,$month,1,$year));
$numberOfDays = date("t",mktime(0,0,0,$month,1,$year));
$lastDayNumber = date('w', mktime(0,0,0,$month+1,0,$year)); 
$theMonth = date("M",mktime(0,0,0,$month,1,$year));
$count=0;
$number = 7 - $firstDayNumber;
$lastnumber = (7 - $lastDayNumber)- 1;

$theMonths = array("dummy","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");

?>

<table border="0" cellspacing="0" cellpadding="5" id="calendar">
<tr>
<td class="top"><b><a href="smallMonthCalendar.php?action=bck">&lt;</a></b></td>
<td align="center" colspan="5" class="top"><?php echo $theMonths[$month] ." " . $year; ?></td>
<td class="top"><b><a href="smallMonthCalendar.php?action=fwd">&gt;</a></b></td>
</tr>
 <tr>
  <td><b>Sunday</b></td>
  <td><b>Monday</b></td>
  <td><b>Tuesday</b></td>
  <td><b>Wednesday</b></td>
  <td><b>Thursday</b></td>
  <td><b>Friday</b></td>
  <td><b>Saturday</b></td>
 </tr>
 <tr>
 
<?php
//writing out the blank cells before the 1st day of the month
for($i=0; $i < $firstDayNumber; $i++)
{
  echo "<td>&nbsp;</td>";
}

//writing the first few days of the month after the blank cells and before the end of the table row
for($j=1; $j < $numberOfDays; $j++)  
  {
  $count++;
  echo "<td>$j</td>";
  if($count + $firstDayNumber ==7)
     {
       echo "</tr>";
       break;
     }     
  }
 
 //writing out the rows that contain the remaining days of the month
 echo "<tr>"; 
 $new_count = 1;
  for($k=$number +1; $k < $numberOfDays +1 ; $k++) 
  { 
   $new_count++;
   echo "<td>$k</td>";
   if($new_count == 8)
     {
       echo "</tr>";
       $new_count=0;
       $new_count++;
       echo "<tr>";
     }
        
     
   } 
 
//writing out the blank cells that appear after the last of the month   
   for($l=0; $l < $lastnumber; $l++)   
   {
     echo "<td>&nbsp;</td>";
   }     


?>  

  </tr>
</table>

</div>
</body>
</html>
