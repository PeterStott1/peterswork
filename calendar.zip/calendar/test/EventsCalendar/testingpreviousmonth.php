<?

require_once('Calendar.class.php');
$cal = new Calendar();

$cal->setMonth($latestmonth);
$cal->setDay('28');
$cal->setYear('2007');
echo $month = $cal->getMonth()."<br>\n";
echo $year = $cal->getYear()."<br>\n";
echo $day = $cal->getDay()."<br>\n";

//
//
//get the previous month should be 10 oct
$currentMonth =  $cal->fnPreviousMonth($month,$year);
echo "current month is:".$currentMonth."<br>\n";
 $num = $cal->fnGetNumberOfWeeksInMonth($currentMonth)."<br>\n";
 echo"the number of weeks is:".$num."<br>\n";
echo count($cal->fnGetTotalLengthOfDayArray()). "<br>\n";

echo $cal->fnGetTotalDaysInCurrentMonth()."<br>\n";



$cal->fnGetStartDayOfCurrentMonth($month,$year);
echo $aryweek = $cal->fnBuildDays($currentMonth,$year);

//*
//
//so now the cuurent month is oct 10 so the result should be 11 nov
//$currentMonth =  $cal->fnNextMonth($currentMonth,$year);
// "current month is:".$currentMonth."<br>\n";
// $num = $cal->fnGetNumberOfWeeksInMonth($currentMonth)."<br>\n";
// "the number of weeks is:".$num."<br>\n";
//echo $aryweek1 = $cal->fnGetTotalLengthOfDayArray($currentMonth,$year);
// "<br>";
// $cal->fnGetStartDayOfCurrentMonth($month,$year);
//echo $aryweek = $cal->fnBuildDays($currentMonth,$year);
?>