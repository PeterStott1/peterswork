<?
define ( "HOSTNAME","localhost");
define ( "DATABASE","diarydb");
define ( "USERNAME","root");
define ( "PASSWORD","");
require_once("../../general_classes/dbConnection.class.php");
class ConfigurationClass
{
	
	public static function CreateDbConn()
	{	
		$db=new Connection();
		return $db;
	}
	
	
	
	
	
	
}


?>