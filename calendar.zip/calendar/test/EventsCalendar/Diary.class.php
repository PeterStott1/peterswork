<?
require_once("baseCalendar.class.php");
require_once("DiaryAccess.class.php");
require_once('ConfigurationClass.class.php');

class Diary extends baseCalendar 
{
	public $tmTime;
	public $Conn;
	public $arrEventsForCurrentDay = array();
	public $DiaryAcc;

	public function __construct($db)
	{
		$this->Conn = $db;
		$this->DiaryAcc = new DiaryAccess($this->Conn);	
	}

	
	
	//@@collect the current day month year
	public function fnAddEvent($eventSubject, $eventDescription, $dateTime)
	{
		$this->DiaryAcc->fnAddAnEvent($eventSubject, $eventDescription, $dateTime);
	}
	
	
	public function fnUpdateEvent($id, $eventDescription, $eventSubject,$dateTime)
	{
		$this->DiaryAcc->fnUpdateAnEvent($id, $eventSubject, $eventDescription, $dateTime);
	}
	

	
	
	
	
	// get day events for the given view.
	public function fnGetDayEvents($startOfDay, $endOfDay)
	{
		$this->intMonth = $intMonth;
		$this->intYear = $intYear;
		$this->intDay = $intDay;
		$arrDaysEvents = array();
		$arrDaysEvents = $this->DiaryAcc->getArrayOfEventsForDay($startOfDay, $endOfDay);
		return $arrDaysEvents;
	}
	
	
	
	
	
	
	public function fnRemoveEvent($id)
	{
		//needs to delete the event
		$this->DiaryAcc->fnRemoveAnEvent($id);
	}
	
}
?>