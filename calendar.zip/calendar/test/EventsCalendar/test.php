<?php 

	for ($i = 0; $i < 8; $i++)
	{
	 $display_time = $i;
		if ($eighthour)
		{
			if ($i == 0)
				$display_time = '9 am'.$disp_zone;
			else
			{
				if ($i < 9)
					$display_time .= ' am'.$disp_zone;
				else
				{
					if ($i == 12)
						$display_time .= ' pm'.$disp_zone;
					else
						 $display_time = ($i - 8).' pm'.$disp_zone;
				}
			}
		}
	}
	
	
	echo $disp_zone;
	?>