<?
include("../../xajax/dbConnection.class.php");
include('Calendar.class.php');

$cal = new Calendar();

$intDay = date('j');
$intMonth = 12;
$intYear = 2007;


$diaryDataAccess = new Connection('localhost','root','','diarydb');
		
		
		
		//$diaryDataAccess->execute("select * from tbl_Events where DateTime >= '. $startofday .' and DateTime <= '. $endofday .'");
		$diaryDataAccess->execute("select * from tbl_Events");
		$new = $diaryDataAccess->fetchArray($diaryDataAccess);
		echo count($new);
		
		
		
		
		
		
		
		
		
		//$diaryDataAccess->execute("select * from tbl_events");
//		while($newone = $diaryDataAccess->fetchArray())
//		{
//			$date .= $newone['Events_Subject'];
//		}
//		echo $date;
		
?>