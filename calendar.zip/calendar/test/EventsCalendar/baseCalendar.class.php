<?php

class baseCalendar 
{
	
	public $intDay;
	public $intMonth;
	public $intYear;
	public $intDaysInMonth;
	public $intMonthStartDay;
	
	//@@sets the number of days in the current month 
	public function fnSetTotalDaysInCurrentMonth() 
	{ 
		$this->intDaysInMonth = date("t", mktime(0,0,0,$this->intMonth,1,$this->intYear))-1;
	} 
	
	//@@sets the first day of the month
	public function fnSetStartDayOfCurrentMonth() 
	{			
		
		$this->intMonthStartDay = date("w", mktime(0,0,0,$this->intMonth,1,$this->intYear));
		if($this->intMonthStartDay == 0)
			{
		 		$this->intMonthStartDay = 7;
    	 	}
	}
	
	
	
	public function getDay()
	{
		return $this->intDay;
	}
	public function getMonth()
	{
		return $this->intMonth;
	}
	public function getYear()
	{
		return $this->intYear;
	}
	public function getDaysInMonth()
	{
		return $this->intDaysInMonth;
	}
	public function getMonthStartDay()
	{
		return $this->intMonthStartDay;	
	}
		
	public function setDay($name)
	{
		$this->intDay = $name;
	}
	public function setMonth($name)
	{
		$this->intMonth = $name;
	}
	public function setYear($name)
	{
		$this->intYear = $name;
	}
	
	//@@sets the month to the previous month
	public function fnSetPreviousMonth()
		{
			
			if($this->intMonth == 1)
			{
				$this->intMonth = 12;
				
			}
			else
			{
				$this->intMonth--;
			}
			return $this->intMonth;
		}	
	//@@sets the month to the next month	
	public function fnSetNextMonth()
	{	//$this->intMonth = $name;
		if($this->intMonth == 12)
		{
			$this->intMonth = 1;
			
		}
		else
		{
			$this->intMonth++;
		}
		return $this->intMonth;
	} 
	public function fnNextYear()
	{
			if($this->intMonth==1)
			{
				$this->intYear++;
				return $this->intYear;
			}
			else
			{
				return $this->intYear;
			}
			
	
			
		
		
		
	}
	public function fnPreviousYear()
	{
			if($this->intMonth==12)
			{
				$this->intYear--;
				return $this->intYear;
			}
			else
			{
				return $this->intYear;
			}
	}
	
}
?>