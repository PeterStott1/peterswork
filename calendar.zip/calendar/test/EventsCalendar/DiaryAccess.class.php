<?
include_once('ConfigurationClass.class.php');

class DiaryAccess  
{
	public $DbConn;
	
	public function __construct($DbConn)
	{
		//@@in here is where we connect to the database
		//@@so we willl need to build this with host 
		//@@user and pasword as well as the database to connect to
		$this->DbConn = $DbConn;
	}
	
	public function fnAddAnEvent($eventDescription, $eventSubject, $dateTime)
	{
		$result = $this->DbConn->execute
		("INSERT INTO tbl_events (Events_id, Events_Subject, Events_Description, DateTime) VALUES ('', '".$eventSubject."','".$eventDescription."', '".$dateTime."')");
		return $result;
	}

	public function fnRemoveAnEvent($id)
	{
		$result = $this->DbConn->execute("Delete from tbl_events where events_id =".$id);
		return $result;
	}

	public function fnUpdateAnEvent($id, $eventDescription, $eventSubject)
	{
		$result = $this->DbConn->execute("UPDATE tbl_events SET Events_Subject = '".$eventSubject."', Events_Description = '".$eventDescription."' WHERE Events_id = $id");  
		
	}	
		

	public function getArrayOfEventsForDay($startOfDay, $endOfDay)
	{
		$arrEvents = array();
		$arrDaysEvents = array();
		$this->DbConn->execute("select * from tbl_Events where DateTime >= '. $startofday .' and DateTime <= '. $endofday .'");
		while($arrEvents = $this->DbConn->fetchArray())
		{	
			$eventID = $arrEvents['Events_id'];
			$eventSubject = $arrEvents['Events_Subject'];
			$eventsDescription = $arrEvents['Events_Description'];
			$dateTime = $arrEvents['DateTime'];
			array_push($arrDaysEvents, $eventID, $eventSubject, $eventDescription,$dateTime);
		
		}
		return $arrDaysEvents;
	}
}
?>