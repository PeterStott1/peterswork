<?
require_once('../../general_classes/dbConnection.class.php');


function GetData()
{
			$db = new Connection('localhost','root','','diarydb');
			$db->execute('select * from tbl_events');
			
			while($newArray = $db->fetchArray())
			{
				
				$proertyId = $newArray['Events_id'];
				$name = $newArray['Events_Date/Time'];
				$resString = $name.",".$proertyId;
				
				
				
				
				
				
				
			}
			return $resString;
}

echo GetData();
?>