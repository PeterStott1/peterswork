<?php

//@@return include the xajax library class
require_once("../../xajax/xajax.inc.php");
require_once('Calendar.class.php');
require_once('Diary.class.php');
require_once('ConfigurationClass.class.php');
//@@return instatiate the object for  use
//$xajax = new xajax();

$xajax = new xajax();
//@@return registers the function with the xajax object without this it will not be registered as a function for xajax
$xajax->registerFunction("nextMonth");
$xajax->registerFunction("PrevMonth");
$xajax->registerFunction("viewEvent");
$xajax->registerFunction("addEventForm");
$xajax->registerFunction("addEvent");



//@@this can be any function you like as long as it is registered 
function nextMonth($aFormValues)
{
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	$month = $aFormValues['Month'];
	$year = $aFormValues['Year'];
	$cal = new Calendar();
	$cal->setMonth($month);
	$cal->setYear($year);
	$cal->fnSetNextMonth();
	$cal->fnNextYear();
	$cal->fnSetCalendarMonth();
	$cal->fnSetTotalDaysInCurrentMonth();
	$cal->fnSetStartDayOfCurrentMonth();
	$cal->fnSetCalendarMonth();
	
	
	$aryweek = $cal->getCalendarMonth();
	$arrayLength = count($aryweek);	
	$month = $cal->getMonth();
	$year = $cal->getYear();
	
	
	$recordId .= "<table border=\"1\">";
	$recordId .= "<tr>";
	$recordId .= "<td colspan=\"7\">";
	$recordId .= "<h1>";
	$recordId .= $year;
	$recordId .= "</h1>";
	$recordId .= "<form id=\"form1\" name=\"form1\" method=\"get\">";
	$recordId .= "<input type=\"input\" name=\"Month\" value='$month'>";
	$recordId .= "<input type=\"input\" name=\"Year\" value='$year'>";
	
	for($j=0;$j<$arrayLength;$j++) 
	{
		$recordId .= "<tr>\n";
		for($i=0;$i<7;$i++)
		 {				 
		 	$recordId .= "<td onclick=xajax_viewEvent('24hr')>";
			$num= $aryweek[$j][$i];
			$recordId .= $num;
			$recordId .= "</td>\n";		
		  }
		  $recordId .= "</tr>\n";
	}
	
	$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_PrevMonth(xajax.getFormValues('form1'));return(false);\"><<<<<<<prev<<<<<<<<</button>";
	$recordId .= "<button type=\"button\" name=\"Submit\"  value=\"Refresh\" onclick=\"xajax_nextMonth(xajax.getFormValues('form1'));return(false);\">>>>>>>>next>>>>>>>>></button>";
	$recordId .= "</form>";
	$recordId .= "</td>";
	$recordId .= "</tr>";
	$recordId .= "</table>";

	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}

function viewEvent()
{
	$cal = new Calendar();
	$db = ConfigurationClass::CreateDbConn();
	$diary = new Diary($db);
	
	
	$month = $cal->getMonth();
	$year = $cal->getYear(); 
	$day = $cal->getDay();
	$startofday = mktime(0, 0, 0, $intMonth, $intDay, $intYear);
	$endofday = mktime(23, 59, 59, $intMonth, $intDay, $intYear);

	
	
	$events = $diary->fnGetDayEvents($startofday, $endofday);
		foreach($events as $key => $value)
		{
			$recordId .= $value; 
		}
		
		
//	$recordId .= "24 hour <br />";
//	$recordId .= "<input type='radio' name='view'> 24 hour<br>";
//	$recordId .= "<td ><input type='radio' name='view' checked> 12 hour<br>";
	$recordId .= '<table>';
	for($i=0; $i<24; $i++)
	{
		$recordId .= '<tr>';
		$recordId .= '<td>';
		$recordId .= $i;
		$recordId .='.00';
		$recordId .= '</td>';
		$recordId .= '<td>';
		$recordId .= '</td>';
		$recordId .= '</tr>';
	}
		
	
	
	$recordId .= "<button type=\"button\" name=\"Submit\"  value=\"Refresh\" onclick=\"xajax_addEventForm(xajax.getFormValues('form1'));return(false);\"> Add Event </button>";
	$recordId .= "<button type=\"button\" name=\"Submit\"  value=\"Refresh\" onclick=\"xajax_addEventForm(xajax.getFormValues('form1'));return(false);\"> Update Event </button>";	
	$recordId .= '</table>';
	//do some more work here!!!!!!!!!!!
	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();
	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}










function addEvent($aFormValues)
{
	$db = ConfigurationClass::CreateDbConn();
	//@@collect the form varaibales
	//@@ add to diary object
	$title = $aFormValues['Title'];
	$date = $aFormValues['Date'];
	$time = $aFormValues['Time'];
	$txtComments = $aFormValues['txtComments'];
	$dateArray = explode('/', $date);
	$timeArray = explode('/', $time);
	$timestamp = mktime($timeArray[1].','.$timeArray[1].',00,'.$dateArray[0].','.$dateArray[1].','.$dateArray[2]);
	$diary = new Diary($db);
	$diary->fnAddEvent($title, $txtComments, $timestamp);
	///$xajax_viewEvent($view);
	//@@perform sql'
	//@@and return result'
	//@@Instantiate the xajaxResponse object
	
	$objResponse = new xajaxResponse();
	$objResponse->addScriptCall("xajax_viewEvent", $view);
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	//return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}

function addEventForm($aFormValues)
{
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	$db = ConfigurationClass::CreateDbConn();
	$recordId .= "<form id='form1' name='form1' action=get>";
	$recordId .= "<table>";
	$recordId .= "<tr><td ><p>Subject</p></td></tr>";
	$recordId .= "<tr><td ><input type='text' name='Title'></td></tr>";
	$recordId .= "<tr><td class='addEvent'><p>Date (month/day/year)</p></td></tr>";
	$recordId .= "<tr><td class='addEvent'><input type='text' name='Date'></td></tr>";
	$recordId .= "<tr><td class='addEvent'><p>Time (10:10:10 24 hour clock in the format hour/minutes/seconds)</p></td></tr>";
	$recordId .= "<tr><td class='addEvent'><input type='text' name='Time'></td></tr>";
	$recordId .= "<tr><td class='addEvent'><p>Description</p></td></tr>";
	$recordId .= "<tr><td colspan='5'> <textarea name='txtComments' cols='40' rows='10'></textarea></tr>";
	$recordId .= "</table>";
	$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_addEvent(xajax.getFormValues('form1'));return(false);\">Add Event</button>";
	$recordId .= "</form>";	

	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	
	 //return the xajaxResponse object with out this no output will be shown
	return $objResponse;
}

//do some more work here!!!!!!!!!!!

function PrevMonth($aFormValues)
{
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	$month = $aFormValues['Month'];
	$year = $aFormValues['Year'];
	$cal = new Calendar();
	$cal->setMonth($month);
	$cal->setYear($year);
	$cal->fnSetPreviousMonth();
	$cal->fnPreviousYear();
	$cal->fnSetCalendarMonth();
	$cal->fnSetTotalDaysInCurrentMonth();
	$cal->fnSetStartDayOfCurrentMonth();
	$cal->fnSetCalendarMonth();
	$aryweek = $cal->getCalendarMonth();
	$arrayLength = count($aryweek);	
	$month = $cal->getMonth();
	$year = $cal->getYear();
	$recordId .= "<table border=\"1\">";
	$recordId .= "<tr>";
	$recordId .= "<td colspan=\"7\">";
	$recordId .= "<h1>";
	$recordId .= $year;
	$recordId .= "</h1>";
	$recordId .= "<form id=\"form1\" name=\"form1\" method=\"get\">";
	$recordId .= "<input type=\"input\" name=\"Month\" value='$month'>";
	$recordId .= "<input type=\"input\" name=\"Year\" value='$year'>";
	
	for($j=0;$j<$arrayLength;$j++) 
	{
		$recordId .= "<tr>\n";
		for($i=0;$i<7;$i++)
		 {				 
		 	$recordId .= "<td onclick=xajax_viewEvent($aryweek[$j][$i])>";
			$recordId .= $aryweek[$j][$i];
			$recordId .= "</td>\n";		
		  }
		  $recordId .= "</tr>\n";
	}
	$recordId .= "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_PrevMonth(xajax.getFormValues('form1'));return(false);\"><<<<<<<prev<<<<<<<<</button>";
	$recordId .= "<button type=\"button\" name=\"Submit\"  value=\"Refresh\" onclick=\"xajax_nextMonth(xajax.getFormValues('form1'));return(false);\">>>>>>>>next>>>>>>>>></button>";
	$recordId .= "</form>";
	$recordId .= "</td>";
	$recordId .= "</tr>";
	$recordId .= "</table>";
	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();
	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@return process the request
$xajax->processRequests();
?>

<html>
<head>
<?php 
//@@Also add the Xajax subdirectory name as an argument if you have the Xajax files, etc. within a subdirectory
$xajax->printJavascript('../../xajax'); 
?>
<script language="JavaScript" src="../smallDatePicker/calendar1.js"></script>
<script language='JavaScript'>
	var cal2 = new calendar1(document.forms['tstest'].elements['input2']);
	cal2.year_scroll = true;
	cal2.time_comp = false;
</script>
			
<link rel=StyleSheet href="styles.css" type="text/css">

</head>
<body>
<!--this is the elemnet id that will be used to show the results//-->

<div id="showRec">
<?
$latestDay = date('j');
$latestMonth = date('n');
$latestYear = date('Y');
$cal = new Calendar();
$cal->setDay($latestDay);
$cal->setMonth($latestMonth);
$cal->setYear($latestYear);	
$cal->fnSetTotalDaysInCurrentMonth();
$cal->fnSetStartDayOfCurrentMonth();
$cal->fnSetCalendarMonth();
$aryweek = $cal->getCalendarMonth();
echo "<table border=\"1\">";
echo "<tr>";
echo "<td colspan=\"7\">";
echo "<form id=\"form1\" name=\"form1\" method=\"get\">";
echo "<input type=\"input\" name=\"Month\" value=$latestMonth>";
echo "<input type=\"input\" name=\"Year\" value=$latestYear>";
$arrayLength = count( $aryweek);
for($j=0;$j<$arrayLength;$j++) 
{
	echo "<tr>\n";
	for($i=0;$i<7;$i++)
	 {				 
	 	echo "<td >";
	 	echo "<a href=# onclick=xajax_viewEvent()>";
		echo $aryweek[$j][$i]."</a>";
		echo "</td>\n";
	 }
	  echo "</tr>\n";
}
echo "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_PrevMonth(xajax.getFormValues('form1'));return(false);\"><<<<<<<<prev<<<<<<<</button>";
echo "<button type=\"button\" name=\"Submit\" value=\"Refresh\" onclick=\"xajax_nextMonth(xajax.getFormValues('form1'));return(false);\">>>>>>>>>next>>>>>>>></button>";
echo "</form>";
echo "</td>";
echo "</tr>";
echo "</table>";
?>
</div>
</body>
</html>