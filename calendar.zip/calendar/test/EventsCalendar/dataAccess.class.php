<?php

require_once('../../general_classes/dbConnection.class.php');

class dataAccess
{
	public function getArrayOfEventsForDay($startOfDay, $endOfDay)
	{
		$arrEvents = array();
		$arrDaysEvents = array();
		$diaryConnection = new Connection('localhost','root','','diarydb');
		//$eventsForDay = execute("select * from tbl_events where DateTime >= '. $startOfDay .' and DateTime <= '. $endOfDay .'");
		$diaryConnection->execute("select * from tbl_events");
		$diaryConnection->fetchArray($diaryConnection);
		while($arrEvents = $diaryConnection->fetchArray())
		{	
			$eventID = $arrEvents['Events_id'];
			$date= $arrEvents['Date/Time'];
			$arrDaysEvents = array('EventId'=>$eventID, 'Date'=>$date);
		}
		return $arrDaysEvents;
	}
}