<?
//test build
include_once('DiaryAccess.class.php');
include_once('Diary.class.php');
require_once('ConfigurationClass.class.php');



$db = ConfigurationClass::CreateDbConn();
$diary = new Diary($db);


//$diary->fnAddEvent('zzzzzzzzzzz','sas hgh shfsdf');
//$diary->fnRemoveEvent(14);
//$diary->fnUpdateEvent(1, 'saf','fsad fdsaf asf');



//we need to edit events the update sql in ordr top edit event entered into dat base tables

	$startofday = mktime(0, 0, 0, 11, 1, 2000);
	$endofday = mktime(23, 59, 59, 12, 3, 2009);

	
	$events = $diary->fnGetDayEvents($startofday, $endofday);
		foreach($events as $key => $value)
		{	
			$recordId .= $value; 
			$recordId .= '<br />';
		}
	
		echo $recordId;
	
	

?>