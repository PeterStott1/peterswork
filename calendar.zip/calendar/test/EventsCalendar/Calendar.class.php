<?php


require_once("baseCalendar.class.php");

class Calendar extends baseCalendar 
{
	
	public $arrCalendarMonth  = array();
	
	public function getCalendarMonth()
	{
		return $this->arrCalendarMonth;		
	}

	public function fnSetCalendarMonth()
	{
			
			$intWeeksInMonth;
			$intDaysInMonthPlusStartDay;
			$arrDatesInMonth = array();
			$intSet1EmptySpaceInCalendar;
			$arrSet1DatesInCalendar = array();
			$intSet2EmptySpaceInCalendar;
			$intAllDaysToBeShownInMonth;
			$intPreviousMonth;
			$intNextMonth;
			$intDaysInPreviousMonth;
			$intDaysInNextMonth;
			
			//sets intDaysInMonthPlusStartDay to the number of days in the month + the number of the first day
			$intValue1 = $this->intDaysInMonth;
			$intValue2 = $this->intMonthStartDay;
			$intDaysInMonthPlusStartDay = $intValue1 + $intValue2;
			
			//sets intWeeksInMonth to the number of weeks in the month
			$intTotalDays = $intDaysInMonthPlusStartDay;
			$intWeeksInMonth = ceil($intTotalDays/7);
			
			//sets the total days to be shown in the month
			$intAllDaysToBeShownInMonth = ($intWeeksInMonth * 7);
	
			//sets arrDatesInMonth to store a list of days from the mon of the first week of the month
			//to the Fri of the last week of the month
			$intCounter1 = 0;
			$intCounter1 -= ($this->intMonthStartDay-1);
			for($a=0;$a<$intWeeksInMonth;$a++) 
				{
					for($b=0;$b<7;$b++)
					 {				                          
					 	$intCounter1++; 
						$arrDatesInMonth[$a][$b] = $intCounter1;
					  }
				}
					
			//sets intSet1EmptySpaceInCalendar to the number between mon of the first week to the first day the month starts on			
			$c = 0;
			for($d=0;$d<$intWeeksInMonth;$d++) 
			{
				for($e=0;$e<7;$e++)
				 {				 	 	
					while($arrDatesInMonth[$d][$c]<1)
					{			
						$intSet1EmptySpaceInCalendar++;	
						$c++;
					}	 
				 }
			}

			//sets intSet2EmptySpaceInCalendar to the number between last date in month and last Fri of month
			$intSet2EmptySpaceInCalendar = $intAllDaysToBeShownInMonth - $intDaysInMonthPlusStartDay;
						
			//Work out which Month is the previous month and store in $previousMonth
			$intPreviousMonth = $this->intMonth - 1;
			
			//Work out which Month is the next month and store in $nextMonth;
			$intNextMonth = $this->intMonth + 1;

			//Count the number of days in the previous and next month and store in variables
			$intDaysInPreviousMonth = date("t", mktime(0,0,0,$intPreviousMonth,1,$this->intYear));
			$intDaysInNextMonth = date("t", mktime(0,0,0,$intNextMonth,1,$this->intYear));

			//loop through and create an array with the dates at the end of the previous month which will be
			//added to the calendar for the current month
			$intValA = $intSet1EmptySpaceInCalendar;
			$intValA = $intValA-1;
			for($f=0; $f<$intSet1EmptySpaceInCalendar; $f++)
			{
				$arrSet1DatesInCalendar[$intValA] = $intDaysInPreviousMonth;
				$intValA--;
				$intDaysInPreviousMonth--;	
			}

			//Add the new array with the days of the previous month which will be included in the current month
			//to the array storing the dates in the current month. 
			$intDaysInPreviousMonthArray = count($arrSet1DatesInCalendar);
	
			 	for($h=0;$h<$intDaysInPreviousMonthArray ;$h++)
			 	{
					$arrDatesInMonth[0][$h] = "<span class='date' id='notInCalendar'>$arrSet1DatesInCalendar[$h]";
			 	}		 
			 	
			 	//Add the new array with the days of the follwing month which will be included in the current month 
				//total weeks * 7	
			 	$intSet2EmptySpaceInCalendar = $intAllDaysToBeShownInMonth - $intDaysInMonthPlusStartDay; 
			 	$tempval2 = 7 - $intSet2EmptySpaceInCalendar;
				$i = 1;
				for($x=$tempval2;$x<7 ;$x++)
			 	{
					$arrDatesInMonth[$intWeeksInMonth-1][$x] = "<span class='date' id='notInCalendar'>$i</span>";
					$i++;
			 	}		 
			 $this->arrCalendarMonth =  $arrDatesInMonth;
			 return $this->arrCalendarMonth;	 	
		}
		
		
}
?>