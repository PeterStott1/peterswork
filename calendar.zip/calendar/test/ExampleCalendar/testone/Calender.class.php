<?
class Calender
{
	public $intDay = 0;
	public $intMonth = 0;
	public $intYear = 0;

	public function fnGetDate($intDay, $intMonth, $intYear)
	{
		$this->intDay = $intDay;
		$this->intMonth = $intMonth;
		$this->intYear = $intYear;

	}

	public function fnBuildCalenderView()
	{
		echo "<table border=\"1\">\n";

		for($i=0; $i<=11;$i++)
		{

			for($j=0;$j<=3;$j++)
			{
				echo "<tr >\n";

					for($h=0;$h<=6;$h++)
					{

						switch($h)
							{
								case 0: echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "Sunday";
										echo "</td>\n";
										break;
								case 1:
										echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "Monday";
										echo "</td>\n";
										break;
								case 2:
										echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "tuesday";
										echo "</td>\n";
										break;
								case 4:
										echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "Wednesday";
										echo "</td>\n";
										break;
								case 5:
										echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "Thursday";
										echo "</td>\n";
										break;
								case 6:
										echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "Friday";
										echo "</td>\n";
										break;
								case 7:
										echo "<td border=\"1\" style=\"width:60px;height:60px;\">";
										echo "Saturday";
										echo "</td>\n";
										break;
								default;
								break;
							}


					}
				echo "</tr>\n";
			}


		}
		echo "</table>\n";
	}


}
?>