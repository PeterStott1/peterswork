<?
require('Calender.class.php');

$cal = new Calender();

$cal->fnBuildCalenderView();
?>