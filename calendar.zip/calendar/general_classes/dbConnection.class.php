<?php

class Connection
{
	//------------		member variables		---------------------
	public $strServeur = HOSTNAME;
	public $strLogin = USERNAME;
	public $strPassword = PASSWORD;
	public $strBase = DATABASE;
	public $intConnectionId = 0;
	public $strQueryResult = '';
	public $intErrorExists = 0;
	public $strMessage = '';
	public $bDisconnectDB = true;
	//------------------------------------------------------------

	//------------		__construct		---------------------
	//ouvre la connexion, stocke l'id, s�lectionne la base
	public function __construct($serveur=HOSTNAME,$login=USERNAME,$password=PASSWORD,$base=DATABASE)
	{
		$this->strServeur = $serveur;
		$this->strLogin = $login;
		$this->strPassword = $password;
		$this->strBase = $base;
		$this->strQueryResult = '';//
		
		if(!($this->intConnectionId = @mysql_connect($this->strServeur,$this->strLogin,$this->strPassword)))
			die("error connecting to the server {$this->serveur}");
			//the die will output the error message and then gracefully end the script
			//preventing the PHP engine outputting hundreds of warnings
		if( ! (@mysql_select_db($this->strBase,$this->intConnectionId) ) )
		{
			//return $this->strShowError();
			die("Error ". mysql_errno($this->intConnectionId) . " : ".mysql_error($this->intConnectionId)."<br>");
		} else {
			return mysql_select_db($this->strBase,$this->intConnectionId);
		}
	}
	
	//------------		member functions	---------------------
	public function strShowError() {
		//die("Error ". mysql_errno($this->intConnectionId) . " : ".mysql_error($this->intConnectionId)."<br>");
		return ("Error ". mysql_errno($this->intConnectionId) . " : ".mysql_error($this->intConnectionId)."<br>");
	}
	public function execute( $request )	{
		$this->strQueryResult = mysql_query( $request, $this->intConnectionId );
		if (!($this->strQueryResult))
		{
			die("Problem with the execute of the sql statement: {$request}<br>Error ". mysql_errno($this->intConnectionId) . " : ".mysql_error($this->intConnectionId)."<br>");
			/*$this->strMessage ("Problem with the execute of the sql statement: {$request}");
			$this->strMessage ("<B>MySQL proteste : </B>".mysql_error($this->intConnectionId));
			return $this->strMessage;
			$this->intErrorExists = 1;*/
		}
		return ( $this->strQueryResult );
	}
	public function closeConnection()	{
		return(mysql_close( $this->intConnectionId ));
	}
	//private function databaseError()	{
		//return(mysql_error());
	//}
	public function fetchArray()	{
		return (mysql_fetch_array($this->strQueryResult));
	}
	public function fetchAssoc()	{
		return (mysql_fetch_assoc($this->strQueryResult));
	}
	public function fetchObject()	{
		return (mysql_fetch_object($this->strQueryResult));
	}
	public function fetchRow()	{
		return (mysql_fetch_row($this->strQueryResult));
	}
	public function numberOfRows()	{
		return (mysql_num_rows($this->strQueryResult));
	}
	public function affectedRows()	{
		return (mysql_affected_rows($this->strQueryResult));
	}
	//Retrieves a string providing information about the most recently executed statement. 
	//Returns NULL for some type of statements
	public function mysqlInfo() {
		return (mysql_info($this->intConnectionId));
	}
	//How many attributes are there
	public function mysqlNumFields() {
		return (mysql_num_field($this->strQueryResult));
	}
	//gets the last auto_incremented id by the sql statement, if none on the table returns something else?
	public function mysqlInsertId() {
		return (mysql_insert_id($this->intConnectionId));
	}
	//------------		__destruct		---------------------
	/*public function __destruct() {
		if($this->bDisconnectDB == 1) {
			print "Database connetion out of scope. ConnectionId: {$this->intConnectionId}";
		}
	}*/
}
?>