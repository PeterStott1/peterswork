<?php
echo "this is a service test";
require_once('mysqlclass.php');
require_once('DataAccess.class.php');
require_once('WorkOrderDescriptor.class.php');
require_once('TriggerEngine.class.php');

//$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3dev'));

$workOrderId="TzoxOToiV29ya09yZGVyRGVzY3JpcHRvciI6ODp7czoxMzoic3RyUHJvcGVydHlJZCI7czoxOiIxIjtzOjExOiJzdHJWZW5kb3JJZCI7czoxOiIxIjtzOjIwOiJzdHJWZW5kb3JTb2xpY2l0b3JJZCI7czoxOiIxIjtzOjE0OiJzdHJBcHBsaWNhbnRJZCI7czoxOiIxIjtzOjIzOiJzdHJBcHBsaWNhbnRTb2xpY2l0b3JJZCI7czoxOiIxIjtzOjk6InN0clVzZXJJZCI7czoxOiIyIjtzOjExOiJzdHJCcmFuY2hJZCI7czoxOiIxIjtzOjE2OiJib29sSW5jbHVkZVJvb21zIjtiOjE7fQ==";

try {


$client = new SoapClient(null, array('location' => "http://89.234.36.211/soapservice/newclasses/service.php", 'uri' => "urn:http://89.234.36.211/soapservice/newclasses/req",'trace'    => 1 ));
$return = $client->__SoapCall("GetWorkOrderByID",array($workOrderId));

echo $return;
}catch(Exception $ex)
{

	echo $ex;
}


?>