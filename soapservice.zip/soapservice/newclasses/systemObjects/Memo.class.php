<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Memo extends EntityBase implements  IEntityObject 
{
	
	public $dtDate ="Conversation Date displayed here";
	public $strSubject ="Conversation Subject displayed here";
	public $strNotes = "Conversation Notes displayed here";
	
	
	public function getProperties()
	{
		
		$resultarray = array(
		'Conversation Date' => $this->dtDate,
		'Conversation Subject'=>$this->strSubject,
		'Conversation Notes'=> $this->strNotes
	
		);
		return $resultarray;	
	
	}
	
	public function getName()
	{
		return('Memo / Conversation Details');
	}
	
	
	
}
?>