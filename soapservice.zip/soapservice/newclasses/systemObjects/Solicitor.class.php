<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class Solicitor extends EntityBase implements  IEntityObject 
{
	
	public $strContactName="Solicitor contact name";
	public $strAddress = "Solicitor address string";
	public $strAddressBlock = "Solicitor address string";
	public $strPhoneNumber = "Solicitor phone number";
	public $strAddress1 = "line 1";
	public $strAddress2 = "line 2";
	public $strAddress3 = "line 3";
	public $strCountry = "country";
	public $strCounty = "county";
	public $strTown = "town/city";
	public $strPostCode = "Solicitor postcode";
	public $strPhoneNo = "Solicitor phone";
	public $strFaxNo = "Solicitor xax";
	public $strDxRef= "Solicitor DX";
	public $strEmailAddress = "Solicitor Email";
	public $strTerms = "Solicitor terms";
	public $strNotes = "Solicitor notes";
	public $strPosition = "Solicitor position";
	public $strCompanyName = "Solicitor company name";
	public $strCompanyPhone = "Solicitor company phone";
	public $strContactPhone = "Solicitor contact phone";
	public $strSalutation = "Solicitor salutation";
	public $strContactEmail = "Solicitor contact email";

	
	public function getProperties()
	{
		$strTemp =$this->strAddressRoadNo.",".$this->strAddressRoadName.",".$this->strAddress2.",".$this->strAddress3.",".$this->strTown.",".$this->strCounty.",".$this->strCountry.",".$this->strPostCode;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultarray = array(
		
//		'vendor'=>$this->strAddress,
//		'vendor'=>$this->strContactName,
//		'vendor'=>$this->strPhoneNumber
		//		'Vendor Solicitor Company Name' => $this->strCompanyName,
		'Solicitor Fax No ' => $this->strFaxNo,
		'Solicitor DX Ref' => $this->strDxRef,
		'Solicitor Terms' => $this->strTerms,
		'Solicitor Notes' => $this->strNotes,

		'Solicitor Road No' => $this->strAddressRoadNo,
		'Solicitor Road Name' => $this->strAddress1,
		'Solicitor Address 2' => $this->strAddress2,
		'Solicitor Address 3' => $this->strAddress3,
		'Solicitor country' => $this->strCountry,
		'Solicitor County' => $this->strCounty,
		'Solicitor Town' => $this->strTown,
		'Solicitor PostCode' => $this->strPostCode,
		'Solicitor Phone No' => $this->strPhoneNo,
		'Solicitor Email' => $this->strEmailAddress,
		'Solicitor Address String' => $this->strAddress,
		'Solicitor Address Block' => $this->strAddressBlock,

		'Solicitor Contact' => $this->strContactName,
		'Solicitor Position' => $this->strPosition,
		'Solicitor Contact Phone' => $this->strContactPhone,
		'Solicitor Salutation' => $this->strSalutation
		);
		

		
		return $resultarray;	
	
	}
	
	
	public function getName()
	{
		return("Solicitor");
	}

	
}
?>