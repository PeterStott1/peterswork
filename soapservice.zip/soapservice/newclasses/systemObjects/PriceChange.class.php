<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
 
class PriceChange extends EntityBase implements  IEntityObject 
{
	
	public $PriceId ="1";
	public $Prop_Id ="1";
	public $dtReqDate = "Price Change Date displayed here";
	public $tmRegTime = "Price Change Time displayed here";
	public $OldAmount = "Price Change Current Amount displayed here";
	public $NewAmount = "Price Change New Amount displayed here";
	public $strComments = "Price Change Details displayed here";
	public $strNotes = "Price Change Notes";
	public $inttype = "Price Change Library Item Type displayed here";
	public $intComp = "1";
	
	
	public function getProperties()
	{
		$resultarray = array(
		'Price Change Date'=>$this->dtReqDate, 
		'Price Change Time Entered'=>$this->tmRegTime, 
		'price Change Old Amount'=>$this->OldAmount, 
		'price Change New Amount'=>$this->NewAmount, 
//\\ ???		'price Change Comments'=>$this->strComments, 
		'price Change Notes'=>$this->strNotes, 
		'price Change Library Item Type'=>$this->inttype, 
//\\ ???		'price Change Comp'=>$this->intComp 
		);
		return $resultarray;	
	}
	
	public function getName()
	{
		return("Price Change Details");
	}
	
	
	
}
?>