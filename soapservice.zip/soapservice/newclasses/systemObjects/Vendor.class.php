<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class vendor extends EntityBase implements  IEntityObject 
{
 
	public $strHomePhone = "Vendor Home Phone Number displayed here";
	public $strBusPhone = "Vendor Business Number displayed here";
	public $strFaxNo="Vendor Fax Number displayed here";
	public $strMobileNo="Vendor Mobile Number displayed here";
	public $strEmail="Vendor Email Address displayed here";
	public $strSalutation="Vendor Salutation displayed here";
	public $strVendorTitle = "Vendor Title displayed here";
	public $strVendorFirstName = "Vendor First Name displayed here";
	public $strVendorInitial = "Vendor Initials displayed here";
	public $strVendorSurname = "Vendor Surname displayed here";
	public $strJVendorTitle = "Vendor Title displayed here";
	public $strJVendorFirstName = "Vendor First Name displayed here";
	public $strJVendorInitial = "Vendor Initials displayed here";
	public $strJVendorSurname = "Vendor Surname displayed here";
	public $strCompanyName="Company Name displayed here";
	public $strVendorName = "Vendor Name displayed here";
	public $strVendorNumber= "Internal Reference No displayed here";
	public $strVendor_allow_sms="Vendor Elected for SMS displayed here"; 
	public $strVendor_allow_email="Vendor Elected for Email displayed here"; 
	public $strVendor_allow_post="Vendor Elected for Post displayed here"; 
	public $strVendor_allow_phone="Vendor Elected for Phone displayed here"; 
	public $strVendor_allow_MMs="Vendor Elected for MMS displayed here";
	public $strVendorUsername = "Vendor Login Name displayed here";
	public $strVendorPassword = "Vendor Password displayed here"; 
	public $strBranchName = "Branch Name"; 
	public $strPropFor = "Property for Sale or Let"; // not need being dealt with in Property class
	public $strVendorNotes = "Vendor Notes displayed here";
	public $dtDateEntered ="Date Entered displayed here";
	public $dtLastChanaged = "Last Updated Date displayed here";
	public $strVendorReferenceId = "Vendor Reference ID displayed here";
	public $intBranchId = "Branch ID displayed here";
	public $strVendorUserRights = "Assigned Negotiator displayed here";
	public $strJVHomePhone = "JV Home Phone Number displayed here";
	public $strJVBusPhone = "JV Business Phone Number displayed here";
	public $strJVFaxNo="JV Fax Number displayed here";
	public $strJVMobileNo="JV Mobile Number displayed here";
	public $strJVEmail="JV Email Address displayed here";
	public $strJVendorName = "JV Name displayed here";
	public $strJVendor_allow_sms="JV Elected for SMS displayed here"; 
	public $strJVendor_allow_email="JV Elected for Email displayed here"; 
	public $strJVendor_allow_post="JV Elected for Post displayed here"; 
	public $strJVendor_allow_phone="JV Elected for Phone displayed here"; 
	public $strJVendor_allow_MMs="JV Elected for MMS displayed here";
	public $strJVendorUsername = "JV Login name displayed here";
    public $strJVendorPassword = "JV Password displayed here"; 
	
	public function getProperties()
	{
		// here is where we split and concantate the string as well as block address string
		$resultArray = array
		(
//		    	'Vendor Name'=>$this->strVendorName,
//		    	'Vendor Title'=>$this->strVendorTitle,
//		    	'Vendor Firstname'=>$this->strVendorFirstName,
//		    	'Vendor Initials'=>$this->strVendorInitial,
//		    	'Vendor Surname'=>$this->strVendorSurname,
			'Vendor Home Number' => $this->strHomePhone,
			'Vendor Business Number'=>$this->strBusPhone ,
			'Vendor Fax number' => $this->strFaxNo,
			'Vendor Mobile Number'=>$this->strMobileNo,
			'Vendor Email Address' => $this->strEmail,
			'Vendor Property Company Name' => $this->strCompanyName, 
			'Vendor Elected for SMS'=>$this->strVendor_allow_sms,
			'Vendor Elected for Email'=>$this->strVendor_allow_email,
			'Vendor Elected for Post'=>$this->strVendor_allow_post,
			'Vendor Elected for Phone'=>$this->strVendor_allow_phone,
			'Vendor Elected for MMS'=>$this->strVendor_allow_MMs,
			'Vendor Web Profile Username'=>$this->strVendorUsername , 
			'Vendor Web Profile Password'=>$this->strVendorPassword ,
			//if it is one if zero is sale need to add the new function
			
//			'Joint Vendor Name'=>$this->strJVendorName,
//			'Joint Vendor Title'=>$this->strJVendorTitle,
//		    'Joint Vendor Firstname'=>$this->strJVendorFirstName,
//		    'Joint Vendor Initials'=>$this->strJVendorInitial,
//		    'Joint Vendor Surname'=>$this->strJVendorSurname,
			'Joint Vendor Business Number'=>$this->strJVBusPhone,
			'Joint Vendor Home Number' => $this->strJVHomePhone,
			'Joint Vendor Fax Number' => $this->strJVFaxNo,
			'Joint Vendor Mobile Number'=>$this->strJVMobileNo,
			'Joint Vendor Email Address' => $this->strJVEmail,
			'Joint Vendor Elected for SMS'=>$this->strJVendor_allow_sms,
			'Joint Vendor Elected for Email'=>$this->strJVendor_allow_email,
			'Joint Vendor Elected for Post'=>$this->strVendor_allow_post,
			'Joint Vendor Elected for Phone'=>$this->strVendor_allow_phone,
			'Joint Vendor Elected for MMS'=>$this->strVendor_allow_MMs,
			'JVendor Web Profile Username'=>$this->strJVendorUsername , 
			'JVendor Web Profile Password'=>$this->strJVendorPassword , 

			'General Salutation' => $this->strSalutation,			
			'General Branch Name Assigned'=>$this->strBranchName, 
			'General Notes'=>$this->strVendorNotes , 
//			'General Internal Reference No'=>$this->strVendorReferenceId , 
			//search on the lib_branch for the value of branch id
			//'General Vendor Branch'=>$this->intBranchId, 
			//@@need to look at lib_br_staff for the negotiator
//			'General Assigned Negotiator'=>$this->VendorUserRights

//Items below being dealt with else where e.g. property class
//			'Property For: Sale or Let'=>$this->strPropFor, 

// Items below not required
//			'Vendor date Entered'=>$this->dtDateEntered ,
//			'Vendor Last Changed'=>$this->dtLastChanaged , 

		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Vendor & JV Details");
	}

	
}
?>