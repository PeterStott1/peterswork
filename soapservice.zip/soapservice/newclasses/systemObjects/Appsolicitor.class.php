<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class AppSolicitor extends EntityBase implements  IEntityObject 
{
	
	public $strCompanyName = "Applicant Solicitor Company Name";
	public $strFaxNo = "Applicant Solicitor Company Fax Number displayed here";
	public $strDxRef= "Applicant Solicitor Company DX Ref displayed here";
	public $strTerms = "Applicant Solicitor Company Terms displayed here";
	public $strNotes = "Applicant Solicitor Company Notes displayed here";

	public $strAddressRoadNo = "Applicant Solicitor Correspondence Road / Street No displayed here";
	public $strAddressRoadName = "Applicant Solicitor Correspondence Road / Street Name displayed here";
	public $strAddress2 = "Applicant Solicitor Correspondence Address Line 2 displayed here";
	public $strAddress3 = "Applicant Solicitor Correspondence Address Line 3 displayed here";
	public $strCountry = "Applicant Solicitor correspondence Address Country";
	public $strCounty = "Applicant Solicitor Correspondence County displayed here";
	public $strTown = "Applicant Solicitor Correspondence Town / City displayed here";
	public $strPostCode = "Applicant Solicitor Correspondence Post Code";
	public $strPhoneNo = "Applicant Solicitor Correspondence Phone Number displayed here";
	public $strEmailAddress = "Applicant Solicitor Correspondence Email Address displayed here";

	public $strAddress = "Applicant Solicitor Address String displayed here";
	public $strAddressBlock = "Applicant Solicitor Block Address display here";

	public $strContactName="Applicant Solicitor Contact Name displayed here";
	public $strPosition = "Applicant Solicitor Contact Position displayed here";
	public $strContactPhone = "Applicant Solicitor Contact Mobile No displayed here";
	public $strSalutation = "Applicant Solicitor Contact Salutation displayed here";
	
	
	
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$strTemp =$this->strAddressRoadNo.", ".$this->strAddressRoadName.", ".$this->strAddress2.", ".$this->strAddress3.", ".$this->strTown.", ".$this->strCounty.", ".$this->strCountry.", ".$this->strPostCode;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultarray = array(
//		'applicant'=>$this->strAddress,
//		'applicant'=>$this->strContactName,
//		'applicant'=>$this->strPhoneNo
		' Solicitor Company Name' => $this->strCompanyName,
		' Solicitor Fax No ' => $this->strFaxNo,
		' Solicitor DX Ref' => $this->strDxRef,
		' Solicitor Terms' => $this->strTerms,
		' Solicitor Notes' => $this->strNotes,

		' Solicitor  Road No' => $this->strAddressRoadNo,
		' Solicitor  Road Name' => $this->strAddressRoadName,
		' Solicitor  Address 2' => $this->strAddress2,
		' Solicitor  Address 3' => $this->strAddress3,
		' Solicitor  country' => $this->strCountry,
		' Solicitor  County' => $this->strCounty,
		' Solicitor  Town' => $this->strTown,
		' Solicitor  Post Code' => $this->strPostCode,
		' Solicitor  Phone No' => $this->strPhoneNo,
		'Email Address' => $this->strEmailAddress,
		'Address String' => $this->strAddress,
		'Address Block' => $this->strAddressBlock,

		' Solicitor Contact Name' => $this->strContactName,
		' Solicitor Position' => $this->strPosition,
		' Solicitor Contact Phone' => $this->strContactPhone,
		' Solicitor Salutation' => $this->strSalutation
		);

		return $resultarray;	
	}
	
	
	public function getName()
	{
		return("Applicant Solicitor");
	}

	
}
?>