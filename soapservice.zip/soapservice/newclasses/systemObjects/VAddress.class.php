<?
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class VAddress extends EntityBase implements  IEntityObject 
{

	public $strVendorPropNumber = "Property / Flat Number displayed here";
	public $strVendorPropName = "Property / Flat Name displayed here";
	public $strVendorAdressLine1 = "Road / Street Number displayed here"; // *** duplicate with below ??
	public $strVendorRoadNo = "Road / Street Number displayed here";
	public $strVendorRoadName = "Road / Street Name displayed here";
	public $strVendorAddressLine2 = "Address Line 2 displayed here";
	public $strVendorAddressLine3 = "Address Line 3 displayed here";
	public $strVendorAddressTown = "Town / City displayed here";
	public $strVendorAddressCounty = "County displayed here";
	public $strVendorAddressCountry = "Country displayed here";
	public $strVendorAddressPostcode = "Post Code displayed here";
	public $strVendorAddress ="Address String displayed here";
	public $strVAddressBlock = "Address Block displayed here";
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
	
	 $strTemp = $this->strVendorPropNumber.", ".$this->strVendorPropName.", ".$this->strVendorAddressLine2.", ".$this->strVendorAddressLine3.", ".$this->strVendorAddressTown.", ".$this->strVendorAddressCounty.", ".$this->strVendorAddressCountry.", ".$this->strVendorAddressPostcode;
	 $this->strVendorAddress = StringManipulation::CheckforCommaFields($strTemp);
	 $this->strVAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
		    
//			'Flat/ House'=> $this->strVendorPropName,
//			'Flat / House No'=>$this->strVendorPropNumber,
//			'Road/Street No'=>$this->strVendorRoadNo,
//			'Road /Street '=>$this->strVendorRoadName,
//			'Line 2'=>$this->strVendorAddressLine2,			
//			'Line 3'=>$this->strVendorAddressLine3,
//			'Town'=>$this->strVendorAddressTown,
//			'County'=>$this->strVendorAddressCounty,
//			'Country'=>$this->strVendorAddressCountry,
//			'Postcode'=>$this->strVendorAddressPostcode,
//			'String'=> $this->strVendorAddress,
//			'Block'=> $this->strVAddressBlock
		'Property No'=>$this->strVendorPropNumber,	  
			'Property Name'=> $this->strVendorPropName,
			//Line 1 not needed!!!!!! Anton was right :)
//			'Line 1'=>$this->strVendorAdressLine1,
			'Road / Street No'=>$this->strVendorRoadNo,
			'Road / Street Name'=>$this->strVendorRoadName,
			'Line 2'=>$this->strVendorAddressLine2,			
			'Line 3'=>$this->strVendorAddressLine3,
			'Town'=>$this->strVendorAddressTown,
			'County'=>$this->strVendorAddressCounty,
			'Country'=>$this->strVendorAddressCountry,
			'Address PostCode'=>$this->strVendorAddressPostcode,
			'Address String'=> $this->strVendorAddress,
			'Address Block'=> $this->strVAddressBlock,
//			Line 1 not needed!!!!!! Anton was right :)
//			'Line 1'=>$this->strVendorAdressLine1,	
			
		);
		return $resultArray;	
	}
	
	public function getName()
	{
		return("Vendor Address");
	}
	
}

?>