<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
class User extends EntityBase implements  IEntityObject 
{
	//staff_id, password, first_name, 
	
	public $strUser ="Users Name displayed here";
	public $strUsername = "Users Login Name displayed here";
	public $strPosition = "Users Position displayed here";
	public $strMobileNumber = "Users Mobile displayed here";
	public $picImage = "Users Picture displayed here";
	public $picSignature = "Users Signature displayed here";
	public $strBranchId = "Users Branch ID";
	public $strBranchPhone = "Users Branch Phone No displayed here";
	public $strDepartment = "Users Department displayed here";
	public $strEmailAddress = "Users Email displayed here";
	
	
	//@@return Get proeprties is a part of the abstract so it must be in the object or it will error dir
	public function getProperties()
	{
		$resultArray = array (
		'Users Name' => $this->strUser,
		'Users Login Name' => $this->strUsername,
		'Users Email Address'=>$this->strEmailAddress,
		'Users Position'=>$this->strPosition,
		'Users Mobile Number'=>$this->strMobileNumber,
		'Users Branch Phone Number'=> $this->strBranchPhone,
		'Users Branch Id'=> $this->strBranchId,
		'Users Department'=>$this->strDepartment
		
		);
		
		return $resultArray;
	}
	//@@return get images again is part of the abstract class if you like a way of setting up a frame work for the coder to follow
	public function getImages()
	{
		$resultArray = array
		(
			
			'Users Picture'=>$this->picImage,
			'Users Signature'=>$this->picSignature
			
		);
		return $resultArray;	
	
		
	}
	
	public function getName()
	{
		return("Users Details");
	}
}
?>