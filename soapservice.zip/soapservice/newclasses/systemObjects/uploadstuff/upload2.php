<?
if ($HTTP_POST_VARS['add_image']) {
$base_path = "path".$_FILES['image']['name'];

copy($_FILES['image']['tmp_name'], $base_path);
chmod ($base_path, 0644);

$image_path = "./propphoto" . $_FILES['image']['name'];

$result = pg_exec ("insert into table (image) values ('$image_path') ");

exit;
} else {?>

<form method="post" enctype="multipart/form-data">
Upload image - <input type="file" name="image">
<input type="submit" name="add_image" value="add this image">
</form>
<?}?>
