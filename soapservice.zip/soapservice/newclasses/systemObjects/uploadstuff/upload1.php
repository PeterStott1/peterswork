<?php
// define the base image dir
$base_img_dir = "../propphoto/";

// define location of image conversion programs
$img_conv_dir = "./bin/";

// define database table containing image info
$img_table = "images";

// connect with database
mysql_connect("192.168.13.240", "root", "letmein");
mysql_select_db("test");
//require 'myconnect1.php';
// generate unique id for use in filename
$uniq = uniqid("");

// new file name
$filename = $base_img_dir.$uniq;

// move uploaded file to destination
move_uploaded_file($_FILES["file"]["tmp_name"], $filename);
//$HTTP_POST_FILES
// retrieve image info
$imginfo = getimagesize($filename);

// handle image according to type
switch ($imginfo[2]) {
    case 1: // gif
        // convert gif to png using shell command
        $command = $img_conv_dir."gif2png $filename";
        exec($command);

        // remove original gif file and rename converted png
        unlink($filename);
        rename("$filename.png", $filename);

        // check png image by loading and saving the file
        //  to prevent wrong uploaded files and errors
        $img = imagecreatefrompng($filename);
        imagepng($img, $filename);
        imagedestroy($img);

        // set image type to png
        $img_type = "PNG";
        break;

    case 2: // jpeg
        // check jpeg image by loading and saving the file
        //  to prevent wrong uploaded files and errors
        $img = imagecreatefromjpeg($filename);
        imagejpeg($img, $filename);
        imagedestroy($img);

        // set image type to jpeg
        $img_type = "JPG";
        break;

    case 3: // png
        // check png image by loading and saving the file
        //  to prevent wrong uploaded files and errors
        $img = imagecreatefrompng($filename);
        imagepng($img, $filename);
        imagedestroy($img);

        // set image type to png
        $img_type = "PNG";
        break;

    case 4: // bmp
        // rename file to bmp
        rename($filename, "$filename.bmp");

        // convert bmp to png using shell command
        $command = $img_conv_dir."bmptoppm $filename.bmp | ".
                   $img_conv_dir."pnmtopng > $filename";
        exec($command);

        // remove original bmp
        unlink("$filename.bmp");

        // check png image by loading and saving the file
        //  to prevent wrong uploaded files and errors
        $img = imagecreatefrompng($filename);
        imagepng($img, $filename);
        imagedestroy($img);

        // set image type to png
        $img_type = "PNG";
        break;

    default:
        break;
}

// retrieve image file size
$imgbytes = filesize($filename);

// insert image into db
mysql_query("INSERT INTO images (img_file, img_type, img_height,
   img_width, img_bytes, img_title, img_descr, img_alt)
  VALUES('$uniq', '$img_type', ".$imginfo[1].", ".$imginfo[0].",
         $imgbytes, '".addslashes($_POST["title"])."', '".
         addslashes($_POST["descr"])."',
         '".addslashes($_POST["alt"])."');");

// display some information
echo "Image uploaded.<br><img src=\"img.php?f($uniq)+x(300)\"><br>".
     "URL: img.php?f($uniq)";
?>
