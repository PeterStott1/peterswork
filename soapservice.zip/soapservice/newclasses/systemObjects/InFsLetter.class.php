<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class InFsLetter extends EntityBase implements  IEntityObject 
{ 

		 public $strAptID  ="1"; 
		 public $strFsAppoinmantperson = "Financial Advisors Name displayed here";
//		 public $strApplicantId = '4';
		 public $strAppointmentNotes = 'Appointment Notes displayed here';
		 public $dtAppointmentDate = 'Appointment Date displayed here';
		 public $tmAppointmentTime = 'Appointment Time displayed here';
		 public $tmAppointmentDuration = 'Appointment Duration displayed here';
		
		 
		 public function getProperties()
			{
				$resultarray = array(
//				'aptID' =>$this->strAptID,
				
				 'Appointment Financial Advisor' =>$this->strFsAppoinmantperson,
				 'Appointment Notes' =>$this->strAppointmentNotes,
				 'Appointment Date'=>$this->dtAppointmentDate,
				 'Appointment Time'=>$this->tmAppointmentTime,
				 'Appointment Duration'=>$this->tmAppointmentDuration,
			
				);
				
				return $resultarray;	
			
			}

		public function getName()
			{
				return("Applicant FS Appointment Details");
			}

}
?>