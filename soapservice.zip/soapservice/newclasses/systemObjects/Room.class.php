<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Room extends EntityBase implements  IEntityObject 
{
	public $strRoomName="Rooms Name displayed here";
	public $strDescription="Room Description displayed here";
	public $imgRoomImage="Room Image displayed here";
	public $fltRoomLength="Room Length displayed here";
	public $fltRoomWdith="Room Width displayed here";
	public function getProperties()
	{
		$resultarray = array(
		'Room Name '.$this->strRoomName => $this->strRoomName,
		'Descriptions '.$this->strRoomName => $this->strDescription,
		'Dimensions '.$this->strRoomName => $this->fltRoomLength.$this->fltRoomWdith,
		
		);
		

		
		return $resultarray;	
	
	}
	public function getImages()
	{
		$resultArray = array
		(
			
			'Room Image'=>$this->imgRoomImage	
			
		);
		return $resultArray;	
	
		
	}
	public function getName()
	{
		return("Room");
	}
}
?>