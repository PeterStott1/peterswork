<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class applicant extends EntityBase implements IEntityObject 
{
	public $strAddress = "Applicant Address String displayed here";
	public $strAddressBlock = "Applicant Address Block displayed here";
	public $strAddressNo = "Applicant Address Number displayed here";
	public $strAddressname = "Applicant Address Name displayed here";
	public $strAddressRoad = "Applicant Address Road displayed here";
	public $strAddressLine1 = "Applicant Address Line 1 displayed here";
	public $strAddressLine2 = "Applicant Address Line 2 displayed here";
	public $strAddressLine3 = "Applicant Address Line 3 displayed here ";
	public $strAddressTown = "Applicant Address Town displayed here";
	public $strAddressCounty = "Applicant Address County displayed here";
	public $strAddressCountry = "Applicant Address Country displayed here";
	public $strPostCode = "Applicants Address Post Code displayed here";
	public $strHomePhone = "Applicant Home No: displayed here";
	public $strBusPhone = "Applicant Business No: displayed here";
	public $strFaxNo="Applicant Fax No: displayed here";
	public $strMobileNo="Applicant Mobile No: displayed here";
	public $strEmail="Applcant Email Address: displayed here";
	public $strSalutation="Applicant Salutation: displayed here";
	public $strCompanyName="Applicant Company Name: displayed here";
	public $strNegotiator="Negotiator Linked to this Applicant: displayed here";
	public $strApplicantNo = "Applicant Key: displayed here";
	public $strApplicantId = "Applicant ID displayed here";	
	public $strApplicantName = "Concatenation of Applicant Name: displayed here";
	public $strApplicantAllowSms ="Applicant SMS Available"; 
	public $strApplicantAllowPost="Applicant Post Available"; 
	public $strApplicantAllowEmail = "Applicant Email Available";
	public $strApplicantNms = "Applicant MMS Available";
	public $strApplicantAllowPhone = "Applicant Phone Available";
	public $strAppliacantUsername = "Applicant Profile Username: displayed here";
	public $strApplicantPassword = "Applicant Profile Password: displayed here";	
	public $strJAHomePhone = "Joint Applicant Home No: displayed here";
	public $strJABusPhone = "Joint Applicant Business No: displayed here";
	public $strJAFaxNo="Joint Applicant Fax No: displayed here";
	public $strJAMobileNo="Joint Applicant Mobile No: displayed here";
	public $strJAEmail="Joint Applcant Email Address: displayed here";
	public $strJASalutation="Joint Applicant Salutation: displayed here";
	public $strJApplicantName = "Concatenation of Joint Applicant Name: displayed here";
	public $strJApplicantAllowSms ="Joint Applicant SMS Available"; 
	public $strJApplicantAllowPost="Joint Applicant Post Available"; 
	public $strJApplicantAllowEmail = "Joint Applicant Email Available";
	public $strJApplicantNms = "Joint Applicant MMS Available";
	public $strJApplicantAllowPhone = "Joint Applicant Phone Available";
	public $strJAppliacantUsername = "Joint Applicant Profile Username: displayed here";
	public $strJApplicantPassword = "Joint Applicant Profile Password: displayed here";
	public $strApplicantCompanyName = "Company Name: displayed here";
	public $strNotes = "Applicant notes displayed here";
	public $dtDateEntered = "01.10.2000";
	public $dtDateLChanged = "01.10.2000";
	public $strapplicantRefId = "0";
	public $strBranchId = "Branch Applicant Assigned to: displayed here";
	public $strActive = "Applicant Active Indicator displayed here";
	public $shareInfo = "0";
	public $applicantCurrentPosition = "0";
	public $strAlert = "Applicant Elected for Auto Alert: displayed here";
	public $strAddedPm = "1";
		
	public function getProperties()
	{
		
	
		//@@before we go to array set up values or manipulate where necessary
		$strTemp = $this->strAddressname.", ".$this->strAddressNo.", ".$this->strAddressRoad.", ".$this->strAddressLine1.", ".$this->strAddressLine2.", ".$this->strAddressLine3.", ".$this->strAddressTown.", ".$this->strAddressCounty.", ".$this->strPostCode.", ".$this->strAddressCountry;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
			'Applicant Salutation' => $this->strSalutation,
			'Address Block'=>$this->strAddressBlock,
			'Address String' => $this->strAddress,
			'Applicant Home phone number' => $this->strHomePhone,
			'Applicant Fax number' => $this->strFaxNo,
			'Applicant Business phone number'=> $this->strBusPhone,
			'Applicant Mobile number'=>$this->strMobileNo,
			'Applicant Email address' => $this->strEmail,
			'Negotiators Name' => $this->strNegotiator,
			'Applicant number' => $this->strApplicantNo,
//			'Applicant Id'=> $this->strApplicantId,
			'Appliant Name' => $this->strApplicantName,
			'Applicant Allow SMS'=> $this->strApplicantAllowSms, 
			'Applicant Allow Post '=>$this->strApplicantAllowPost,
			'Applicant Allow Email '=>$this->strApplicantAllowEmail,
			'Applicant Allow MMS'=>$this->strApplicantNms,
			'Applicant Allow Phone'=>$this->strApplicantAllowPhone,
			'Applicant Alerts'=>$this->strAlert ,
			
			
			'Joint Applicant Home phone number' => $this->strJAHomePhone,
			'Joint Applicant Fax number' => $this->strJAFaxNo,
			'Joint Applicant Business phone number'=> $this->strBusPhone,
			'Joint Applicant Mobile number'=>$this->strJAMobileNo,
			'Joint Applicant Email address' => $this->strJAEmail,
			'Joint Applicant Appliant Name' => $this->strJApplicantName,
			'Joint Applicant Applicant Allow SMS'=> $this->strJApplicantAllowSms, 
			'Joint Applicant Applicant Allow Post '=>$this->strJApplicantAllowPost,
			'Joint Applicant Applicant Allow Email '=>$this->strJApplicantAllowEmail,
			'Joint Applicant Applicant Allow MMS'=>$this->strJApplicantNms ,
			'Joint Applicant Applicant Allow Phone'=>$this->strJApplicantAllowPhone,
			
			'Applicant Web Portfolio Username'=>$this->strAppliacantUsername,
			'Applicant Web Portfolio  Password'=>$this->strApplicantPassword,
			'Joint Applicant Web Portfolio Username'=>$this->strJAppliacantUsername,
			'Joint Applicant Web Portfolio Password'=>$this->strJApplicantPassword,
			
			'Address Company Name'=>$this->strApplicantCompanyName,
			'Applicant Other Information'=>$this->strNotes,
//			'Applicant Date Entered'=>$this->dtDateEntered,
//			'Applicant Date Changed'=>$this->dtDateLChanged ,
//			'Applicant Reference Id'=>$this->strapplicantRefId ,
			'Applicant Branch Name'=>$this->strBranchId,//put the branch name here!!!!!
//			'Applicant Active'=>$this->strActive ,
			'Applicant Share Information'=>$this->shareInfo ,
			'Applicant Current position'=>$this->applicantCurrentPosition ,
//			'Applicant Added Pm'=>$this->strAddedPm 
	
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Applicant Details:");
	}

	
}
?>