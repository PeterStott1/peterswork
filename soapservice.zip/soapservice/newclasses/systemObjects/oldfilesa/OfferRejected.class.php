<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OfferRejected extends EntityBase implements IEntityObject 
{
	
	public $dtRejected="Offer Rejected date displayed here";
	public $tmrejected="Offer Rejected time entered displayed here";
	public $strOfferNotes="Offer Rejected reason displayed here";
	
	
	public function getProperties()
	{
		$resultArray = array
		(	
			'Date Rejected'=>$this->dtRejected,
			'Time Entered'=>$this->tmrejected,
			'Offer Rejected Reason'=>$this->strOfferNotes,

		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Offer Rejected Details");
	}

	
}
?>