<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class PropertyList extends EntityBase implements IEntityObject 
{
	
		public $strProperty_id;
		public $strPropertyDecriptionbrief;
	
			public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$strTemp = $this->strPropertyName.", ".$this->strAddressLine1.", ".$this->strAddressLine2.", ".$this->strAddressLine3.", ".$this->strTown.", ".$this->strCounty.", ".$this->strPostcode.", ".$this->strCountry;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
			'property id'=>$this->strProperty_id,
			'property decritpion'=>$this->strPropertyDecriptionbrief
	
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Property-List".$this->strProperty_id);
	}

	
}
?>