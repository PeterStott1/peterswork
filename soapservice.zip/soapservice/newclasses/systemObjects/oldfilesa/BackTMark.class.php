<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class BackTMark extends EntityBase implements  IEntityObject 
{
	
	public $dtDate ="1";
	public $tmTime = "10:30";
	public $strSubject ="Branch Name";
	public $strNegotiator = "13 New Street, Winton, Bournemouth, BH34 TH6, Dorset, England";
	public $strNotes = "notes about the convo";
	
	
	public function getProperties()
	{
		
		$resultarray = array(
		'Back to Market Date' => $this->dtDate,
		'Back to Market Time'=>$this->tmTime,
		'Back to Market Subject'=>$this->strSubject,
		'Back to Market Subject'=>$this->strNotes,
		'Back to Market Notes'=> $this->strNegotiator
	
		);
		return $resultarray;	
	
	}
	
	public function getName()
	{
		return('Back To Market');
	}
	
	
	
}
?>