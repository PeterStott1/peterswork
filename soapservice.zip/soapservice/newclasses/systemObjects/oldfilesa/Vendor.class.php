<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class vendor extends EntityBase implements  IEntityObject 
{

	public $strHomePhone = "01202-876543";
	public $strBusPhone = "01202-678912";
	public $strFaxNo="02203786627";
	public $strMobileNo="787987986";
	public $strEmail="someone@somewhere.com";
	public $strSalutation="Dr Johnson";
	public $strVendorTitle = "Dr";
	public $strVendorFirstName = "Neil";
	public $strVendorInitial = "p";
	public $strVendorSurname = "Johnson";
	public $strJVendorTitle = "Dr";
	public $strJVendorFirstName = "Neil";
	public $strJVendorInitial = "p";
	public $strJVendorSurname = "Johnson";
	public $strCompanyName="somecompany";
	public $strVendorName = "john smith,jenny bond";
	public $strVendorNumber= "2";
	public $strVendor_allow_sms="yes"; 
	public $strVendor_allow_email="yes"; 
	public $strVendor_allow_post="yes"; 
	public $strVendor_allow_phone="yes"; 
	public $strVendor_allow_MMs="yes";
	public $strVendorUsername = "user";
    public $strVendorPassword = "passowrd"; 
    public $strBranchName = "rubric";
    public $strPropFor = "0";
    public $strVendorNotes = "some thing here";
    public $dtDateEntered ="01.01.2000";
    public $dtLastChanaged = "01.01.2000";
    public $strVendorReferenceId = "";
    public $intBranchId = "1";
    public $VendorUserRights = "1";
    public $strJVHomePhone = "01202-876543";
	public $strJVBusPhone = "01202-678912";
	public $strJVFaxNo="02203786627";
	public $strJVMobileNo="787987986";
	public $strJVEmail="someone@somewhere.com";
	public $strJVendorName = "john smith,jenny bond";
	public $strJVendor_allow_sms="yes"; 
	public $strJVendor_allow_email="yes"; 
	public $strJVendor_allow_post="yes"; 
	public $strJVendor_allow_phone="yes"; 
	public $strJVendor_allow_MMs="yes";
	public $strJVendorUsername = "user";
    public $strJVendorPassword = "passowrd"; 
	
	public function getProperties()
	{
		// here is where we split and concantate the string as well as block address string
		$resultArray = array
		(
		    'Vendor Name'=>$this->strVendorName,
		    'Vendor Title'=>$this->strVendorTitle,
		    'Vendor Firstname'=>$this->strVendorFirstName,
		    'Vendor Initial'=>$this->strVendorInitial,
		    'Vendor Surname'=>$this->strVendorSurname,
			'General Vendor Salutation' => $this->strSalutation,
			'Vendor Home Number' => $this->strHomePhone,
			'Vendor Business Number'=>$this->strBusPhone ,
			'Vendor Fax number' => $this->strFaxNo,
			'Vendor Mobile Number'=>$this->strMobileNo,
			'Vendor Email Address' => $this->strEmail,
			'Vendor Property Company Name' => $this->strCompanyName, 
			'Vendor Allow SMS'=>$this->strVendor_allow_sms,
			'Vendor Allow Email'=>$this->strVendor_allow_email,
			'Vendor Allow Post'=>$this->strVendor_allow_post,
			'Vendor Allow Phone'=>$this->strVendor_allow_phone,
			'Vendor Allow MMS'=>$this->strVendor_allow_MMs,
			'Vendor Web Profile Username'=>$this->strVendorUsername , 
			'Vendor Web Profile Password'=>$this->strVendorPassword ,
			//if it is one if zero is sale need to add the new function
			
			'Joint Vendor Name'=>$this->strJVendorName,
			'Joint Vendor Title'=>$this->strJVendorTitle,
		    'Joint Vendor Firstname'=>$this->strJVendorFirstName,
		    'Joint Vendor Initial'=>$this->strJVendorInitial,
		    'Joint Vendor Surname'=>$this->strJVendorSurname,
			'Joint Vendor Business Number'=>$this->strJVBusPhone,
			'Joint Vendor Home Number' => $this->strJVHomePhone,
			'Joint Vendor Fax Number' => $this->strJVFaxNo,
			'Joint Vendor Mobile Number'=>$this->strJVMobileNo,
			'Joint Vendor Email Address' => $this->strJVEmail,
			'Joint Vendor Allow SMS'=>$this->strJVendor_allow_sms,
			'Joint Vendor Allow Email'=>$this->strJVendor_allow_email,
			'Joint Vendor Allow Post'=>$this->strVendor_allow_post,
			'Joint Vendor Allow Phone'=>$this->strVendor_allow_phone,
			'Joint Vendor Allow MMS'=>$this->strVendor_allow_MMs,
			'Joint Vendor Web Profile Username'=>$this->strJVendorUsername , 
			'Joint Vendor Web Profile Password'=>$this->strJVendorPassword , 
			'General Vendor Branch Name'=>$this->strBranchName, 
			'Property For: Sale or Let'=>$this->strPropFor, 
			'General Vendor Notes'=>$this->strVendorNotes , 
//			'Vendor date Entered'=>$this->dtDateEntered ,
//			'Vendor Last Changed'=>$this->dtLastChanaged , 
			'General Vendor Internal Reference No'=>$this->strVendorReferenceId , 
			//search on the lib_branch for the value of branch id
			//'General Vendor Branch'=>$this->intBranchId, 
			//@@need to look at lib_br_staff for the negotiator
			'General Vendor Negotiator'=>$this->VendorUserRights , 
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Vendor :".$this->strSalutation);
	}

	
}
?>