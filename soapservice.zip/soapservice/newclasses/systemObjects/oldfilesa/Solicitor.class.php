<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Solicitor extends EntityBase implements  IEntityObject 
{
	
	public $strContactName="someone";
	public $strAddress = "Flat 2, Elizabeth Court, 445, Lorne Park Road, Westbourne, Bournemouth, Dorset, BH1 1JN";
	public $strPhoneNumber = "01202 897345";
	

	
	public function getProperties()
	{
		$resultarray = array(
		'contact name' => $this->strContactName,
		'Address' => $this->strAddress,
		'Phone number' => $this->strPhoneNumber
		);
		

		
		return $resultarray;	
	
	}
	
	
	public function getName()
	{
		return("Solicitor");
	}

	
}
?>