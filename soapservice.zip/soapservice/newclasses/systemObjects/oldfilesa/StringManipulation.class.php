<?

class StringManipulation
{
	static public function CheckforCommaFields($strTemp)
	{
		$strResult_array = explode(", " , $strTemp);
		$arrayLength = count($strResult_array); 
		$boolFirst = true;
			for($i=0;$i<=$arrayLength;$i++)
			{
				if(!empty($strResult_array[$i]))
				{
					if(!$boolFirst)
					{	
						$strResult .= ", ";	
					}
					$boolFirst = false;
					$strResult .= $strResult_array[$i];
				}
			}
			return $strResult;
	}
	static public function MakeBlock($strTemp)
	{
		
		$strResult_array = explode(", " , $strTemp);
		$arrayLength = count($strResult_array); 
		$boolFirst = true;
			for($i=0;$i<=$arrayLength;$i++)
			{
				if(!empty($strResult_array[$i]))
				{
					if(!$boolFirst)
					{	
						$strResult .= " ";	
					}
					$boolFirst = false;
					$strResult .= $strResult_array[$i]."\n ";
				}
			}
			return $strResult;
	}
	static public function ConditionalConcat($strFValue,$strConcat,$strSValue)
	{
	//@@concatinate the joint applicant, solicitor, vendor, solicitor
		$strResult = $strFValue;
		if(strlen($strSValue)>3);
		{
			$strResult .= $strConcat.$strSValue; 	
		}
		return $strResult;
	}
	
}
?>