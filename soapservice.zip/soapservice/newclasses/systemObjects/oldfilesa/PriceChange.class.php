<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
 
class PriceChange extends EntityBase implements  IEntityObject 
{
	
	public $PriceId ="1";
	public $Prop_Id ="1";
	public $dtReqDate = "Price change date displayed here";
	public $tmRegTime = "Price change time displayed here";
	public $OldAmount = "Price change current amount displayed here";
	public $NewAmount = "Price change new amount displayed here";
	public $strComments = "Price change details displayed here";
	public $strNotes = "some kind of information";
	public $inttype = "19";
	public $intComp = "1";
	
	
	public function getProperties()
	{
		$resultarray = array(
		'Date required'=>$this->dtReqDate, 
		'Time Entered'=>$this->tmRegTime, 
		'price Change Old amount'=>$this->OldAmount, 
		'price Change new amount'=>$this->NewAmount, 
		'price Change comments'=>$this->strComments, 
		'price Change notes'=>$this->strNotes, 
		'price Change type'=>$this->inttype, 
		'price Change comp'=>$this->intComp 
		);
		return $resultarray;	
	}
	
	public function getName()
	{
		return("Price Change");
	}
	
	
	
}
?>