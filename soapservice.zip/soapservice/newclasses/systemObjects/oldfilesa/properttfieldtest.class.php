<?
include_once('Property.class.php');
include_once('../Config.class.php');
class properttfieldtest
{

public function __construct($conMysql)
	{
		$this->conDatabase=$conMysql;
	}
	
	
public function getProperty($intPId)
	{
		//@getting the property data from the database
		$result=$this->conDatabase->query('SELECT * FROM ven_property_info where property_id ='.$intPId);
		$row = $result->fetch($result);
		$property = new Property();
		$property->intVendorNo=$row['vendorno'];
		$property->intaskingpr=$this->CheckForEmptyValues($row['askingpr']);
		$property->strDescrition=$this->CheckForEmptyValues($row['prop_description']);
		$property->imgMainImage=Config::$ImageDirectory.$row['mainimg'];
		$property->strPropertyName=$this->CheckForEmptyValues($row['prop_name']);
		$property->strPropertyNumber=$this->CheckForEmptyValues($row['prop_no']);
		$property->strAddressLine1 = $this->CheckForEmptyValues($row['address1']); 
		$property->strAddressLine2 = $this->CheckForEmptyValues($row['address2']);
		$property->strAddressLine3 = $this->CheckForEmptyValues($row['address3']);
		$property->strTown = $this->getTown($row['town']);
		$property->strCounty = $this->getCounty($row['county']);
		$property->strPostcode = $row['postcode'];
		$property->strCountry= $this->getCounty($row['country']);
		$property->imgFloorPlan=$this->CheckForEmptyValues($this->getFloorPlan($intPId));
		$property->intPropertyId=$row['property_id'];
		$property->strBranchId =$row['branch_id']; 
		$property->strPropertyType =$this->CheckForEmptyValues($row['property_type']); 
		$property->strCommercialProperty =$this->CheckForEmptyValues($row['commerce_prop']); 
		$property->strPropertyFor =$this->CheckForEmptyValues($row['property_for']);
		$property->strPropertyBedrooms=$this->CheckForEmptyValues($row['no_beds']);
		$property->strPropertyReceptions=$this->CheckForEmptyValues($row['no_recep']);
		$property->strPropertyBathrooms=$this->CheckForEmptyValues($row['no_baths']);
		$property->strPropertyValuationPrice=$this->CheckForEmptyValues($row['valuationpr']);
		$property->strPropertyQuickSellPrice=$this->CheckForEmptyValues($row['quickspr']);
		$property->strPropertyTestMarketPrice=$this->CheckForEmptyValues($row['testmarpr']);
		$property->strOpinionPrice=$this->CheckForEmptyValues($row['opinionpr']);
		$property->strPropertyAge =$this->CheckForEmptyValues($row['property_age']); 
		$property->strPropertyView =$this->CheckForEmptyValues($row['view']);
		$property->strPropertyTenure =$this->CheckForEmptyValues($row['tenure']);
		$property->strPropertyPosseion =$this->CheckForEmptyValues($row['possession']); 
		$property->strBuyersposition =$this->CheckForEmptyValues($row['buyer_pos']); 
		$property->strPropertyClass =$this->CheckForEmptyValues($row['prop_class']); 
		$property->strCentralHeating=$this->CheckForEmptyValues($row['central_heating']); 
		$property->strVacant =$this->CheckForEmptyValues($row['vaccant']); 
		$property->strVehicleParking =$this->CheckForEmptyValues($row['veh_parking']); 
		$property->strParkingSize =$this->CheckForEmptyValues($row['parkingsize']); 
		$property->intmap_ref =$this->CheckForEmptyValues($row['map_ref']);
		$property->strOffRoadParking =$this->CheckForEmptyValues($row['off_road_park']); 
		$property->strGarage =$this->CheckForEmptyValues($row['garage']); 
		$property->strOutBuilding =$this->CheckForEmptyValues($row['out_building']); 
		$property->strSwimmingPool =$this->CheckForEmptyValues($row['swim_pool']);
		$property->strSpecialCritiria =$this->CheckForEmptyValues($row['spcriteria']); 
		$property->strGarden =$this->CheckForEmptyValues($row['garden']); 
		$property->strLargeGarden =$this->CheckForEmptyValues($row['large_garden']); 
		$property->strAdditionalInformation =$this->CheckForEmptyValues($row['add_info']); 
		$property->SquareFootage =$row['sq_footage']; 
		$property->strrentalPeriod =$row['rent_period']; 
		$property->strSalesBoardrequired =$row['sale_board_req']; 
		$property->strSalesBoard =$this->CheckForEmptyValues($row['sale_board']); 
		$property->strKeyReference =$row['key_ref']; 
		$property->strKeyHolder =$row['key_holder']; 
		$property->strSendToPropertyList =$row['sendtoproplist']; 
		$property->dtCreatedOn =$row['createdon']; 
		$property->strViewingDescription =$this->CheckForEmptyValues($row['viewingdesc']);
		$property->strViewingInformation =$this->CheckForEmptyValues($row['viewinginfo']);
		$property->strEnquirySource =$row['enquiry_source']; 
		$property->strShowPrice =$row['showprice']; 
		$property->curCurrency =$row['currency']; 
		$property->strPOA =$row['poa']; 
		$property->strPropertyDescription =$this->CheckForEmptyValues($row['viewingdesc']); 
		$property->strPropertyBand =$row['pr_band']; 
		$property->strValuationCompleted =$row['val_completed'];
		$property->strLwd =$this->CheckForEmptyValues($row['lwd']);
		$property->dtLwd =$this->CheckForEmptyValues($row['lwd_date']);
		$property->tmLwd =$this->CheckForEmptyValues($row['lwd_time']); 
		$property->strLostTo =$this->CheckForEmptyValues($row['lost_to']);
		$property->strReasonLost =$this->CheckForEmptyValues($row['lost_reason']); 
		$property->strLwdNotes =$this->CheckForEmptyValues($row['lwd_notes']);
		$property->strValutionNotes =$this->CheckForEmptyValues($row['val_notes']); 
		$property->strPropertyTarnsfer =$this->CheckForEmptyValues($row['prop_transf']);
		$property->strPropertyBranchValuer =$this->CheckForEmptyValues($row['branch_valuer']); 
		$property->strPropertyNegotiator=$this->CheckForEmptyValues($row['negotiator']); 
		$property->strArchive =$this->CheckForEmptyValues($row['archive']); 
		$property->strSalesStatus =$this->CheckForEmptyValues($row['sale_stat']); 
		$property->strPropertyInMarket =$this->CheckForEmptyValues($row['propinmarket']); 
		$property->dtPropertyAvailableDate =$this->CheckForEmptyValues($row['prop_avail_date']); 
		$property->strKitchen =$this->CheckForEmptyValues($row['kitchen']); 
		$property->strFloorNo =$this->CheckForEmptyValues($row['floorno']); 
		$property->strFlooring =$this->CheckForEmptyValues($row['Flooring']); 
		$property->boolFurnished  =$this->CheckForEmptyValues($row['furnished']); 
		$property->boolLift  =$this->CheckForEmptyValues($row['lift']); 
		$property->strPropCondition =$this->CheckForEmptyValues($row['prop_cond']);
		$property->strTube =$this->CheckForEmptyValues($row['tube']); 
		$property->strPropertyCondition =$this->CheckForEmptyValues($row['prop_cond']);
		$property->strAllowSmoker =$this->CheckForEmptyValues($row['allow_smoker']); 
		$property->strAllowStudent =$this->CheckForEmptyValues($row['allow_student']);
		$property->strAllowChildren =$this->CheckForEmptyValues($row['allow_children']);
		$property->strAllowPets =$this->CheckForEmptyValues($row['allow_pets']); 
		$property->strInstructedDate =$this->CheckForEmptyValues($row['instructed_date']); 
		$property->strpropBrief =$this->CheckForEmptyValues($row['prop_short_desc']); 
		$property->strPropDescription =$row['prop_description']; 
		$property->strPropertyNotes =$this->CheckForEmptyValues($row['notes']); 
		$property->strPropertyLive =$row['live']; 
		$property->strAdvertDescription =$row['prop_advert_desc']; 
		$property->strpropertySub =$row['property_sub']; 
		$property->strPropertyFeature =$row['feature']; 
		$property->strLocalInfo =$this->CheckForEmptyValues($row['local_info']); 
		$property->strAddressFlag =$this->CheckForEmptyValues($row['address_flag']); 
		$property->strFeatureInsertBefore =$row['fet_insert_before'];
		$property->strOtherPl =$row['othersPL'];
		$property->dtSoldDate =$this->CheckForEmptyValues($row['sold_date']); 
		$property->tmSoldTime  =$this->CheckForEmptyValues($row['sold_time']);	
		return $property;
	}
	private function CheckForEmptyValues($strRowValue)
	{
	//@validation for empty record set feilds
		$strTemp = $strRowValue;
		if($strTemp!=null)
		{
			return $strTemp;
		}
		else
		{
			$strTemp = "";
			return $strTemp;
		}
	}
	private function ConditionalConcat($strFValue,$strConcat,$strSValue)
	{
	//@@concatinate the joint applicant, solicitor, vendor, solicitor
		$strResult = $strFValue;
		if(strlen($strSValue)>3);
		{
			$strResult .= $strConcat.$strSValue; 	
		}
		return $strResult;
	}
	private function getTown($intTownId)
	{
		if(!empty($intTownId))
		{
			//get town calls to other table in the database
			$result=$this->conDatabase->query('SELECT townname FROM lib_town where townid = '.$intTownId);
			$row = $result->fetch($result);
			return $row['townname'];
		}
		else 
		{
			return $row="n/a";
		}
	
	}
	private function GetDepartment($Id)
	{
		if(!empty($Id))
		{
		$result=$this->conDatabase->query('SELECT department FROM lib_department where d_id = '.$Id);
		$row = $result->fetch($result);
		return $row['department'];
		}
		else 
		{
			return $row="";
		}
		
	}

	//@@return the data from the table based on the id set to the function
	private function getCounty($intCountyId)
	{
		if(!empty($intCountyId))
		{
		$result=$this->conDatabase->query('SELECT countyname FROM lib_county where countyid = '.$intCountyId);
		$row = $result->fetch($result);
		return $row['countyname'];
		}
		else 
		{
			return $row="";
		}
	}
	//@@return country from id in the ven_proeprty_info which is stored as an id in the table
	private function getCountry($intCountryId)
	{
		if(!empty($intCountryId))
		{
		$result=$this->conDatabase->query('SELECT countryname FROM lib_country where countryid = '.$intCountryId);
		$row = $result->fetch($result);
		return $row['countryname'];
		}
		else 
		{
			return $row="";
		}
	}
	//@@return gets the florrplan thet is stored as an id in the ven_proeprty_info table in the database
	private function getFloorPlan($intPropID)
	{
		$result=$this->conDatabase->query('SELECT img FROM prop_floor where prop_id = '.$intPropID);
		$row = $result->fetch($result);
		$image = Config::$ImageDirectory.$row['img'];
		return $image;
		
	}
	//@@return the area
	private function getArea($intID)
	{
		if(!empty($intID))
		{
			$result=$this->conDatabase->query('SELECT * FROM lib_br_area area_id = '.$intID);
			$row = $result->fetch($result);
			return $row['ar_name'];
		}
		else 
		{
			return $row="";
		}
		
	}
}

//$db=Config::CreateDbConn();	
$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3-demo'));

$tester = new properttfieldtest($db);


$property = $tester->getProperty('133');
print_r ($property->getProperties());
?>