<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OfferAccepted extends EntityBase implements IEntityObject 
{
	

	public $dtAccepted="Date accepted displayed here";
	public $tmAccepted="Time entered displayed here";
	public $strOfferNotes="Offer accepted details displayed here";
	public $strDepositPaid = "no";
	
	
	
 	
	
	public function getProperties()
	{
		$resultArray = array
		(
			'Date Accepted'=>$this->dtAccepted,
			'Time Entered'=>$this->tmAccepted,
			'Offer Acceptence Details Agreed'=>$this->strOfferNotes,
			'Deposit Paid'=>$this->strDepositPaid,
		
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Offer Acceptence Details");
	}

	
}
?>