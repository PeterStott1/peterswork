<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OutFsVendorLetter extends EntityBase implements IEntityObject 
{ 


		 public $strAptID = "1";
		 public $strFsContactId = "1";
		 public $strPropertyId = "10";
		 public $strFsAppoinmantperson = "John West";
		 public $strFsposition = "manager";
		 public $strFsComanyName = "rent b4 u buy";
		 public $strFsComanyAddress = "Flat 2, Elizabeth Court, 445, Lorne Park Road, Westbourne, Bournemouth, Dorset, BH1 1JN";
		 public $strFsCompanyPrimaryContact = "John Miller";
		 public $strVendorNegotiator = "James Gibbson";
		 public $strCompRef = "ljhukgi";
		 public $strCompanyContactName = "Financial Advisor";
		
		 
		 public function getProperties()
			{
				$resultarray = array(
				'aptID' =>$this->strAptID,
				'Property Id'=>$this->strPropertyId,
				'financial service position'=>$this->strFsposition,
				'financial service contact id'=>$this->strFsContactId,
				'financial service appointment Person'=>$this->strFsAppoinmantperson,
				'financial service contact name'=>$this->strCompanyContactName,
				'financial service company name'=>$this->strFsComanyName,
				'financial service Company address'=> $this->strFsComanyAddress,
				'financial service Primary contact'=>$this->strFsCompanyPrimaryContact,
				'financial service company reference'=>$this->strCompRef,
				'financial service Vendor Negotiator'=>$this->strVendorNegotiator		
				);
				
		
				
				return $resultarray;	
			
			}

		public function getName()
			{
				return("OutFsVendorLetter");
			}

}
?>