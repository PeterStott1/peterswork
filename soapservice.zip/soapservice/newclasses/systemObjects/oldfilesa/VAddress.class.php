<?
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class VAddress extends EntityBase implements  IEntityObject 
{
	
	public $strVendorPropNumber = "Flat 2";
	public $strVendorPropName = "Elizabeth Court";
	public $strVendorAdressLine1 = "445";
	public $strVendorRoadNo = "445";
	public $strVendorRoadName = "Lorne Park Road";
	public $strVendorAddressLine2 = "Talbot Woods";
	public $strVendorAddressLine3 = "Westbourne";
	public $strVendorAddressTown = "Bournemouth";
	public $strVendorAddressCounty = "Dorset";
	public $strVendorAddressCountry = "United Kingdom";
	public $strVendorAddressPostcode = "BH1 1JN";
	public $strVendorAddress ="Flat 2, Elizabeth Court, 445, Lorne Park Road, Westbourne, Bournemouth, Dorset, BH1 1JN";
	public $strVAddressBlock =
"Flat 2, Elizabeth Court
445
Lorne Park Road
Westbourne
Bournemouth
Dorset
BH1 1JN";
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
	
	 $strTemp = $this->strVendorPropNumber.", ".$this->strVendorPropName.", ".$this->strVendorAdressLine1.", ".$this->strVendorAddressLine2.", ".$this->strVendorAddressLine3.", ".$this->strVendorAddressTown.", ".$this->strVendorAddressCounty.", ".$this->strVendorAddressCountry.", ".$this->strVendorAddressPostcode;
	 $this->strVendorAddress = StringManipulation::CheckforCommaFields($strTemp);
	$this->strVAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
		    'Property No'=>$this->strVendorPropNumber,	  
			'Property Name'=> $this->strVendorPropName,
			//Line 1 not needed!!!!!! Anton was right :)
			'Line 1'=>$this->strVendorAdressLine1,
			'Road / Street No'=>$this->strVendorRoadNo,
			'Road / Street Name'=>$this->strVendorRoadName,
			'Line 2'=>$this->strVendorAddressLine2,			
			'Line 3'=>$this->strVendorAddressLine3,
			'Town'=>$this->strVendorAddressTown,
			'County'=>$this->strVendorAddressCounty,
			'Country'=>$this->strVendorAddressCountry,
			'Address PostCode'=>$this->strVendorAddressPostcode,
			'Address String'=> $this->strVendorAddress,
			'Address Block'=> $this->strVAddressBlock,
			
			
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Vendor Address");
	}
	
}

?>