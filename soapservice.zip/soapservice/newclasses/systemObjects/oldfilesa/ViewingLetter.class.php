<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class ViewingLetter extends EntityBase implements IEntityObject 
{ 
		
		 	public $strViewId ="1"; 
			public $strApId = "1"; 
			public $strPropId="1"; 
			public $strViewDate="01.01.2000"; 
			public $strViewTime ="10:01:10"; 
			public $strViewDuration = "30mins"; 
			public $strApplicantConfirm = "yes"; 
			public $strVendorConfirm ="Yes"; 
			public $strCanceled ="no";
			public $strCancelDate = "12-12-1220";
			public $strCancelReason = "";
			public $strComplete = "yes";
			public $strCompleteDate ="12-12-1220";
			public $strCompletedNotes  = "Some comments obout the completion";
	
		 public function getProperties()
			{
				$resultarray = array(
				 	 
					'Viewing Id' => $this->strViewId, 
					'Applicant Id' => $this->strApId, 
					'Property Id' => $this->strPropId, 
					'Viewing Date' => $this->strViewDate, 
					'Viewing Time' => $this->strViewTime, 
					'Viewing Duration' => $this->strViewDuration, 
					'Applicant Confirm' => $this->strApplicantConfirm, 
					'Vendor Confirm' => $this->strVendorConfirm,
					'Viewing cancelation'=>$this->strCanceled,
					'Viewing Cancelation date' =>$this->strCancelDate,
					'Viewing Cancelation Reason'=>$this->strCancelReason,
					'Viewing Complete'=>$this->strComplete,
					'Viewing Completion date' =>$this->strCompleteDate,
					'Viewing Completion Reason'=>$this->strCompletedNotes
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("Viewing Letter");
			}

}
?>