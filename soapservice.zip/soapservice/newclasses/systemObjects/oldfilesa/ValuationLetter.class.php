<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class ValuationLetter extends EntityBase implements IEntityObject 
{ 
		  
			public $strPropCategory = "Residental";
		    public $strPropSubCategory = "Investment property"; 
			public $strCancelDate = "01.10.2000";
			public $strLostToEstateAgent = "This was lost due to lazy consultants";
			public $strCancelReason = "sold there selves";
			public $strCancelNotes = "if we had been on the ball a bit more then we would have";
 			public $strContactDate = "01.01.2000";

		 public function getProperties()
			{
				$resultarray = array(
					'Property catergory' =>$this->strPropCategory ,
				 	'Property sub catergory' =>$this->strPropSubCategory ,
					'cancel date'=>$this->strCancelDate,
					'Lost Estate Agency'=>$this->strLostToEstateAgent,
					'Cancel reason'=>$this->strCancelReason,
					'cancel notes'=>$this->strCancelNotes,
					'Contacted date'=>$this->strContactDate,
				);
				return $resultarray;	
			}
		 
		public function getName()
			{
				return("Valuation Letter");
			}
}
?>