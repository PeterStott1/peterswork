<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
class User extends EntityBase implements  IEntityObject 
{
	//staff_id, password, first_name, 
	
	public $strUser ="John Smith";
	public $strUsername = "smithj";
	public $strPosition = "Manager";
	public $strMobileNumber = "07968564532";
	public $picImage = "img.jpg";
	public $picSignature = "sign.jpg";
	public $strBranchId = "1";
	public $strBranchPhone = "01305 774 362";
	public $strDepartment = "Sales";
	public $strEmailAddress = "somewhere@someplace";
	
	
	//@@return Get proeprties is a part of the abstract so it must be in the object or it will error dir
	public function getProperties()
	{
		$resultArray = array (
		'Name' => $this->strUser,
		'Username' => $this->strUsername,
		'Email Address'=>$this->strEmailAddress,
		'Job Title'=>$this->strPosition,
		'Mobile Phone'=>$this->strMobileNumber,
		'Branch Phone Number'=> $this->strBranchPhone,
		'Branch Id'=> $this->strBranchId,
		'Department'=>$this->strDepartment
		
		);
		
		return $resultArray;
	}
	//@@return get images again is part of the abstract class if you like a way of setting up a frame work for the coder to follow
	public function getImages()
	{
		$resultArray = array
		(
			
			'Users Picture'=>$this->picImage,
			'Users Signature'=>$this->picSignature
			
		);
		return $resultArray;	
	
		
	}
	
	public function getName()
	{
		return("User: ".$this->strUser);
	}
}
?>