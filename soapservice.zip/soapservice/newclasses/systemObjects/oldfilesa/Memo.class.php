<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Memo extends EntityBase implements  IEntityObject 
{
	
	public $dtDate ="1";
	public $strSubject ="Branch Name";
	public $strNotes = "notes about memo";
	
	
	public function getProperties()
	{
		
		$resultarray = array(
		'Conversation Date' => $this->dtDate,
		'Conversation Sunbject'=>$this->strSubject,
		'Conversation Notes'=> $this->strNotes
	
		);
		return $resultarray;	
	
	}
	
	public function getName()
	{
		return('Memo.Conversation');
	}
	
	
	
}
?>