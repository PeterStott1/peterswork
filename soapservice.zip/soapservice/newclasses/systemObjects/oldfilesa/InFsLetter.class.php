<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class InFsLetter extends EntityBase implements  IEntityObject 
{ 

		 public $strAptID  ="1";
		 public $strFsAppoinmantperson = "Financial Advisors Name";
//		 public $strApplicantId = '4';
		 public $strAppointmentNotes = 'The appointments notes displayed here';
		 public $dtAppointmentDate = 'Appointment date displayed here';
		 public $tmAppointmentTime = 'Appointment time displayed here';
		 public $tmAppointmentDuration = 'Appointment duration displayed here';
		
		 
		 public function getProperties()
			{
				$resultarray = array(
//				'aptID' =>$this->strAptID,
				
				 'appointment person' =>$this->strFsAppoinmantperson,
				 'appointment notes' =>$this->strAppointmentNotes,
				 'appointment dates'=>$this->dtAppointmentDate,
				 'appointment time'=>$this->tmAppointmentTime,
				 'appointment duration'=>$this->tmAppointmentDuration,
			
				);
				
				return $resultarray;	
			
			}

		public function getName()
			{
				return("Applicant FS Appointment Details");
			}

}
?>