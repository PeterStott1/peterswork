<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class TermsAgency extends EntityBase implements  IEntityObject 
{
	public $strTermsId = "Term ID displayed here";         
	public $strCommisionRate = "Commission Agreed displayed here";    
	public $strFmFee = "Fixed Fee Agreed displayed here";            
	public $strTermNotes = "Term Notes displayed here";        
	public $strAgencyType = "Agency Type displayed here";      
	public $strJointAgent = "Joint Agent ID displayed here";
	public $strAgencyPeriod = "Agency Period Agreed displayed here";    
	public $strPropId ="Property ID displayed here";
	public $strSplitCommission = "Split Commission Agreed  displayed here";

	
		
	function getName()
	{
		return("Terms & Agency Details");
	}

	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		//$strTemp = 
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		//@@now build the properties for this object

		$resultArray = array
		(
			'Agency Period'=>$this->strAgencyPeriod,
			'Agency Type'=>$this->strAgencyType,
			'Agreed Fixed Fee'=>$this->strFmFee,
			'Agreed Commission Rate'=>$this->strCommisionRate,
			'Agreed Split Commission'=>$this->strSplitCommission,
			'Term & Agency Notes' => $strTermNotes,
			'Your Fee' => $????????????????? *** Dynamically picking up the item that has a value not equal to zero
		);
		return $resultArray;	
	
	}
	
//	public function getImages()
//	{
//		$resultArray = array
//		(
//			
//			
//			
//		);
//		return $resultArray;	
//	
//		
//	}
	
	


}
?>