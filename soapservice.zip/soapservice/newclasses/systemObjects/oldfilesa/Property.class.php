<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class Property extends EntityBase implements  IEntityObject 
{
	public  $intPropertyId="0";
	public  $intVendorNo="0";
	public  $strPropertyName = "The willows";
	public  $strPropertyNumber = "123";
	public  $strAddressLine1 = "fake ";
	public  $strAddressLine2 = "street";
	public  $strAddressLine3 = "old poole town";
	public  $strAddressRoad = "will close";
	public  $strTown = "Poole";
	public  $strPostcode = "bh15 1rp";
	public  $strCounty = "Dorset";
	public  $strCountry = "England";
 	public 	$strAddress = "Flat 2, Elizabeth Court, 445, Lorne Park Road, Westbourne, Bournemouth, Dorset, BH1 1JN";
	public  $strAddressBlock = "Flat 2\n Elizabeth Court\n 445\n, Lorne Park Road\n, Westbourne\n, Bournemouth\n, Dorset\n, BH1 1JN\n";
 	public 	$strDescrition = "large open plan property with open view vista of bournemouth beach";
	public  $intaskingpr ="150,000.00";
	public  $imgFloorPlan = "property-photo-big.jpg";
	public 	$imgMainImage = "prop-photo.jpg";
	public 	$strBranchId = "1";
	public  $strPropertyType = "2";
	public 	$strCommercialProperty = "1";
	public  $strPropertyFor =""; 
	public  $strPropertyBedrooms=""; 
	public  $strPropertyReceptions=""; 
	public  $strPropertyBathrooms=""; 
	Public  $strOpinionPrice = "2308725";
	public  $strPropertyValuationPrice=""; 
	public  $strPropertyQuickSellPrice="";
	public  $strPropertyTestMarketPrice="";
	public 	$strPropertyAge = "33";
	public  $strPropertyView ="0";
	public  $strPropertyTenure ="1";
	public  $strPropertyPosseion = "5";
	public  $strBuyersposition = "0";
	public  $strPropertyClass = "0";
	public  $strCentralHeating= "0";
	public  $strVacant = "0";
	public 	$strVehicleParking = "0";
	public  $strParkingSize = "0";
	public 	$intmap_ref ="0";
	public  $strOffRoadParking = "0";
	public 	$strGarage = "0";
	public  $strOutBuilding = "0";
	public  $strSwimmingPool = "0";
	public  $strSpecialCritiria = "0";
	public 	$strGarden = "0";
	public  $strLargeGarden = "0"; 
	public  $strAdditionalInformation = "stuff for this property will be held at the branch";
	public 	$SquareFootage = "0";
	public  $strrentalPeriod = "2";
	public  $strSalesBoardrequired = "2";
	public  $strSalesBoard = "1";
	public  $strKeyReference = "244kk";
	public  $strKeyHolder = "key in office";
	public  $strSendToPropertyList = "0";
	public  $dtCreatedOn = "01.01.2000";
	public  $strViewingDescription = "some thing to decribe the view";
	public  $strViewingInformation ="some think else in here";
	public  $strEnquirySource = "2";
	public  $strShowPrice = "2";
	public  $curCurrency = "1";
	public  $strPOA = "1";
	public  $strPropertyDescription = "2";
	public  $strPropertyBand = "2";
	Public  $strValuationCompleted = "0";
	public  $strLwd = "0";
	public  $dtLwd = "01.01.2000";
	public  $tmLwd = "12:12:12";
	public  $strLostTo = "2";
	public  $strReasonLost = "poor show";
	public  $strLwdNotes = "stuff about this tag";
	public  $strValutionNotes = "good property we can sell";
	public  $strPropertyTarnsfer = "1";
	public  $strPropertyBranchValuer = "1";
	public  $strPropertyNegotiator= "anton";
	public  $strArchive = "1";
	public  $strSalesStatus = "0";
	public  $strPropertyInMarket = "1";
	public  $dtPropertyAvailableDate = "01.01.2000";
	public  $strKitchen = "1";
    public  $strFloorNo = "2";
    public  $strFlooring = "3";
    public  $boolFurnished  = "false";
    public  $boolLift  = "false";
    public  $strPropCondition ="good";
    public  $strTube = "1";
    public  $strAllowSmoker = "false";
	public  $strAllowStudent = "false";
	public  $strAllowChildren = "false";
	public  $strAllowPets = "false";
	public  $strInstructedDate = "12.01.2007";
	public  $strpropBrief = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses";
	public  $strPropDescription = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";	
	public  $strPropertyNotes = "smoit in here";
	public  $strPropertyLive = "0";
	public  $strAdvertDescription = "just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential";
	public  $strpropertySub = "3";
	public  $strPropertyFeature = "2";
	public  $strLocalInfo = "something in here";
	public  $strFeatureInsertBefore = "0";
	public  $strOtherPl = "0";
	public  $dtSoldDate = "01.01.2000";
	public  $tmSoldTime  ="12:12:12";
	
	function getName()
	{
		return("Property ".$this->strPropertyId);
	}

	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$strTemp = $this->strPropertyName.", ".$this->strAddressRoad.", ".$this->strAddressLine1.", ".$this->strAddressLine2.", ".$this->strAddressLine3.", ".$this->strTown.", ".$this->strCounty.", ".$this->strPostcode.", ".$this->strCountry;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		//@@now build the properties for this object

		$resultArray = array
		(
			//split out the individual address line for the users see correspondence address steal it!!
			'Property Key'=>$this->intPropertyId,
//			'Property Vendor Number'=>$this->intVendorNo,
			'Property Address Number'=>$this->strPropertyNumber,
			'Property Address Town' => $this->strTown,
			'Property Address Postcode' =>$this->strPostcode,
			'Property Address County' => $this->strCounty,
			'Property Address Country' => $this->strCountry,
			'Property Address String'=>$this->strAddress,
			'Property Address Road'=>$this->strAddressRoad,
			'Property Address Block'=>$this->strAddressBlock,
			// Descriptions need to be individual as well as a concatenate of all descriptions into 1 string!
			//being moved to brochure object
//			'Descriptions Property'=>$this->strDescrition, 
			'Descriptions Brief'=>$this->strpropBrief ,
			'Descriptions Full'=>$this->strPropertyDescription ,
			'Descriptions Adverteristing'=>$this->strAdvertDescription , 
			'Property Description'=>$this->strPropDescription ,

//			'Property Branch Id'=>$this->strBranchId , 
			'Selling Criteria Category'=>$this->strPropertyType ,
			'Selling Criteria Sub Category'=>$this->strCommercialProperty , 
//			'Property For'=>$this->strPropertyFor ,
			'Selling Criteria Bedrooms'=>$this->strPropertyBedrooms,
			'Selling Criteria Receptions'=>$this->strPropertyReceptions,
			'Selling Criteria Bathrooms'=>$this->strPropertyBathrooms,
			'Library Pricing Asking price'=>$this->intaskingpr ,
			'Library Pricing Vendor Opinion'=>$this->strOpinionPrice ,
			'Library Pricing Valuation'=>$this->strPropertyValuationPrice,
			'Library Pricing Quick Sell'=>$this->strPropertyQuickSellPrice,
			'Library Pricing Test Market'=>$this->strPropertyTestMarketPrice,
			'General Detail Age'=>$this->strPropertyAge ,
			'General Detail View Requirements'=>$this->strPropertyView ,
			'Selling Criteria Tenure'=>$this->strPropertyTenure ,
			'General Detail Possession'=>$this->strPropertyPosseion , 
			'General Detail Vendor Position'=>$this->strBuyersposition , 
			'General Detail Price Band'=>$this->strPropertyClass , 
//			'Property Central Heating'=>$this->strCentralHeating,
//			'Property Vacant'=>$this->strVacant , 
//			'Property Vehicle parking'=>$this->strVehicleParking , 
//			'Property Parking Size'=>$this->strParkingSize , 
//			'Property Map Ref'=>$this->intmap_ref ,
//			'Property off road parking'=>$this->strOffRoadParking ,
//			'Property Garage'=>$this->strGarage ,
//			'Property Out buildings'=>$this->strOutBuilding ,
//			'Property Swimmming Pool'=>$this->strSwimmingPool , 
			'Selling Criteria '=>$this->strSpecialCritiria , 
//			'Property Garden'=>$this->strGarden ,
//			'Property large Garden'=>$this->strLargeGarden ,
			'General Detail Additional Information'=>$this->strAdditionalInformation , 
			'General Detail Square footage'=>$this->SquareFootage ,
			'Rental Criteria Period'=>$this->strrentalPeriod ,
			'General Detail Board required'=>$this->strSalesBoardrequired , 
			'Property Sales Board'=>$this->strSalesBoard ,
			'Property key reference'=>$this->strKeyReference , 
			'Property key Holder'=>$this->strKeyHolder ,
			'Property send to property list'=>$this->strSendToPropertyList ,
			'Property Created On'=>$this->dtCreatedOn ,
//			'Property Viewing Description'=>$this->strViewingDescription ,
			'Property Viewing Information'=>$this->strViewingInformation ,
			'Property Enquiry source'=>$this->strEnquirySource ,
			'Property show price'=>$this->strShowPrice ,
//			'Property Currency'=>$this->curCurrency ,
//			'Property POA'=>$this->strPOA ,
		
			'Property Band'=>$this->strPropertyBand ,
			'Property Valuation Completed'=>$this->strValuationCompleted ,
//			'Property LWD'=>$this->strLwd , 
//			'Property date of LWD'=>$this->dtLwd ,
//			'Property Time of LWD'=>$this->tmLwd , 
			'Property lost to'=>$this->strLostTo , 
			'Property Reason lost'=>$this->strReasonLost ,
			'Property LWD notes'=>$this->strLwdNotes , 
			'Property valuation notes'=>$this->strValutionNotes , 
			'Property Transfer'=>$this->strPropertyTarnsfer , 
			'Property Branch Valuer'=>$this->strPropertyBranchValuer ,
			'Property Negotiator'=>$this->strPropertyNegotiator, 
			'Property Archive'=>$this->strArchive , 
			'Property Sales Status'=>$this->strSalesStatus ,
			'Property In Market'=>$this->strPropertyInMarket ,
			'Rental Criteria Date Available from'=>$this->dtPropertyAvailableDate, 
			'Rental Criteria Kitchen Y/N'=>$this->strKitchen,
		    'Rental Criteria Floor No'=>$this->strFloorNo,
		    'Rental Criteria Type of Flooring'=>$this->strFlooring,
		    'Rental Criteria Furnished Y/N'=>$this->boolFurnished,
		    'Rental Criteria Lift Y/N'=>$this->boolLift, 
		    'Rental Criteria Condition'=>$this->strPropCondition,
		    'Rental Criteria Tube'=>$this->strTube,
		    'Rental Criteria Property Allow Smoker'=>$this->strAllowSmoker,
			'Rental Criteria Property Allow Student'=>$this->strAllowStudent,
			'Rental Criteria Property Allow Children'=>$this->strAllowChildren,
			'Rental Criteria Property Allow pets'=>$this->strAllowPets, 
			'Property Instructed date'=>$this->strInstructedDate , 
			
		
			'Property Notes'=>$this->strPropertyNotes ,
			'Property Live'=>$this->strPropertyLive ,
			
			'Property sub'=>$this->strpropertySub , 
			'Property Feature'=>$this->strPropertyFeature ,
			'Property local information'=>$this->strLocalInfo , 
			'Property feature Insert before'=>$this->strFeatureInsertBefore, 
			'Property OtherPl'=>$this->strOtherPl, 
			'Property date sold'=>$this->dtSoldDate, 
			'Property sold Time'=>$this->tmSoldTime
			
			
		);
		return $resultArray;	
	
	}
	
	public function getImages()
	{
		$resultArray = array
		(
			
			'Floor plan' => $this->imgFloorPlan,
			'Image'=>$this->imgMainImage
			
		);
		return $resultArray;	
	
		
	}
	
	


}
?>