<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class PropertyLetter extends EntityBase implements IEntityObject 
{ 
		
		
		 public $fltCommisionRate = "10";
		 public $boolsplitCommission = "0";
		 public $CurFixedFee = "1,500";
		 public $dtLeaseComenceDate = "01.01.2007";
		 public $IntLeaseNoYears = "2";
		 public $curLeaseGroundRent = "23";
		 public $boolLeasegroundFixed ="yes";
		 public $curLeaseMaintenanceCharge = "500";
		 public $boolCopyLeaseAvailable = "yes";
		 public $boolLeaseInsuranceIncluded = "yes";
		 public $strLeaseManagementCompany = "collins maintenance crew";
		 public $boolLeaseSittingTenants = "no";
		 public $strAgencyType = "Sole Agency";
		 public $strAgencyPeriod = "6 weeks";		 	
		
		 public function getProperties()
			{
				$resultarray = array(
				 'commision rate' =>$this->fltCommisionRate ,
				 'split commission' =>$this->boolsplitCommission ,
				 'fixed fee' =>$this->CurFixedFee ,
				 'Date Lease commences' =>$this->dtLeaseComenceDate ,
				 'Lease years' =>$this->IntLeaseNoYears ,
				 'lease ground rent' =>$this->curLeaseGroundRent ,
				 'lease ground fixed' =>$this->boolLeasegroundFixed ,
				 'lease maintenance charge' =>$this->curLeaseMaintenanceCharge ,
				 'Lease available' =>$this->boolCopyLeaseAvailable ,
				 'lease insurance included' =>$this->boolLeaseInsuranceIncluded ,
				 'Lease management company' =>$this->strLeaseManagementCompany ,
				 'lease sitting tenants' =>$this->boolLeaseSittingTenants ,
				 'agency type' =>$this->strAgencyType,
				 'agency period' =>$this->strAgencyPeriod  
				);
				return $resultarray;	
			}
		 
		public function getName()
			{
				return("Property Letter");
			}

}
?>