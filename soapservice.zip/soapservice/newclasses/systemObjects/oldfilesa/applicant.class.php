<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class applicant extends EntityBase implements IEntityObject 
{
	public $strAddress = "Applicant address: displayed here";
	public $strAddressBlock = "Applicant address: displayed here";
	public $strAddressNo = "Applicant Address Number";
	public $strAddressname = "Applicant Address Name";
	public $strAddressRoad = "Applicant Address Road";
	public $strAddressLine1 = "Applicant Line 1";
	public $strAddressLine2 = "Applicant Address line 2 ";
	public $strAddressLine3 = "Applicant Address line 3 ";
	public $strAddressTown = "Applicant Address Town";
	public $strAddressCounty = "Applicant Address County";
	public $strAddressCountry = "Applicant Address Country";
	public $strPostCode = "Applicants Address PostCode";
	public $strHomePhone = "Applicant Home No: displayed here";
	public $strBusPhone = "Applicant Business No: displayed here";
	public $strFaxNo="Applicant Fax No: displayed here";
	public $strMobileNo="Applicant Mobile No: displayed here";
	public $strEmail="Applcant Email Address: displayed here";
	public $strSalutation="Applicant Salutation: displayed here";
	public $strCompanyName="Applicant Company Name: displayed here";
	public $strNegotiator="Negotiator Linked to this Applicant: displayed here";
	public $strApplicantNo = "Applicant Key: displayed here";
	public $strApplicantId = "1";	
	public $strApplicantName = "Concatenation of Applicant Name: displayed here";
	public $strApplicantAllowSms ="Applicant SMS Available"; 
	public $strApplicantAllowPost="yes"; 
	public $strApplicantAllowEmail = "yes";
	public $strApplicantNms = "yes";
	public $strApplicantAllowPhone = "yes";
	public $strAppliacantUsername = "Applicant Profile Username: displayed here";
	public $strApplicantPassword = "Applicant Profile Password: displayed here";	
	public $strJAHomePhone = "Joint Applicant Home No: displayed here";
	public $strJABusPhone = "Joint Applicant Business No: displayed here";
	public $strJAFaxNo="Joint Applicant Fax No: displayed here";
	public $strJAMobileNo="Joint Applicant Mobile No: displayed here";
	public $strJAEmail="Joint Applcant Email Address: displayed here";
	public $strJASalutation="Joint Applicant Salutation: displayed here";
	public $strJApplicantName = "Concatenation of Joint Applicant Name: displayed here";
	public $strJApplicantAllowSms ="yes"; 
	public $strJApplicantAllowPost="yes"; 
	public $strJApplicantAllowEmail = "yes";
	public $strJApplicantNms = "yes";
	public $strJApplicantAllowPhone = "yes";
	public $strJAppliacantUsername = "Joint Applicant Profile Username: displayed here";
	public $strJApplicantPassword = "Joint Applicant Profile Password: displayed here";
	public $strApplicantCompanyName = "Company Name: displayed here";
	public $strNotes = "Applicant notes displayed here";
	public $dtDateEntered = "01.10.2000";
	public $dtDateLChanged = "01.10.2000";
	public $strapplicantRefId = "0";
	public $strBranchId = "Branch Applicant Assigned to: displayed here";
	public $strActive = "1";
	public $shareInfo = "0";
	public $applicantCurrentPosition = "0";
	public $strAlert = "Applicant Elected for Auto Alert: displayed here";
	public $strAddedPm = "1";
		
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$strTemp = $this->strPropertyName.", ".$this->strAddressLine1.", ".$this->strAddressLine2.", ".$this->strAddressLine3.", ".$this->strTown.", ".$this->strCounty.", ".$this->strPostcode.", ".$this->strCountry;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
			'Applicant Salutation' => $this->strSalutation,
			'Applicant Home phone number' => $this->strHomePhone,
			'Address String' => $this->strAddress,
			'Address Block'=>$this->strAddressBlock,
			'Applicant Fax number' => $this->strFaxNo,
			'Applicant Business phone number'=> $this->strBusPhone,
			'Applicant Mobile Phone number'=>$this->strMobileNo,
			'Applicant Email address' => $this->strEmail,
			'Company Negotiator' => $this->strCompanyName,
			'Applicant number' => $this->strApplicantNo,
//			'Applicant Id'=> $this->strApplicantId,
			'Appliant Name' => $this->strApplicantName,
			'Applicant Allow SMS'=> $this->strApplicantAllowSms, 
			'Applicant Allow Post '=>$this->strApplicantAllowPost,
			'Applicant Allow Email '=>$this->strApplicantAllowEmail,
			'Applicant Allow Nms'=>$this->strApplicantNms,
			'Applicant Allow Phone'=>$this->strApplicantAllowPhone,
			'Applicant Alerts'=>$this->strAlert ,
			
			
			'Joint Applicant Home phone number' => $this->strJAHomePhone,
			'Joint Applicant Fax number' => $this->strJAFaxNo,
			'Joint Applicant Business phone number'=> $this->strBusPhone,
			'Joint Applicant Mobile Phone number'=>$this->strJAMobileNo,
			'Joint Applicant Email address' => $this->strJAEmail,
			'Joint Applicant Appliant Name' => $this->strJApplicantName,
			'Joint Applicant Applicant Allow SMS'=> $this->strJApplicantAllowSms, 
			'Joint Applicant Applicant Allow Post '=>$this->strJApplicantAllowPost,
			'Joint Applicant Applicant Allow Email '=>$this->strJApplicantAllowEmail,
			'Joint Applicant Applicant Allow Nms'=>$this->strJApplicantNms ,
			'Joint Applicant Applicant Allow Phone'=>$this->strJApplicantAllowPhone,
			
			'Applicant Web Portfolio Username'=>$this->strAppliacantUsername,
			'Applicant Web Portfolio  Password'=>$this->strApplicantPassword,
			'Joint Applicant Web Portfolio Username'=>$this->strJAppliacantUsername,
			'Joint Applicant Web Portfolio Password'=>$this->strJApplicantPassword,
			
			'Address Company Name'=>$this->strApplicantCompanyName,
			'Applicant Other Information'=>$this->strNotes,
//			'Applicant Date Entered'=>$this->dtDateEntered,
//			'Applicant Date Changed'=>$this->dtDateLChanged ,
//			'Applicant Reference Id'=>$this->strapplicantRefId ,
			'Applicant Branch Name'=>$this->strBranchId,//put the branch name here!!!!!
//			'Applicant Active'=>$this->strActive ,
			'Applicant Share Information'=>$this->shareInfo ,
			'Applicant Current position'=>$this->applicantCurrentPosition ,
//			'Applicant Added Pm'=>$this->strAddedPm 
	
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Applicant Details".$this->strSalutation);
	}

	
}
?>