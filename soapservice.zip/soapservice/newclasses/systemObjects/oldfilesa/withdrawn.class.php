<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class TermsAgency extends EntityBase implements  IEntityObject 
{
	public $strSubject = "Withdrawal Subject displayed here";         
	public $strNote = "Withdrawal Notes displayed here";    
	public $strNegotiator = "Withdrawal Negotiator displayed here";            
	public $strDate = "Date of Withdrawal displayed here";        
	
	
		
	function getName()
	{
		return("Withdrawn Details");
	}

	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		//$strTemp = 
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		//@@now build the properties for this object

		$resultArray = array
		(
			'Withdrawal Subject'=>strSubject,
			'Withdrawal Notes'=>$strNote,
			'Withdrawal Negotiator'=>strNegotiator,
			'Date of Withdrawal'=>$strDate,
			
		);
		return $resultArray;	
	
	}
	
//	public function getImages()
//	{
//		$resultArray = array
//		(
//			
//			
//			
//		);
//		return $resultArray;	
//	
//		
//	}
	
	


}
?>