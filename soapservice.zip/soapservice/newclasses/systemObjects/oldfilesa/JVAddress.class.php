<?
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class JVAddress extends EntityBase implements  IEntityObject 
{
	
	public $strJVendorPropNumber = "Flat 2";
	public $strJVendorPropName = "Elizabeth Court";
	public $strJVendorAdressLine1 = "445";
	public $strJVendorRoadNo = "445";
	public $strJVendorRoadName = "Lorne Park Road";
	public $strJVendorAddressLine2 = "Talbot Woods";
	public $strJVendorAddressLine3 = "Westbourne";
	public $strJVendorAddressTown = "Bournemouth";
	public $strJVendorAddressCounty = "Dorset";
	public $strJVendorAddressCountry = "United Kingdom";
	public $strJVendorAddressPostcode = "BH1 1JN";
	public $strJVendorAddress ="Flat 2, Elizabeth Court, 445, Lorne Park Road, Westbourne, Bournemouth, Dorset, BH1 1JN";
	public $strJVAddressBlock =
"Flat 2 Elizabeth Court\n
445 Lorne Park Road\n
Westbourne\n
Bournemouth\n
Dorset\n
BH1 1JN\n";
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
	
	 $strTemp = $this->strJVendorPropNumber.", ".$this->strJVendorPropName.", ".$this->strJVendorAdressLine1.", ".$this->strJVendorAddressLine2.", ".$this->strJVendorAddressLine3.", ".$this->strJVendorAddressTown.", ".$this->strJVendorAddressCounty.", ".$this->strJVendorAddressCountry.", ".$this->strJVendorAddressPostcode;
	$this->strJVendorAddress = StringManipulation::CheckforCommaFields($strTemp);
	$this->strJVAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
		 	'JV Property No'=>$this->strJVendorPropNumber,	  
			'JV Property Name'=> $this->strJVendorPropName,
			'JV Line 1'=>$this->strJVendorAdressLine1,
			'JV Road / Street No'=>$this->strJVendorRoadNo,
			'JV Road / Street Name'=>$this->strJVendorRoadName,
			'JV Line 2'=>$this->strJVendorAddressLine2,			
			'JV Line 3'=>$this->strJVendorAddressLine3,
			'JV Town'=>$this->strJVendorAddressTown,
			'JV County'=>$this->strJVendorAddressCounty,
			'JV Country'=>$this->strJVendorAddressCountry,
			'JV Address String'=> $this->strJVendorAddress,
			'JV Address Block'=> $this->strJVendorAddress,
			
			
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("JV Correspondence Address");
	}
	
}

?>