<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Offer extends EntityBase implements IEntityObject 
{
	
	public $strOfferStatus;
	public $intOffer_AcceptId = "1";
	public $intOfferId = "1";
	public $intApplicantId = "2";
	public $intPropertyId="10";
	public $dtDate="01.01.2000";
	public $tmTime="12:12:12";
	public $strOfferNotes="offer Accepted";
	public $strlocalAuthority ="bournemouth county council";
	public $strbuyerPosition="manager";
	public $strFinancialInformation = "big mortgage";
	public $strType="27";
	public $strcomp="0";
	public $intOffer_rejId = "1";
	public $intOfferId = "1";
	public $intApplicantId = "2";
	public $intPropertyId="10";
	public $dtRejected="01.01.2000";
	public $tmrejected="12:12:12";
	public $strOfferNotes="offer rejected";
	
	public function __construct($Status)
	{
		$this->strOfferStatus=$Status;
	}	
	public function getProperties()
	{
		$resultArray = array
		(

		);
		return $resultArray;	
	
	}
	public function getName()
	{
		if($this->strOfferStatus=="Rejected")
			return("Offer Rejected");
		if($this->strOfferStatus=="Accepted")
			return("Offer Accepted");
		if($this->strOfferStatus=="Standard")
			return("Offer");
			
	}

	
}
?>