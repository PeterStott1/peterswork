<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OutFsLetter extends EntityBase implements IEntityObject 
{ 
	
//apt_id, fs_contact_id, fs_appointment_person, fs_position, 
//fs_br_add1, fs_br_add2, fs_br_add3, fs_br_town, fs_br_county, 
//fs_br_country, fs_br_postcode, fs_phoneno, fs_mobile, fs_salutation, 
//fs_email, fs_br_road, fs_primary_contact, fs_negotiator, fs_same_commpany, 
//fs_comp_cot_cat, fs_comp_name, fs_comp_add1, fs_comp_add2, fs_comp_add3, 
//fs_comp_town, fs_comp_county, fs_comp_country, fs_comp_postcode, fs_comp_phoneno, 
//fs_comp_faxno, fs_comp_dx_ref, fs_comp_terms, fs_comp_emails, fs_comp_notes, 
//fs_comp_road, fs_comp_negotiator, fs_concat_name, applicant_key, 

		 public $strAptID = "1";
		 public $strFsContactId = "1";
		 public $strApplicantKey = "100002";
		 public $strFsAppoinmentperson = "Financial Advisors Name displayed here";
		 public $strFsposition = "Financial Advisors Position  displayed here";
		 public $strFsBrAddressLine = "Financial Advisors Branch Address displayed here";
		 public $strFSComanyName = "Financial Advisors Company Name displayed here";
		 public $strFsCompanyAddress = "Financial Advisors Company Address displayed here";
		 public $strCompanyNegotiator = "Negotitor displayed here";
		 public $strPrimaryContact = "Primary Contact displayed here";
		
		
		
		
		 public function getProperties()
			{
				$resultarray = array(
				'aptID' =>$this->strAptID,
				'contactId' => $this->strFsContactId,
				 'appointment person' =>$this->strFsAppoinmantperson,
				 'Position' =>$this->strFsposition,
				 'branch address' =>$this->strFsBrAddressLine,
				 'Vendor position' =>$this->strVendorPosition,
				);
				
		
				
				return $resultarray;	
			
			}

		public function getName()
			{
				return("OutFsLetter");
			}

}
?>