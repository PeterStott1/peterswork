<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Progress extends EntityBase implements IEntityObject 
{
	

	public $curOfferAmount = "Offer amount displayed here";
	public $dtOfferDate="Offer date displayed here";
	public $tmOfferTime="Offer time displayed here";
	public $strOfferNotes="Offer notes displayed here";
	public $strlocalAuthority ="Local authority info displayed here";
	public $strbuyerPosition="Buyers position displayed here";
	public $strFinancialInformation = "Financial Info displayed here";
	//public $strType="Property status displayed here";
//	public $strcomp="Comple";
	
 	
	//@get properties needed to
	public function getProperties()
	{
		$resultArray = array
		(

			'Offer Amount'=>$this->curOfferAmount,
			'Offer date'=>$this->dtAccepted,
			'Offer Time'=>$this->tmAccepted,
			'Offer Notes'=>$this->strOfferNotes,
			'Local Authority'=>$this->strlocalAuthority,
			'Buyer position'=>$this->strbuyerPosition,
			'Financial Information'=>$this->strFinancialInformation,
			//'Offer type'=>$this->strType
//			'Complete'=>$this->strcomp
	
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Offer Details");
	}

	
}
?>