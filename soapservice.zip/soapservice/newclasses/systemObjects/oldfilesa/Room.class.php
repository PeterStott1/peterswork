<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Room extends EntityBase implements  IEntityObject 
{
	
	public $strRoomName="bedroom";
	public $strDescription="large single room with south facing windows";
	public $imgRoomImage="property-photo-big.jpg";
	public $fltRoomLength="3'6";
	public $fltRoomWdith="4'9";
	
	
	

	public function getProperties()
	{
		$resultarray = array(
		'room name' => $this->strRoomName,
		'Description' => $this->strDescription,
		'Dimensions' => $this->fltRoomLength.$this->fltRoomWdith,
		
		);
		

		
		return $resultarray;	
	
	}
	public function getImages()
	{
		$resultArray = array
		(
			
			'Image'=>$this->imgRoomImage	
			
		);
		return $resultArray;	
	
		
	}
	
	public function getName()
	{
		return("Room Property ".$this->strRoomName);
	}

	
}
?>