<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Branch extends EntityBase implements  IEntityObject 
{
	
	public $strBranchID ="1";
	public $strBranchName ="Branch Name";
	public $strAddress = "13 New Street, Winton, Bournemouth, BH34 TH6, Dorset, England";
	public $strTelePhone = "01202 675 395";
	public $strFax = "01202 564 908";
	public $strBranchManager= "Mr Smith";
	public $strHeader = "Header information would go here";
	public $strFooter = "Footer information would go here";
	public $strEmailAddress = "Aol@Aol.com";
	
	
	
	public function getProperties()
	{
		
	 
	
		$resultarray = array(
		'Branch name' => $this->strBranchName,
		'Telephone Number' =>$this->strTelePhone,
		'Fax Number' => $this->strFax,
		'Branch Manager' => $this->strBranchManager,	
		'Header' => $this->strHeader,
		'Footer' => $this->strFooter,
		'Branch Address String'=>$this->strAddress,
		'Branch Email Address'=>$this->strEmailAddress,
		);
		return $resultarray;	
	
	}
	
	public function getName()
	{
		return($this->strBranchName);
	}
	
	
	
}
?>