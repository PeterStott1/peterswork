<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class Contact extends EntityBase implements  IEntityObject 
{
	public $strCompanyName = "Contact Company Name";
	public $strFaxNo = "Contact Company Fax Number displayed here";
	public $strDxRef= "Contact Company DX Ref displayed here";
	public $strTerms = "Contact Company Terms displayed here";
	public $strNotes = "Contact Company Notes displayed here";

	public $strAddressRoadNo = "Contact Correspondence Road / Street No displayed here";
	public $strAddressRoadName = "Contact Correspondence Road / Street Name displayed here";
	public $strAddress2 = "Contact Correspondence Address Line 2 displayed here";
	public $strAddress3 = "Contact Correspondence Address Line 3 displayed here";
	public $strCountry = "Contact correspondence Address Country";
	public $strCounty = "Contact Correspondence County displayed here";
	public $strTown = "Contact Correspondence Town / City displayed here";
	public $strPostCode = "Contact Correspondence Post Code";
	public $strPhoneNo = "Contact Correspondence Phone Number displayed here";
	public $strEmailAddress = "Contact Correspondence Email Address displayed here";

	public $strAddress = "Contact Address String displayed here";
	public $strAddressBlock = "Contact Block Address display here";

	public $strContactName="Contact Name displayed here";
	public $strPosition = "Contact Position displayed here";
	public $strContactPhone = "Contact Mobile No displayed here";
	public $strSalutation = "Contact Salutation displayed here";
	
	function getName()
	{
		return("Contact Details");
	}

	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		
		$strTemp =$this->strAddressRoadNo.",".$this->strAddressRoadName.",".$this->strAddress2.",".$this->strAddress3.",".$this->strTown.",".$this->strCounty.",".$this->strCountry.",".$this->strPostCode;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		//@@now build the properties for this object

		$resultArray = array
		(
		'Contact Company Name' => $strCompanyName,
		'Contact Company Fax No ' => $strFaxNo,
		'Contact Company DX Ref' => $strDxRef,
		'Contact Company Terms' => $strTerms,
		'Contact Company Notes' => $strNotes,

		'Contact Road No' => $strAddressRoadNo,
		'Contact Road Name' => $strAddressRoadName,
		'Contact Address 2' => $strAddress2,
		'Contact Address 3' => $strAddress3,
		'Contact country' => $strCountry,
		'Contact County' => $strCounty,
		'Contact Town' => $strTown,
		'Contact Post Code' => $strPostCode,
		'Contact Phone No' => $strPhoneNo,
		'Contact Email Address' => $strEmailAddress,
		'Contact Address String' => $strAddress,
		'Contact Address Block' => $strAddressBlock,

		'Contact Name' => $strContactName,
		'Contact Position' => $strPosition,
		'Contact Mobile Number' => $strContactPhone,
		'Contact Salutation' => $strSalutation,
		);
		return $resultArray;	
	
	}
	
//	public function getImages()
//	{
//		$resultArray = array
//		(
//			
//			
//			
//		);
//		return $resultArray;	
//	
//		
//	}
	
	


}
?>