<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class Branch extends EntityBase implements  IEntityObject 
{
	
	public $strBranchID ="Branch ID displayed here";
	public $strBranchName ="Branch Name displayed here";
	public $strAddress = "Branch Address displayed here";
	public $strTelePhone = "Branch Phone number displayed here";
	public $strFax = "Branch Fax number displayed here";
	public $strBranchManager= "Branch Manager displayed here";
	public $strHeader = "Branch Header displayed here";
	public $strFooter = "Branch Footer displayed here";
	public $strEmailAddress = "Branch Email Address displayed here";
	
	
	
	public function getProperties()
	{
		
	 	$strTemp = $this->strHeader;
		
	 	$this->strHeader = StringManipulation::RegExpression($strTemp);
		
		$resultarray = array(
		'Branch Name' => $this->strBranchName,
 		'Branch Manager' => $this->strBranchManager,
		'Branch Address String'=>$this->strAddress,
		'Branch Email Address'=>$this->strEmailAddress,
		'Branch Telephone Number' =>$this->strTelePhone,
		'Branch Fax Number' => $this->strFax,	
		'Branch Header' => $this->strHeader,
		'Branch Footer' => $this->strFooter,

		);
		return $resultarray;	
	
	}
	
	public function getName()
	{
		return("Branch Details");
	}
	
	
	
}
?>