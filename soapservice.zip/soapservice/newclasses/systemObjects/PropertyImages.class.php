<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class PropertyImages extends EntityBase implements IEntityObject 
{
	
		
		public $strImage;
		public $strImageTitle;
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$resultArray = array
		(
			'Title'=>$this->strImageTitle
			
		);
		return $resultArray;	
	
	}
	public function getImages()
	{
		$resultArray = array
		(
			
			'Images' => $this->strImage
		);
		return $resultArray;	
	
		
	}
	
	public function getName()
	{
		return("PropertyImages".$this->strImageTitle);
	}

	
}
?>