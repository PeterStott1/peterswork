<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');

class Property extends EntityBase implements  IEntityObject 
{
	public  $intPropertyId="Property ID displayed here";
	public  $intVendorNo="Vendor ID displayed here";
	public  $strPropertyName = "Property / Flat Name displayed here";
	public  $strPropertyNumber = "Property / Flat Number displayed here";
	public  $strAddressLine1 = "Road / Street Number displayed here";
	public  $strAddressLine2 = "Address Line 2 displayed here";
	public  $strAddressLine3 = "Address Line 3 displayed here";
	public  $strAddressRoad = "Road / Street Name displayed here";
	public  $strTown = "Town / City displayed here";
	public  $strPostcode = "Post Code displayed here";
	public  $strCounty = "County displayed here";
	public  $strCountry = "Country displayed here";
 	public 	$strAddress = "Address String displayed here";
	public  $strAddressBlock = "Address Block displayed here";
 	public 	$strDescrition = "Property Description displayed here";
	public  $intaskingpr ="Asking Price displayed here";
	public  $imgFloorPlan = "Floor-plan displayed here";
	public 	$imgMainImage = "Main Image displayed here";
	public 	$strBranchId = "Branch ID displayed here";
	public 	$strPropertyArea = "string of areas";
	public 	$strPropertyDistrict ="string of district";
	public  $strPropertyType = "Property Type displayed here";
	public 	$strCommercialProperty = "Property Commercial Flag displayed here";
	public  $strPropertyFor ="Property For Sale or Rent Flag displayed here"; 
	public  $strPropertyBedrooms="Property No of Bedrooms displayed here"; 
	public  $strPropertyReceptions="Property No of Reception Rooms displayed here"; 
	public  $strPropertyBathrooms="Property No of Bathrooms displayed here"; 
	Public  $strOpinionPrice = "Vendors Opinion Library Price displayed here";
	public  $strPropertyValuationPrice="Valuation Library Price displayed here"; 
	public  $strPropertyQuickSellPrice="Quick Sale Library Price displayed here";
	public  $strPropertyTestMarketPrice="Test the Market Library Price displayed here";
	public 	$strPropertyAge = "Property Age displayed here";
	public  $strPropertyView ="Property Viewing Requirements displayed here ???????????";
	public  $strPropertyTenure ="Property Tenure displayed here";
	public  $strPropertyPosseion = "Property Possession Detail displayed here";
	public  $strBuyersposition = "Vendors Position Detail displayed here";
	public  $strPropertyClass = "0";
	public  $strCentralHeating= "0";
	public  $strVacant = "0";
	public 	$strVehicleParking = "0";
	public  $strParkingSize = "0";
	public 	$intmap_ref ="0";
	public  $strOffRoadParking = "0";
	public 	$strGarage = "0";
	public  $strOutBuilding = "0";
	public  $strSwimmingPool = "0";
	public  $strSpecialCritiria = "Property Special Criteria displayed here";
	public 	$strGarden = "0";
	public  $strLargeGarden = "0"; 
	public  $strAdditionalInformation = "Addition Information Details displayed here";
	public 	$SquareFootage = "Property Approximate Sq Ft displayed here";
	public  $strrentalPeriod = "Property Rental Period displayed here";
	public  $strSalesBoardrequired = "Sale Board Required Flag displayed here";
	public  $strSalesBoard = "1";
	public  $strKeyReference = "Property Key Cupboard No displayed here";
	public  $strKeyHolder = "Property Key Status displayed here";
	public  $strSendToPropertyList = "0";
	public  $dtCreatedOn = "Property Record Created Date displayed here";
	public  $strViewingDescription = "Property Viewing Requirements displayed here ???????????";
	public  $strViewingInformation ="Property Viewing Requirements displayed here ???????????";
	public  $strEnquirySource = "Property Enquiry Source displayed here";
	public  $strShowPrice = "Property Library Price Item to show displayed here";
	public  $curCurrency = "Property Currency displayed here";
	public  $strPOA = "Property Price on Application Flag displayed here";
	public  $strPropertyDescription = "Property Descriptions displayed here";
	public  $strPropertyBand = "Property Council Tax Band displayed here";
	Public  $strValuationCompleted = "Property Valuation Completed Flag displayed here";
	public  $strLwd = "??????????";
	public  $dtLwd = "???????????";
	public  $tmLwd = "???????????";
	public  $strLostTo = "Property Lost to whom displayed here";
	public  $strReasonLost = "Property Lost Reason displayed here";
	public  $strLwdNotes = "??????????????";
	public  $strValutionNotes = "Property Valuation Notes displayed here";
	public  $strPropertyTarnsfer = "Property Transfer Flag displayed here";
	public  $strPropertyBranchValuer = "Property Assigned Negotiator displayed here";
	public  $strPropertyNegotiator= "Property Assigned Negotiator displayed here";
	public  $strArchive = "Property Archived Flag displayed here";
	public  $strSalesStatus = "?????????????";
	public  $strPropertyInMarket = "Property Available Flag displayed here ???";
	public  $dtPropertyAvailableDate = "Rental Criteria Available Date displayed here";
	public  $strKitchen = "Rental Criteria Kitchen Type displayed here";
    public  $strFloorNo = "Rental Criteria Floor no displayed here";
    public  $strFlooring = "Rental Criteria Flooring Type displayed here";
    public  $boolFurnished  = "Rental Criteria Furnished Yes / No displayed here";
    public  $boolLift  = "Rental Criteria Lift Yes or No displayed here";
    public  $strPropCondition ="Rental Criteria Property Condition displayed here";
    public  $strTube = "Rental Criteria Tube Info displayed here";
    public  $strAllowSmoker = "Rental Criteria Smoker Allowed Yes / No displayed here";
	public  $strAllowStudent = "Rental Criteria Students Allowed Yes / No displayed here";
	public  $strAllowChildren = "Rental Criteria Children Allowed Yes / No displayed here";
	public  $strAllowPets = "Rental Criteria Pets Allowed Yes / No displayed here";
	public  $strInstructedDate = "Property Instructed Date displayed here";
	public  $strpropBrief = "Property Brief Description displayed here";
	public  $strPropDescription = "Property Full Description displayed here";	
	public  $strPropertyNotes = "Property Notes displayed here";
	public  $strPropertyLive = "Property Live Flag displayed here";
	public  $strAdvertDescription = "Property Advert Description displayed here";
	public  $strpropertySub = "Property Sub Category displayed here ?????????";
	public  $strPropertyFeature = "Property Features displayed here";
	public  $strLocalInfo = "?????????????????";
	public  $strFeatureInsertBefore = "Property Insert before flag displayed here";
	public  $strOtherPl = "??????????";
	public  $dtSoldDate = "Property Sold Date displayed here";
	public  $tmSoldTime  ="Property Sold Time displayed here";
	public 	$strCurrentPrice = "Property Current Price displayed here";
	
	function getName()
	{
		return("Property Details");
	}

	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$strTemp = $this->strPropertyNumber.", ".$this->strPropertyName.", ".$this->strAddressLine1.", ".$this->strAddressRoad.", ".$this->strAddressLine2.", ".$this->strAddressLine3.", ".$this->strTown.", ".$this->strCounty.", ".$this->strPostcode.", ".$this->strCountry;
		$this->strAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strAddressBlock = StringManipulation::MakeBlock($strTemp);
		//@@now build the properties for this object

		$resultArray = array
		(
			//split out the individual address line for the users see correspondence address steal it!!
			'Property Key'=>$this->intPropertyId,
//			'Property Vendor Number'=>$this->intVendorNo,


			'Property Address Flat / House Name'=>$this->strPropertyName,
			'Property Address Flat / House Number'=>$this->strPropertyNumber,
			'Property Address Road / Street Number'=>$this->strAddressLine1,
			'Property Address Road / Street Name'=>$this->strAddressRoad,
			'Property Address Line 2'=>$this->strAddressLine2,
			'Property Address Line 3'=>$this->strAddressLine3,
			'Property Address Town' => $this->strTown,
			'Property Address Postcode' =>$this->strPostcode,
			'Property Address County' => $this->strCounty,
			'Property Address Country' => $this->strCountry,
			'Property Address String'=>$this->strAddress,
			'Property Address Block'=>$this->strAddressBlock,
			// Descriptions need to be individual as well as a concatenate of all descriptions into 1 string!
			//being moved to brochure object

			'Descriptions Property Live Y/N'=>$this->strPropertyLive ,
			'Area' =>$this->strPropertyArea,
			'District'=>$this->strPropertyDistrict,
			'Descriptions Brief'=>$this->strpropBrief ,
			'Descriptions Full'=>$this->strPropertyDescription ,
			'Descriptions Features'=>$this->strPropertyFeature , // This is multiple items *******
			'Descriptions Adverteristing'=>$this->strAdvertDescription , 
			'Descriptions Main for Property'=>$this->strPropDescription ,
			'Descriptions Approximate Total Square Footage'=>$this->SquareFootage ,
			'Descriptions Property Status'=>$this->strSalesStatus ,
			'Property In Market'=>$this->strPropertyInMarket , // Disputed with the above item only 1 status possible dont know which 1 is which!! *****

// FEATURES Required *****

//			'Property Branch Id'=>$this->strBranchId , 
			'Selling Criteria Property For Sale or Let'=>$this->strPropertyFor ,
			'Selling Criteria Category Property'=>$this->strPropertyType , // Please check value from the ValutionLetter.class to make sure we are pull the value from the correct place ***********
			'Selling Criteria Category sub'=>$this->strpropertySub , // Please check value from the ValutionLetter.class to make sure we are pull the value from the correct place ***********
			'Selling Criteria Category Sub'=>$this->strCommercialProperty , // Disputed with the above only 1 needed dont think class is what we think it is!!! ****
			'Selling Criteria No Bedrooms'=>$this->strPropertyBedrooms,
			'Selling Criteria No Receptions'=>$this->strPropertyReceptions,
			'Selling Criteria No Bathrooms'=>$this->strPropertyBathrooms,
			'Selling Criteria Tenure'=>$this->strPropertyTenure ,
			'Selling Criteria Special Criterias Detailed'=>$this->strSpecialCritiria ,
			'Selling Criteria Viewing Information'=>$this->strViewingInformation ,
			'Rental Criteria Rental Period'=>$this->strrentalPeriod ,			
			'Rental Criteria Date Available from'=>$this->dtPropertyAvailableDate, 
			'Rental Criteria Kitchen Y/N'=>$this->strKitchen,
		    	'Rental Criteria Floor No'=>$this->strFloorNo,
		    	'Rental Criteria Type of Flooring'=>$this->strFlooring,
		    	'Rental Criteria Furnished Y/N'=>$this->boolFurnished,
		    	'Rental Criteria Lift Y/N'=>$this->boolLift, 
		    	'Rental Criteria Condition'=>$this->strPropCondition,
		    	'Rental Criteria Tube'=>$this->strTube,
		    	'Rental Criteria Property Allow Smoker'=>$this->strAllowSmoker,
			'Rental Criteria Property Allow Student'=>$this->strAllowStudent,
			'Rental Criteria Property Allow Children'=>$this->strAllowChildren,
			'Rental Criteria Property Allow Pets'=>$this->strAllowPets, 
			'Library Pricing being used for Advertising'=>$this->strShowPrice ,
			'Library Pricing being used for Advertising'=>$this->strCurrentPrice, // Disputed with the above only 1 need possible both same		
			'Library Pricing Asking price'=>$this->intaskingpr ,
			'Library Pricing Vendor Opinion'=>$this->strOpinionPrice ,
			'Library Pricing Valuation'=>$this->strPropertyValuationPrice,
			'Library Pricing Quick Sell'=>$this->strPropertyQuickSellPrice,
			'Library Pricing Test Market'=>$this->strPropertyTestMarketPrice,
			'Library Pricing POA Flag'=>$this->strPOA ,
			'Library Pricing Currency'=>$this->curCurrency ,
			'General Detail Enquiry Source'=>$this->strEnquirySource ,			
			'General Detail Council Tax Band'=>$this->strPropertyClass , 
			'General Detail Council Tax Band'=>$this->strPropertyBand , //Disputed with the above item only 1 is possible *****
			'General Detail Age'=>$this->strPropertyAge ,
			'General Detail View Requirements'=>$this->strPropertyView ,
			'General Detail Possession'=>$this->strPropertyPosseion , 
			'General Detail Vendor Position'=>$this->strBuyersposition , 
			'General Detail Additional Information'=>$this->strAdditionalInformation , 
			'General Detail Date Property Created On System'=>$this->dtCreatedOn ,
			'General Detail Assign Negotiator'=>$this->strPropertyNegotiator, 
			'General Detail Instructed date'=>$this->strInstructedDate ,
			'General Detail Property Notes'=>$this->strPropertyNotes , // this is a multiple item content ******
			'General Detail Date Sold'=>$this->dtSoldDate, 
			'General Detail Sold Time'=>$this->tmSoldTime,
			'Board / Key - Board required Yes or No'=>$this->strSalesBoardrequired , 
// Need Current Board***'Board / Key - Sales Board'=>$this->strSalesBoard , *************************************
// Need New Reqdmt***	'Board / Key - Sales Board'=>$this->strSalesBoard , *************************************
// lots of key information is missing *********************************************************************************
			'Board / Key -  Key Reference'=>$this->strKeyReference , 
			'Board / Key -  key Holder'=>$this->strKeyHolder ,
//
//			'Valuation Notes'=>$this->strValutionNotes , 
//			'Valuation Branch Valuer'=>$this->strPropertyBranchValuer ,
//			'Valuation Completed Date'=>$this->strValuationCompleted ,



// this could well be to do with CANCELLING A VALUATION IF SO WE NEED THEM NEED TO BE CONFIRMED PLEASE ****

//			'Property LWD notes'=>$this->strLwdNotes , 
//			'Property LWD'=>$this->strLwd , 
//			'Property date of LWD'=>$this->dtLwd ,
//			'Property Time of LWD'=>$this->tmLwd ,
		


// not required
//			'Property feature Insert before'=>$this->strFeatureInsertBefore, 
//			'Property send to property list'=>$this->strSendToPropertyList ,
//			'Property Transfer'=>$this->strPropertyTarnsfer , 
// 			'Property Archive'=>$this->strArchive , 
//			'Propecting - Property Lost To'=>$this->strLostTo , 
//			'Prospecting - Property Reason Lost'=>$this->strReasonLost ,

// Unknown need to understand if used and what for to make a decision if needed.

//			'Property local information'=>$this->strLocalInfo , 
//			'Property OtherPl'=>$this->strOtherPl,
// Unsure if values	'Descriptions Property'=>$this->strDescrition, 
//			'Property Central Heating'=>$this->strCentralHeating,
//			'Property Vacant'=>$this->strVacant , 
//			'Property Vehicle parking'=>$this->strVehicleParking , 
//			'Property Parking Size'=>$this->strParkingSize , 
//			'Property Map Ref'=>$this->intmap_ref ,
//			'Property off road parking'=>$this->strOffRoadParking ,
//			'Property Garage'=>$this->strGarage ,
//			'Property Out buildings'=>$this->strOutBuilding ,
//			'Property Swimmming Pool'=>$this->strSwimmingPool , 
//			'Property Garden'=>$this->strGarden ,
//			'Property large Garden'=>$this->strLargeGarden ,
//			'Property Viewing Description'=>$this->strViewingDescription ,
 

			
		);
		return $resultArray;	
	
	}
	
	public function getImages()
	{
		$resultArray = array
		(
			
			'Floor Plans' => $this->imgFloorPlan, // Multiple items *****
			'Main Image'=>$this->imgMainImage // Main image *****
// Where are the other room images and the other images for other uploads plus maps as well ******
			
		);
		return $resultArray;	
	
		
	}
	
	


}
?>