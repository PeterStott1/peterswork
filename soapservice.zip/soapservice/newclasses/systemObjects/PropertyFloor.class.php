<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class PropertyFloor extends EntityBase implements IEntityObject 
{
	
		
		public $strImage;
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
		$resultArray = array
		(
			
			
		);
		return $resultArray;	
	
	}
	public function getImages()
	{
		$resultArray = array
		(
			
			'Floor Plans' => $this->strImage
		);
		return $resultArray;	
	
		
	}
	
	public function getName()
	{
		return("PropertyFloor");
	}

	
}
?>