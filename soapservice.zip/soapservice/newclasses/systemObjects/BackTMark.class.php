<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class BackTMark extends EntityBase implements  IEntityObject 
{
	
	public $dtDate ="Back to Market Date displayed here";
	public $tmTime = "Back to Market Time displayed here";
	public $strSubject ="Back to Market Subject displayed here";
	public $strNegotiator = "Back to Market Negotiator displayed here";
	public $strNotes = "Back to Market Notes displayed here";
	
	
	public function getProperties()
	{
		
		$resultarray = array(
		'Back to Market Date' => $this->dtDate,
		'Back to Market Time'=>$this->tmTime,
		'Back to Market Subject'=>$this->strSubject,
		'Back to Market Notes'=>$this->strNotes,
		'Back to Market Negotiator'=> $this->strNegotiator
	
		);
		return $resultarray;	
	
	}
	
	public function getName()
	{
		return('Back To Market Details');
	}
	
	
	
}
?>