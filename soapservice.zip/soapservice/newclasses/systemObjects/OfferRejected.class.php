<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OfferRejected extends EntityBase implements IEntityObject 
{
	
	public $dtRejected="Offer Rejected Date displayed here";
	public $tmrejected="Offer Rejected Time Entered displayed here";
	public $strOfferNotes="Offer Rejected Notes displayed here";
	
	
	public function getProperties()
	{
		$resultArray = array
		(	
			'Date Rejected'=>$this->dtRejected,
			'Time Entered'=>$this->tmrejected,
			'Offer Rejected Notes'=>$this->strOfferNotes,

		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Offer Rejected Details");
	}

	
}
?>