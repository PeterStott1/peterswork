<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class PropertyLetter extends EntityBase implements IEntityObject 
{ 
		
		 public $PropertyKey = "100010";
		 public $strPropertyId = "10";
		 public $strVendorUsername = "user";
		 public $strVendorPassword = "passoword";
		 public $strJVendorUsername = "user";
		 public $strJVendorPassword = "passowrd";
		 public $strVendorAddress = "23, fake street, branksome,poole, bh15 6yp, dorset"; 
		 public $strVendorName = "Mr.J John Johnson";
		 public $strVendorPhoneNum = "010208976554";
		 public $strVendorBusinessPhonenum = "0102984659";
		 public $strVendorMobileNum = "010208976554";
		 public $strVendorFaxNum = "874185019357";
		 public $strVendorEmail = "someone@someplace";
		 public $boolVendorAllowPost = "false";
		 public $boolVendorAllowSms = "false";
		 public $boolVendorAllowEmail = "false";
		 public $strJVendorName = "Miss Jenny Penny";
		 public $strJVendorPhoneNum = "010208976554";
		 public $strJVendorMobileNum = "09788654643321";
		 public $strJVendorFaxNum = "874185019357";
		 public $strJVendorEmail = "someone@someplace"; 
		 public $strJVendorBusinessPhoneNumber = "012020338655";
		 public $boolJVendorAllowPost = "false";
		 public $boolJVendorAllowSms = "false";
		 public $boolJVendorAllowEmail = "false";
		 public $strVendorSalutation = "DR no";
		 public $strPropComanyName = "rent b4 u buy";
		 public $strpropAddress = "23, fake street,branksome,Poole,bh1 1 rp, dorset";
		 public $strPropType = "semi detached";
		 public $strPropStatus = "Sale";
		 public $strpropBedroomNum = "3";
		 public $PropKitchendesc = "open plan";
		 public $propFlooring = "1st floor";
		 public $PropFloorno = "3";
		 public $PropCondition = "good";
		 public $strpropRecptions = "1";
		 public $strPropBathrooms = "2";
		 public $strPropAskingPrice = "150,000.00";
		 public $strPropValuationPrice = "180,000.00";
		 public $strQuickSellPrice = "140,000.00";
		 public $strTestMarketPrice = "160,000.00";
		 public $strVendoropinionPrice = "200,000.00";
		 public $strCurrentPrice = "180,000.00";
		 public $strBranch = "1";
		 public $strBranchPhoneNum = "980634521";
		 public $strBranchFaxNum = "97892865975";
		 public $strBranchEmail = "someone@someplace.com";
		 public $strSalesStatus = "exchnage";
		 public $strRentalPeriod = "12 Month renewable";
		 public $strLettingAvailableDate = "12.01.2007";
		 public $boolFurnished  = "false";
		 public $boolLift  = "false";
		 public $strTube = "1";
		 public $boolAllowSmoker = "false";
		 public $boolAllowStudent = "false";
		 public $boolAllowChildren = "false";
		 public $boolAllowPets = "false";
		 public $strVendorNegotiator = "james gibbson";
		 public $strpropBrief = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses";
		 public $strPropDescription = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";
		 public $strViewingRequirements = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";
		 public $strPropertyLocation = "Winton, Dorset,England";
		 public $datContactedDate = "01.02.2007";
		 public $fltCommisionRate = "10";
		 public $boolsplitCommission = "0";
		 public $CurFixedFee = "1,500";
		 public $strInstructedDate = "12.01.2007";
		 public $strPopTenure = "Freehold";
		 public $strPriceDescription = "Guide Price";
		 public $strVendorPosition = "Cash Buyer";
		 public $strPropCategory = "Residental";
		 public $strPropSubCategory = "Investment property";
		 public $strAdvertDescription = "just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential";
		 public $dtLeaseComenceDate = "01.01.2007";
		 public $IntLeaseNoYears = "2";
		 public $curLeaseGroundRent = "23";
		 public $boolLeasegroundFixed ="yes";
		 public $curLeaseMaintenanceCharge = "500";
		 public $boolCopyLeaseAvailable = "yes";
		 public $boolLeaseInsuranceIncluded = "yes";
		 public $strLeaseManagementCompany = "collins maintenance crew";
		 public $boolLeaseSittingTenants = "no";
		 public $strAgencyType = "Sole Agency";
		 public $strAgencyPeriod = "6 weeks";		 
		 public $strSolicitorCompanyName = "MRA Financial Services";
		 public $strVendorSolicitorAddress = "23, fake street,branksome,Poole,bh11rp,Dorset";
		 public $strVendorSolPhoneNum = "01202346586";
		 public $strVendorSolContactName = "jimmy riddle";
		 public $strVendorSolFaxNum = "0923830972348";
		 public $strVendorSolMobileNum = "018378623845";
		 public $strVendorSolEmail = "someone@someplace.com";
		 public $strVendorPropertyAddress = "23, fake street,branksome,bh11rp,poole ,dorset";
		 public $strJointVendorAdress = "23, fake street,branksome,bh11rp,poole ,dorset";
		 public $strVendorSolSalutation = "DR no";

				
		
		 public function getProperties()
			{
				$resultarray = array(
				 	 
				'property key' =>$this->PropertyKey ,
				 'property Id' =>$this->strPropertyId ,
				 'Vendor username' =>$this->strVendorUsername ,
				 'Vendor Password' =>$this->strVendorPassword ,
				 'Joint Vendor Username' =>$this->strJVendorUsername ,
				 'Joint Vendor Password' =>$this->strJVendorPassword ,
				 'Vendor Address' =>$this->strVendorAddress ,
				 'Vendor Name' =>$this->strVendorName ,
				 'Vendor Phone number' =>$this->strVendorPhoneNum ,
				 'Vendor Business phone Number' =>$this->strVendorBusinessPhonenum ,
				 'Vendor Mobile Number' =>$this->strVendorMobileNum ,
				 'Vendor fax number' =>$this->strVendorFaxNum ,
				 'Vendor Email' =>$this->strVendorEmail ,
				 'Vendor Allow Post' =>$this->boolVendorAllowPost ,
				 'Vendor Allow SMS' =>$this->boolVendorAllowSms ,
				 'Vendor Allow Eamil' =>$this->boolVendorAllowEmail ,
				 'Joint Vendor Name' =>$this->strJVendorName ,
				 'Joint Vendor Phone number' =>$this->strJVendorPhoneNum ,
				 'Joint Vendor Mobile number' =>$this->strJVendorMobileNum ,
				 'Joint Vendor fax number' =>$this->strJVendorFaxNum ,
				 'Joint Vendor Email' =>$this->strJVendorEmail ,
				 'Joint Vendor Buisness number' =>$this->strJVendorBusinessPhoneNumber ,
				 'Joint Vendor Allow Post' =>$this->boolJVendorAllowPost ,
				 'Joint Vendor Allow SMS' =>$this->boolJVendorAllowSms ,
				 'Joint Vendor Allow Eamil' =>$this->boolJVendorAllowEmail ,
				 'Vendor Salutation' =>$this->strVendorSalutation ,
				 'property Company name' =>$this->strPropComanyName ,
				 'property Address' =>$this->strpropAddress ,
				 'property type' =>$this->strPropType ,
				 'property Status' =>$this->strPropStatus ,
				 'property Bedroom Number' =>$this->strpropBedroomNum ,
				 'property Kitchen Desc' =>$this->PropKitchendesc ,
				 'property Flooring' =>$this->propFlooring ,
				 'property number of floors' =>$this->PropFloorno ,
				 'property Condition' =>$this->PropCondition ,
				 'property receptions' =>$this->strpropRecptions ,
				 'property bathrooms' =>$this->strPropBathrooms ,
				 'property Asking price' =>$this->strPropAskingPrice ,
				 'property Valuation Price' =>$this->strPropValuationPrice ,
				 'property quick Sell Price' =>$this->strQuickSellPrice ,
				 'property test market price' =>$this->strTestMarketPrice ,
				 'Vendor opinion price' =>$this->strVendoropinionPrice ,
				 'property current pirce' =>$this->strCurrentPrice ,
				 'Branch' =>$this->strBranch ,
				 'Branch phone Number' =>$this->strBranchPhoneNum ,
				 'Branch Fax number' =>$this->strBranchFaxNum ,
				 'Branch Eamil' =>$this->strBranchEmail ,
				 'Property Sales Status' =>$this->strSalesStatus ,
				 'Property Renatl Period' =>$this->strRentalPeriod ,
				 'Property letteing available date' =>$this->strLettingAvailableDate ,
				 'Furnished' =>$this->boolFurnished  ,
				 'lift' =>$this->boolLift  ,
				 'tube' =>$this->strTube ,
				 'Property allow smokers' =>$this->boolAllowSmoker ,
				 'Property allow students' =>$this->boolAllowStudent ,
				 'Property allow children' =>$this->boolAllowChildren ,
				 'Property allow pets' =>$this->boolAllowPets ,
				 'Vendor negotiator' =>$this->strVendorNegotiator ,
				 'Property Brief description' =>$this->strpropBrief ,
				 'Property description' =>$this->strPropDescription ,
				 'Property viewing requirements' =>$this->strViewingRequirements ,
				 'Property location' =>$this->strPropertyLocation ,
				 'Date Contacted' =>$this->datContactedDate ,
				 'commision rate' =>$this->fltCommisionRate ,
				 'split commission' =>$this->boolsplitCommission ,
				 'fixed fee' =>$this->CurFixedFee ,
				 'Instructed date' =>$this->strInstructedDate ,
				 'Tenure' =>$this->strPopTenure ,
				 'price description' =>$this->strPriceDescription ,
				 'Vendor position' =>$this->strVendorPosition ,
				 'Property catergory' =>$this->strPropCategory ,
				 'Property sub catergory' =>$this->strPropSubCategory ,
				 'Property description' =>$this->strAdvertDescription ,
				 'Date Lease commences' =>$this->dtLeaseComenceDate ,
				 'Lease years' =>$this->IntLeaseNoYears ,
				 'lease ground rent' =>$this->curLeaseGroundRent ,
				 'lease ground fixed' =>$this->boolLeasegroundFixed ,
				 'lease maintenance charge' =>$this->curLeaseMaintenanceCharge ,
				 'Lease available' =>$this->boolCopyLeaseAvailable ,
				 'lease insurance included' =>$this->boolLeaseInsuranceIncluded ,
				 'Lease management company' =>$this->strLeaseManagementCompany ,
				 'lease sitting tenants' =>$this->boolLeaseSittingTenants ,
				 'agency type' =>$this->strAgencyType ,
				 'agency period' =>$this->strAgencyPeriod ,	 
				 'Solicitors company name' =>$this->strSolicitorCompanyName ,
				 'Vendor Solicitors address' =>$this->strVendorSolicitorAddress ,
				 'Vendor Solicitors Phone Number' =>$this->strVendorSolPhoneNum ,
				 'Vendor Solicitors Contact Name' =>$this->strVendorSolContactName ,
				 'Vendor Solicitors Fax number' =>$this->strVendorSolFaxNum ,
				 'Vendor Solicitors mobile number' =>$this->strVendorSolMobileNum ,
				 'Vendor Solicitors Email' =>$this->strVendorSolEmail ,
				 'Vendor Property Address' =>$this->strVendorPropertyAddress ,
				 'Joint Vendor Address' =>$this->strJointVendorAdress ,
				 'Vendor Soloicitor salutation' =>$this->strVendorSolSalutation ,	
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("Property Letter");
			}

}
?>