<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class InFsVendorLetter extends EntityBase implements IEntityObject 
{ 
		 public $strAptID  =" ";
		 public $fs_appointment_notes = "Name :Mr. Bogart Contact Number :555 123456 [H] Address :65, High Av Easton, Bristol, England, GH1 1HU [Google Map] 	Tenure :Freehold Property :For Sale [Residential - Sheltered Housing] 	Price :  �123,456 Property Ref. : 100053 Total Area : 0&#39; 0&#39;&#39;   [ 0.00 m x m] Contact Vendor By : Post";
		 public $fs_appointment_date = "01.10.1900";
		 public $fs_appointment_time = "23:00";
		 public $fs_appointment_duration = "60min";
		 public $strFsAppoinmantperson = "John West";
		 public $PropertyKey = "100010";
		 public $strPropertyId = "10";
		 public $strVendorUsername = "user";
		 public $strVendorPassword = "passoword";
		 public $strJVendorUsername = "user";
		 public $strJVendorPassword = "passowrd";
		 public $strVendorAddress = "23, fake street, branksome,poole, bh15 6yp, dorset"; 
		 public $strVendorName = "Mr.J John Johnson";
		 public $strVendorPhoneNum = "010208976554";
		 public $strVendorBusinessPhonenum = "0102984659";
		 public $strVendorMobileNum = "010208976554";
		 public $strVendorFaxNum = "874185019357";
		 public $strVendorEmail = "someone@someplace";
		 public $boolVendorAllowPost = "false";
		 public $boolVendorAllowSms = "false";
		 public $boolVendorAllowEmail = "false";
		 public $strJVendorName = "Miss Jenny Penny";
		 public $strJVendorPhoneNum = "010208976554";
		 public $strJVendorMobileNum = "09788654643321";
		 public $strJVendorFaxNum = "874185019357";
		 public $strJVendorEmail = "someone@someplace"; 
		 public $strJVendorBusinessPhoneNumber = "012020338655";
		 public $boolJVendorAllowPost = "false";
		 public $boolJVendorAllowSms = "false";
		 public $boolJVendorAllowEmail = "false";
		 public $strVendorSalutation = "DR no";
		 public $strPropComanyName = "rent b4 u buy";
		 public $strpropAddress = "23, fake street,branksome,Poole,bh1 1 rp, dorset";
		 public $strPropType = "semi detached";
		 public $strPropStatus = "Sale";
		 public $strpropBedroomNum = "3";
		 public $strpropRecptions = "1";
		 public $strPropBathrooms = "2";
		 public $strPropAskingPrice = "150,000.00";
		 public $strPropValuationPrice = "180,000.00";
		 public $strQuickSellPrice = "140,000.00";
		 public $strTestMarketPrice = "160,000.00";
		 public $strVendoropinionPrice = "200,000.00";
		 public $strCurrentPrice = "180,000.00";
		 public $strBranch = "1";
		 public $strBranchPhoneNum = "980634521";
		 public $strBranchFaxNum = "97892865975";
		 public $strBranchEmail = "someone@someplace.com";
		 public $strSalesStatus = "exchnage";
		 public $strRentalPeriod = "12 Month renewable";
		 public $strLettingAvailableDate = "12.01.2007";
		 public $boolFurnished  = "false";
		 public $boolLift  = "false";
		 public $strTube = "1";
		 public $boolAllowSmoker = "false";
		 public $boolAllowStudent = "false";
		 public $boolAllowChildren = "false";
		 public $boolAllowPets = "false";
		 public $strVendorNegotiator = "james gibbson";
		 public $strpropBrief = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses";
		 public $strPropDescription = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";
		 public $strViewingRequirements = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";
		 public $strPropertyLocation = "Winton, Dorset,England";
		 public $strInstructedDate = "12.01.2007";
		 public $strPopTenure = "Freehold";
		 public $strPriceDescription = "Guide Price";
		 public $strVendorPosition = "Cash Buyer";
		 public $strPropCategory = "Residental";
		 public $strPropSubCategory = "Investment property";
		 public $strAdvertDescription = "just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential";
		 public $strSolicitorCompanyName = "MRA Financial Services";
		 public $strVendorSolicitorAddress = "23, fake street,branksome,Poole,bh11rp,Dorset";
		 public $strVendorSolPhoneNum = "01202346586";
		 public $strVendorSolContactName = "jimmy riddle";
		 public $strVendorSolCompanyName = "the firm";
		 public $strVendorSolFaxNum = "0923830972348";
		 public $strVendorSolMobileNum = "018378623845";
		 public $strVendorSolEmail = "someone@someplace.com";
		 public $strVendorPropertyAddress = "23, fake street,branksome,bh11rp,poole ,dorset";
		 public $strJointVendorAdress = "23, fake street,branksome,bh11rp,poole ,dorset";
		 public $strVendorSolSalutation = "DR no";

				
		
		 public function getProperties()
			{
				$resultarray = array(
				 	 'aptId'=>$this->strAptID ,
					 'appointment notes'=>$this->fs_appointment_notes ,
					 'appointment date'=>$this->fs_appointment_date ,
					 'appointment time'=>$this->fs_appointment_time,
					 'appointment duration'=>$this->fs_appointment_duration ,
					 'apointment person'=>$this->strFsAppoinmantperson ,
					 'property key'=>$this->PropertyKey,
					 'Property id'=>$this->strPropertyId ,
					 'Vendor username'=>$this->strVendorUsername,
					 'Vendor Password'=>$this->strVendorPassword ,
					 'Joint Vendor Username'=>$this->strJVendorUsername ,
					 'Joint Vendor'=>$this->strJVendorPassword ,
					 'Vendor address'=>$this->strVendorAddress ,
					 'Vendor name'=>$this->strVendorName ,
					 'Vendor Phone Number'=>$this->strVendorPhoneNum ,
					 'Vendor business Number'=>$this->strVendorBusinessPhonenum ,
					 'Vendor Mobile number'=>$this->strVendorMobileNum ,
					 'Vendor fax number'=>$this->strVendorFaxNum ,
					 'Vendor Email'=>$this->strVendorEmail ,
					 'Vendor allow post'=>$this->boolVendorAllowPost ,
					 'Vendor allow SMS'=>$this->boolVendorAllowSms ,
					 'Vendor allow Email'=>$this->boolVendorAllowEmail ,
					 'Joint Vendor name'=>$this->strJVendorName ,
					 'Joint Vendor phone number'=>$this->strJVendorPhoneNum,
					 'Joint Vendor Mobile number'=>$this->strJVendorMobileNum,
					 'Joint Vendor Fax number'=>$this->strJVendorFaxNum ,
					 'Joint Vendor Email'=>$this->strJVendorEmail ,
					 'Joint Vendor Phone Number'=>$this->strJVendorBusinessPhoneNumber,
					 'Joint Vendor allow post'=>$this->boolJVendorAllowPost ,
					 'Joint Vendor allow SMS'=>$this->boolJVendorAllowSms ,
					 'Joint Vendor allow Email'=>$this->boolJVendorAllowEmail ,
					 'Vendor Salutation'=>$this->strVendorSalutation,
					 'Property company name'=>$this->strPropComanyName,
					 'Property address'=>$this->strpropAddress ,
					 'Property type'=>$this->strPropType ,
					 'Property status'=>$this->strPropStatus ,
					 'Property bedrooms'=>$this->strpropBedroomNum ,
					 'Property receptions'=>$this->strpropRecptions ,
					 'Property bathrooms'=>$this->strPropBathrooms ,
					 'Property asking price'=>$this->strPropAskingPrice ,
					 'Property valuation price'=>$this->strPropValuationPrice ,
					 'Quick sale price'=>$this->strQuickSellPrice ,
					 'test market price'=>$this->strTestMarketPrice,
					 'Vendor opinion price'=>$this->strVendoropinionPrice ,
					 'Current price'=>$this->strCurrentPrice,
					 'Branch'=>$this->strBranch ,
					 'Branch Phone Number'=>$this->strBranchPhoneNum,
					 'Branch fax number'=>$this->strBranchFaxNum ,
					 'Branch Email'=>$this->strBranchEmail ,
					 'Sales status'=>$this->strSalesStatus,
					 'Rental period'=>$this->strRentalPeriod,
					 'Available from'=>$this->strLettingAvailableDate,
					 'furnished'=>$this->boolFurnished ,
					 'lift'=>$this->boolLift ,
					 'Tube'=>$this->strTube ,
					 'allow smokers'=>$this->boolAllowSmoker ,
					 'allow Students'=>$this->boolAllowStudent,
					 'allow Children'=>$this->boolAllowChildren,
					 'allow Pets'=>$this->boolAllowPets ,
					 'Vendor negotiator'=>$this->strVendorNegotiator,
					 'Property Brief description'=>$this->strpropBrief ,
					 'Property description'=>$this->strPropDescription ,
					 'Viewing Requirements'=>$this->strViewingRequirements ,
					 'Property location'=>$this->strPropertyLocation ,
					 'Instructed date'=>$this->strInstructedDate ,
					 'Tenure'=>$this->strPopTenure ,
					 'Price descrpition'=>$this->strPriceDescription ,
					 'Vendor Position'=>$this->strVendorPosition,
					 'Property catergory'=>$this->strPropCategory ,
					 'Property sub catergory'=>$this->strPropSubCategory ,
					 'Advertising description'=>$this->strAdvertDescription ,
					 'Solicitor company name'=>$this->strSolicitorCompanyName,
					 'Vendor Solicitor address'=>$this->strVendorSolicitorAddress ,
					 'Vendor Solicitor phone number'=>$this->strVendorSolPhoneNum ,
					 'Vendor Solicitor contact name'=>$this->strVendorSolContactName ,
					 'Vendor Solicitor company name'=>$this->strVendorSolCompanyName ,
					 'Vendor Solicitor fax  number'=>$this->strVendorSolFaxNum ,
					 'Vendor Solicitor  mobile number'=>$this->strVendorSolMobileNum ,
					 'Vendor Solicitor eamil'=>$this->strVendorSolEmail ,
					 'Vendor Address'=>$this->strVendorPropertyAddress ,
					 'joint Vendor address'=>$this->strJointVendorAdress ,
					 'Vendor Solicitor'=>$this->strVendorSolSalutation ,	
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("InFsVendorLetter");
			}

}
?>