<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class ValuationLetter extends EntityBase implements IEntityObject 
{ 
		  
		 	//@property object for letter and brochure
		 	//@takes the attributes from the database
		 	//@and wraps them into the object
			public $strPropertyKey ="100010";
			public $strPropertyId = "10"; 	
			public $strVendorName = "mr John j Johnston";
			public $strVendorHomePhone= "082459134613567"; 
			public $strVendorBusPhone= "082459134613567"; 
			public $strVendorMobileNo= "082459134613567"; 
			public $strVendorFaxNo= "082459134613567"; 
			public $strVendorEmail="someone@somwhere.co.uk";
			public $strVendorUsername = "user";
			public $strVendorPassword = "passoword";
			public $strVendorNegotiator = "Jems gibbson";
			public $strJointVendorName ="mr,micheal,j, john";
			public $strJointVendorPhoneNo= "082459134613567"; 
			public $strJointVendorBusPhone= "082459134613567"; 
			public $strJointVendorMobileNo= "082459134613567"; 
			public $strJointVendorFaxNo= "082459134613567"; 
			public $strJointVendorEmail="someone@somwhere.co.uk"; 
			public $strVendorSalutation ="dr, johnston"; 
			public $strJVendorUsername = "user";
		 	public $strJVendorPassword = "passowrd";
			public $strCompanyName = "the firm";
			public $strVendorPropertAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strJointVendorAddress="123, fake street,branksome,poole,bh11rp,dorset, england";	 
			Public $strPropertyAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strPropertyFor ="";
			public $strPropType = "semi detached"; 
			public $strPropertyBedrooms=""; 
			public $strPropertyReceptions=""; 
			public $strPropertyBathrooms="";
			public $strPropertyAge = "33";
			public $strPropCategory = "Residental";
		    public $strPropSubCategory = "Investment property"; 
			public $strPropertyAskingPrice=""; 
			public $strPropertyValuationPrice=""; 
			public $strPropertyQuickSellPrice="";
			public $strPropertyTestMarketPrice=""; 
			public $strPropertyVendorOpinionPrice=""; 
			public $strPropertyCurrentPrice=""; 
			public $strCancelDate = "01.10.2000";
			public $strLostToEstateAgent = "This was lost due to lazy consultants";
			public $strCancelReason = "sold there selves";
			public $strCancelNotes = "if we had been on the ball a bit more then we would have";
 			public $strContactDate = "01.01.2000";
 			public $strPropertyBranch = "branch name"; 
			public $strPropertyBranchPhoneno= "082459134613567"; 
			public $strPropertyBranchFaxno= "082459134613567"; 
			public $strPropertyBranchEmail="someone@somwhere.co.uk"; 
			public $strPropertySaleStatus=""; 
			public $strPropertyNegotiator=""; 
			public $strPropertyBriefDescription=""; 
			public $strPropertyInstructedDate="";
			public $strVendorSolicitorCompanyName = "the firm"; 
			public $strVendorSolAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strVendor_solicitor_phoneno= "082459134613567"; 
			public $strVendor_solicitor_faxno= "082459134613567"; 
			public $strVendor_solicitor_contact_name ="john"; 
			public $strVendor_solicitor_mobileno= "082459134613567"; 
			public $strVendor_solicitor_email="someone@somwhere.co.uk"; 
			public $strVendor_solicitor_salutation=""; 
			public $strVendor_allow_sms="yes"; 
			public $strVendor_allow_email="yes"; 
			public $strVendor_allow_post="yes"; 
			public $strJoint_vendor_allow_sms="yes"; 
			public $strJoint_vendor_allow_email="yes"; 
			public $strJoint_vendor_allow_post="yes";

		
		 public function getProperties()
			{
				$resultarray = array(
				 
					'Property Key' => $this->strPropertyKey, 	
					'Property Id' => $this->strPropertyId, 
					'Vendor name' => $this->strVendorName,
					'Vendor Home Phone Number' => $this->strVendorHomePhone, 
					'Vendor Buisness Number' => $this->strVendorBusPhone, 
					'Vendor Mobile Number' => $this->strVendorMobileNo, 
					'Vendor fax Number' => $this->strVendorFaxNo, 
					'Vendor Email' => $this->strVendorEmail,
					'Vendor salutation'=>$this->strVendorSalutation,
					'Vendor username' =>$this->strVendorUsername ,
				 	'Vendor Password' =>$this->strVendorPassword ,
				 	'Joint Vendor Username' =>$this->strJVendorUsername ,
				 	'Joint Vendor Password' =>$this->strJVendorPassword ,
					'Joint Vendor name' => $this->strJointVendorName,
					'Joint Vendor Phne Number' => $this->strJointVendorPhoneNo, 
					'Joint Vendor Buisness number' => $this->strJointVendorBusPhone, 
					'Joint Vendor Mobile Number' => $this->strJointVendorMobileNo, 
					'Joint Vendor fax Number' => $this->strJointVendorFaxNo, 
					'Joint Vendor email' => $this->strJointVendorEmail, 
					'Joint Vendor salutation' => $this->strVendorSalutation, 
					'Property Company name' => $this->strCompanyName,	 
					'Property Address' => $this->strPropertyAddress,
					'Property For' => $this->strPropertyFor, 
					'property type' =>$this->strPropType ,
					'Property age'=>$this->strPropertyAge,
					'Property Bedrooms' => $this->strPropertyBedrooms, 
					'Property receptions' => $this->strPropertyReceptions, 
					'Property Bathrooms' => $this->strPropertyBathrooms, 
					'Property asking price' => $this->strPropertyAskingPrice, 
					'Property valuation Price' => $this->strPropertyValuationPrice, 
					'Property Quick sell price' => $this->strPropertyQuickSellPrice,
					'Property test market price' => $this->strPropertyTestMarketPrice, 
					'Property vendor opinion' => $this->strPropertyVendorOpinionPrice, 
					'Property current price' => $this->strPropertyCurrentPrice, 
					'Property Branch' => $this->strPropertyBranch, 
					'Property Branch Phone Number'  => $this->strPropertyBranchPhoneno, 
					'Property Branch fax Number' => $this->strPropertyBranchFaxno, 
					'Property Branch email' => $this->strPropertyBranchEmail, 
					'Property sales status' => $this->strPropertySaleStatus, 
					'Property catergory' =>$this->strPropCategory ,
				 	'Property sub catergory' =>$this->strPropSubCategory ,
					'Vendor Negotiator' => $this->strVendorNegotiator, 
					'cancel date'=>$this->strCancelDate,
					'Lost Estate Agency'=>$this->strLostToEstateAgent,
					'Cancel reason'=>$this->strCancelReason,
					'cancel notes'=>$this->strCancelNotes,
					'Contacted date'=>$this->strContactDate,
					'Property brief description' => $this->strPropertyBriefDescription, 
					'Property Instructed Date' => $this->strPropertyInstructedDate,
					'Vendor Solicitor company name' => $this->strVendorSolicitorCompanyName, 
					'Vendor Solicitor Address' => $this->strVendorSolAddress,
					'Vendor Solicitor Phone Number' => $this->strVendor_solicitor_phoneno, 
					'Vendor Solicitor Fax Number' => $this->strVendor_solicitor_faxno, 
					'Vendor Solicitor contact name' => $this->strVendor_solicitor_contact_name, 
					'Vendor Solicitor Mobile Number' => $this->strVendor_solicitor_mobileno, 
					'Vendor Solicitor email' => $this->strVendor_solicitor_email, 
					'Vendor Solicitor Salutaion' => $this->strVendor_solicitor_salutation, 
					'Vendor porperty address' => $this->strVendorPropertAddress,
					'Joint Vendor address' => $this->strJointVendorAddress,
					'Vendor Allow sms' => $this->strVendor_allow_sms, 
					'Vendor Allow email' => $this->strVendor_allow_email, 
					'Vendor Allow post' => $this->strVendor_allow_post, 
					'Joint Vendor Allow sms' => $this->strJoint_vendor_allow_sms, 
					'Joint Vendor Allow email' => $this->strJoint_vendor_allow_email, 
					'Joint Vendor Allow post' => $this->strJoint_vendor_allow_post,	
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("Valuation Letter");
			}

}
?>