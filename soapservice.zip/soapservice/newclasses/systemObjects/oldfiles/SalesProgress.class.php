<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class SalesProgress extends EntityBase implements IEntityObject 
{ 
			public $stroffer_id;
			public $strap_id;
			public $strprop_id;
			public $stroffer_amount;
			public $stroffer_date;
			public $stroffer_time;
			public $strsales_offer_accept_date;
			public $strsales_offer_accept_time;
			public $strsales_offer_accept_details;	
			public $strproperty_key;			
			public $strvendorName;		
				
		
		 public function getProperties()
			{
				$resultarray = array(
				 	'offer id ' =>$this->stroffer_id,
					'Applicant Id ' =>$this->strap_id,
					'Property Id ' =>$this->strprop_id,
					'Offer amount ' =>$this->stroffer_amount ,
					'Offer Datte ' =>$this->stroffer_date ,
					'Offer Time ' =>$this->stroffer_time,
					'Offer Accepted date' =>$this->strsales_offer_accept_date,
					'Offer Accepted Time' =>$this->strsales_offer_accept_time,
					'Offer accepted  Details ' =>$this->strsales_offer_accept_details,
					'Appliacnt Key' =>$this->strapplicant_key,
					'appliacnat Name' =>$this->strApplicantName,
					
					'Applicant Phone number' =>$this->strapplicant_home_phone,
					'Applicant Business number' =>$this->strapplicant_bus_phone,
					'Applicant Fax Number ' =>$this->strapplicant_fax_no,
					'Applicant email ' =>$this->strapplicant_email,
					'Applicant mobile number' =>$this->strapplicant_mobile_no,
					'Applicant Salutation ' =>$this->strapplicant_salutation,
					'Joint applicant Name ' =>$this->strjoint_vendor_name,
			
					' ' =>$this->strjoint_applicant_home_phone,
					' ' =>$this->strjoint_applicant_bus_phone,
					' ' =>$this->strjoint_applicant_email,
					' ' =>$this->strjoint_applicant_fax_no,
					' ' =>$this->strjoint_applicant_mobile_no,
					' ' =>$this->strapplicant_company_name,
					' ' =>$this->strapplicant_negotiator,
					' ' =>$this->strapplicant_property_no,
					' ' =>$this->strapplicant_property_name,
					' ' =>$this->strapplicant_address1_no,
					' ' =>$this->strapplicant_address1_name,
					' ' =>$this->strapplicant_address2,
					' ' =>$this->strapplicant_address3,
					' ' =>$this->strapplicant_postcode,
					' ' =>$this->strapplicant_town,
					' ' =>$this->strapplicant_county,
					' ' =>$this->strapplicant_country,
					' ' =>$this->strapplicant_branch,
					' ' =>$this->strapplicant_branch_phone_no,
					' ' =>$this->strapplicant_branch_fax_no,
					' ' =>$this->strapplicant_branch_email,
					' ' =>$this->strapplicant_solicitor_company_name,
					' ' =>$this->strapplicant_solicitor_address1_no,
					' ' =>$this->strapplicant_solicitor_address1_name,
					' ' =>$this->strapplicant_solicitor_address2,
					' ' =>$this->strapplicant_solicitor_address3,
					' ' =>$this->strapplicant_solicitor_town ,
					' ' =>$this->strapplicant_solicitor_county,
					' ' =>$this->strapplicant_solicitor_country,
					' ' =>$this->strapplicant_solicitor_postcode,
					' ' =>$this->strapplicant_solicitor_phoneno,
					' ' =>$this->strapplicant_solicitor_faxno,
					' ' =>$this->strapplicant_solicitor_contact_name,
					' ' =>$this->strapplicant_solicitor_mobileno,
					' ' =>$this->strapplicant_solicitor_email,
					' ' =>$this->strapplicant_solicitor_salutation,
					' ' =>$this->strproperty_key,
					' ' =>$this->strvendor_title,
					' ' =>$this->strvendor_initials,
					' ' =>$this->strvendor_first_name,
					' ' =>$this->strvendor_sur_name,
					' ' =>$this->strvendor_home_phone,
					' ' =>$this->strvendor_bus_phone,
					' ' =>$this->strvendor_mobile_no,
					' ' =>$this->strvendor_fax_no,
					' ' =>$this->strvendor_email,
					' ' =>$this->strjoint_vendor_title,
					' ' =>$this->strjoint_vendor_first_name,
					' ' =>$this->strjoint_vendor_initials,
					' ' =>$this->strjoint_vendor_sur_name,
					' ' =>$this->strjoint_vendor_home_phone,
					' ' =>$this->strjoint_vendor_bus_phone,
					' ' =>$this->strjoint_vendor_mobile_no,
					' ' =>$this->strjoint_vendor_fax_no,
					' ' =>$this->strjoint_vendor_email,
					' ' =>$this->strvendor_salutation,
					' ' =>$this->strcompany_name,
					' ' =>$this->strproperty_no ,
					' ' =>$this->strproperty_name,
					' ' =>$this->strproperty_address1_no,
					' ' =>$this->strproperty_address1_name,
					' ' =>$this->strproperty_address2,
					' ' =>$this->strproperty_address3,
					' ' =>$this->strproperty_town,
					' ' =>$this->strproperty_county,
					' ' =>$this->strproperty_country,
					' ' =>$this->strproperty_postcode,
					' ' =>$this->strproperty_for,
					' ' =>$this->strproperty_bedrooms,
					' ' =>$this->strproperty_receptions,
					' ' =>$this->strproperty_bathrooms,
					' ' =>$this->strproperty_current_price,
					' ' =>$this->strproperty_branch,
					' ' =>$this->strproperty_branch_phoneno,
					' ' =>$this->strproperty_branch_faxno,
					' ' =>$this->strproperty_branch_email,
					' ' =>$this->strproperty_sale_status,
					' ' =>$this->strproperty_negotiator,
					' ' =>$this->strproperty_brief_description,
					' ' =>$this->strproperty_instructed_date,
					' ' =>$this->strvendor_solicitor_company_name,
					' ' =>$this->strvendor_solicitor_address1_no,
					' ' =>$this->strvendor_solicitor_address1_name,
					' ' =>$this->strvendor_solicitor_address2,
					' ' =>$this->strvendor_solicitor_address3,
					' ' =>$this->strvendor_solicitor_town,
					' ' =>$this->strvendor_solicitor_county ,
					' ' =>$this->strvendor_solicitor_country,
					' ' =>$this->strvendor_solicitor_postcode,
					' ' =>$this->strvendor_solicitor_phoneno,
					' ' =>$this->strvendor_solicitor_faxno,
					' ' =>$this->strvendor_solicitor_contact_name,
					' ' =>$this->strvendor_solicitor_mobileno,
					' ' =>$this->strvendor_solicitor_email,
					' ' =>$this->strvendor_solicitor_salutation,
					' ' =>$this->strvendor_property_no,
					' ' =>$this->strvendor_property_name,
					' ' =>$this->strvendor_address1_no,
					' ' =>$this->strvendor_address1_name,
					' ' =>$this->strvendor_address2,
					' ' =>$this->strvendor_address3,
					' ' =>$this->strvendor_town,
					' ' =>$this->strvendor_county,
					' ' =>$this->strvendor_country,
					' ' =>$this->strvendor_postcode,
					' ' =>$this->strjoint_vendor_property_no,
					' ' =>$this->strjoint_vendor_property_name,
					' ' =>$this->strjoint_vendor_address1_no,
					' ' =>$this->strjoint_vendor_address1_name,
					' ' =>$this->strjoint_vendor_address2,
					' ' =>$this->strjoint_vendor_address3,
					' ' =>$this->strjoint_vendor_town,
					' ' =>$this->strjoint_vendor_county,
					' ' =>$this->strjoint_vendor_country,
					' ' =>$this->strjoint_vendor_postcode,
					' ' =>$this->strvendor_allow_sms,
					' ' =>$this->strvendor_allow_email,
					' ' =>$this->strvendor_allow_post,
					' ' =>$this->strjoint_vendor_allow_sms,
					' ' =>$this->strjoint_vendor_allow_email,
					' ' =>$this->strjoint_vendor_allow_post,
					' ' =>$this->strapplicant_allow_sms,
					' ' =>$this->strapplicant_allow_email,
					' ' =>$this->strapplicant_allow_post,
					' ' =>$this->strjoint_applicant_allow_sms,
					' ' =>$this->strjoint_applicant_allow_email,
					' ' =>$this->strjoint_applicant_allow_post,
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("Valuation Letter");
			}

}
?>