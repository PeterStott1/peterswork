<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OutFsVendorLetter extends EntityBase implements IEntityObject 
{ 

		 public $strAptID  =" ";
		 public $strFsContactId = "1";
		 public $strFsCotid = "3";
		 public $strFsAppoinmantperson = "John West";
		 public $strFsposition = "manager";
		 public $strFsBrAddress = "23, fake street,branksome,poole,dorset";
		 public $strPhoneNum = "01202 78565";
		 public $strMobileNum = "0798675432";
		 public $strSalutation = "dr Johnston"; 
		 public $strEmail = "someone@somewhere";
		 public $strFsPrimaryContact = "Johnathan wilbert";
		 public $strNegotiator = "jimmy riddle";
		 public $strSameCompany = "tes"; 
		 public $strCotCat = "3";
		 public $strCompanyName = "rubic on";
		 public $strCompAddress = "23, fake street,branksome,poole,dorset";
		 public $strCompanyPhoneNum = "01202 675433";
		 public $strCompanyFaxNum = "01202 576483";
		 public $strCompanyDXRef = "pok979364gte2088";
		 public $strCompanyNegotiator = "jimmy riddle";
		 public $strCompanyTerms = "this comany will provide free evaluation for your property";
		 public $strCompanyEmail = "someone@someplace";
		 public $strCompanyNotes = "popular company yeah";
		 public $ConcatName = "financial advisor";
		 public $PropertyKey = "100010";
		 public $strPropertyId = "10";
		 public $strViewVendorLetter = "micheal";
		 public $strVendorPassword = "passoword";
		 public $strVendorSalutation = "DR no";
		 public $strVendorName = "Mr.John Johnson";
		 public $strVendorAddress = "23, fake street, branksome,poole, bh15 6yp, dorset";
		 public $strVendorPhoneNum = "010208976554";
		 public $strVendorFaxNum = "874185019357";
		 public $strVendorMobileNum = "010208976554";
		 public $strVendorBusinessPhonenum = "0102984659";
		 public $strVendorEmail = "someone@someplace";
		 public $strJVendorUsername = "user";
		 public $strJVendorPassword = "passowrd";
		 public $strJVendorName = "Miss Jenny Penny";
		 public $strJVendorPhoneNum = "010208976554";
		 public $strJVendorMobileNum = "09788654643321";
		 public $strJVendorFaxNum = "874185019357";
		 public $strJVendorEmail = "someone@someplace";
		 public $boolVendorAllowPost = "false";
		 public $boolVendorAllowSms = "false";
		 public $boolVendorAllowEmail = "false";
		 public $strJVendorBusinessPhoneNumber = "012020338655";
		 public $boolJVendorAllowPost = "false";
		 public $boolJVendorAllowSms = "false";
		 public $boolJVendorAllowEmail = "false";
		 public $strPropComanyName = "rent b4 u buy";
		 public $strpropAddress = "23, fake street,branksome,Poole,bh1 1 rp, dorset";
		 public $strPropType = "semi detached";
		 public $strPropStatus = "Sale";
		 public $strpropBedroomNum = "3";
		 public $strpropRecptions = "1";
		 public $strPropBathrooms = "2";
		 public $strPropAskingPrice = "150,000.00";
		 public $strPropValuationPrice = "180,000.00";
		 public $strQuickSellPrice = "140,000.00";
		 public $strTestMarketPrice = "160,000.00";
		 public $strVendoropinionPrice = "200,000.00";
		 public $strCurrentPrice = "180,000.00";
		 public $strBranch = "1";
		 public $strBranchPhoneNum = "980634521";
		 public $strBranchFaxNum = "97892865975";
		 public $strBranchEmail = "someone@someplace.com";
		 public $strSalesStatus = "exchnage";
		 public $strRentalPeriod = "12 Month renewable";
		 public $strLettingAvailableDate = "12.01.2007";
		 public $strfloorNo = "2";
		 public $boolFurnished  = "false";
		 public $boolLift  = "false";
		 public $strPropCondition ="good";
		 public $strTube = "1";
		 public $boolAllowSmoker = "false";
		 public $boolAllowStudent = "false";
		 public $boolAllowChildren = "false";
		 public $boolAllowPets = "false";
		 public $strVendorNegotiator = "james gibbson";
		 public $strpropBrief = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses";
		 public $strPropDescription = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";
		 public $strViewingRequirements = "Kingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential arsasasasdadasddasdsadassasdasdsaKingsfield House is a development of just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses.";
		 public $strPropertyLocation = "Winton, Dorset,England";
		 public $strInstructedDate = "12.01.2007";
		 public $strPopTenure = "Freehold";
		 public $strPriceDescription = "Guide Price";
		 public $strVendorPosition = "Cash Buyer";
		 public $strPropCategory = "Residental";
		 public $strPropSubCategory = "Investment property";
		 public $strAdvertDescription = "just 8 luxury 3 bedroom apartments along with 2 exclusive 3 bedroom coach houses. The development is located within the much sought after residential";
		 public $strSolicitorCompanyName = "MRA Financial Services";
		 public $strVendorSolicitorAddress = "23, fake street,branksome,Poole,bh11rp,Dorset";
		 public $strVendorSolPhoneNum = "01202346586";
		 public $strVendorSolContactName = "jimmy riddle";
		 public $strVendorSolName = "the firm";
		 public $strVendorSolFaxNum = "0923830972348";
		 public $strVendorSolMobileNum = "018378623845";
		 public $strVendorSolEmail = "someone@someplace.com";
		 public $strVendorPropertyAddress = "23, fake street,branksome,bh11rp,poole ,dorset";
		 public $strJointVendorAdress = "23, fake street,branksome,bh11rp,poole ,dorset";
		 public $strVendorSolSalutation = "DR no";

		 public function getProperties()
			{
				$resultarray = array(
				'aptID' =>$this->strAptID,
				'contactId' => $this->strFsContactId ,
				 'Cotid' => $this->strFsCotid ,
				 'appointment person' =>$this->strFsAppoinmantperson,
				 'Position' =>$this->strFsposition,
				 'branch address' =>$this->strFsBrAddress,
				 'Branch phone number' =>$this->strPhoneNum,
				 'Branch mobile number' =>$this->strMobileNum ,
				 'Branch Salutation' =>$this->strSalutation ,
				 'Branch email' =>$this->strEmail,
				 'Branch Primary Contact' =>$this->strFsPrimaryContact ,
				 'Branch negotiator' =>$this->strNegotiator ,
				 'Same company' =>$this->strSameCompany ,
				 'cot cat' =>$this->strCotCat ,
				 'Company name' =>$this->strCompanyName ,
				 'Company Address' =>$this->strCompAddress ,
				 'Company Phone Number' =>$this->strCompanyPhoneNum ,
				 'Company Fax Number' =>$this->strCompanyFaxNum ,
				 'Company DX reference' =>$this->strCompanyDXRef,
				 'Company Negotiator' =>$this->strCompanyNegotiator,
				 'Company Terms' =>$this->strCompanyTerms ,
				 'CompanyEmail' =>$this->strCompanyEmail ,
				 'Company Notes' =>$this->strCompanyNotes,
				 'Company Name' =>$this->ConcatName ,
				 'Property Key' =>$this->PropertyKey ,
				 'Property Id' =>$this->strPropertyId ,
				 'View Vendor Letter' =>$this->strViewVendorLetter,
				 'Vendor Password' =>$this->strVendorPassword ,
				 'Vendor salutation' =>$this->strVendorSalutation ,
				 'Vendor Name' =>$this->strVendorName ,
				 'Vendor Address' =>$this->strVendorAddress ,
				 'Vendor Phone Number' =>$this->strVendorPhoneNum,
				 'Vendor fax Number' =>$this->strVendorFaxNum ,
				 'Vendor Mobile Nuber' =>$this->strVendorMobileNum ,
				 'Vendor Business Number' =>$this->strVendorBusinessPhonenum ,
				 'Vendor email' =>$this->strVendorEmail ,
				 'Joint Vendor Username' =>$this->strJVendorUsername ,
				 'Joint Vendor Password' =>$this->strJVendorPassword ,
				 'Joint Vendor Name' =>$this->strJVendorName ,
				 'Joint Vendor Phone Number' =>$this->strJVendorPhoneNum ,
				 'Joint Vendor Mobile Phone Number' =>$this->strJVendorMobileNum ,
				 'Joint Vendor Fax Number' =>$this->strJVendorFaxNum ,
				 'Joint Vendor email' =>$this->strJVendorEmail ,
				 'Branch' =>$this->boolVendorAllowPost,
				 'Branch' =>$this->boolVendorAllowSms ,
				 'Branch' =>$this->boolVendorAllowEmail ,
				 'Joint Vendor Buisiness Phine Number' =>$this->strJVendorBusinessPhoneNumber ,
				 'Joint Vendor Post' =>$this->boolJVendorAllowPost ,
				 'Joint Vendor Sms'  =>$this->boolJVendorAllowSms ,
				 'Joint Vendor Email' =>$this->boolJVendorAllowEmail ,
				 'Property Company Name' =>$this->strPropComanyName ,
				 'Property address' =>$this->strpropAddress ,
				 'Property type' =>$this->strPropType ,
				 'Property status' =>$this->strPropStatus,
				 'Property bedroom' =>$this->strpropBedroomNum ,
				 'Property reception' =>$this->strpropRecptions ,
				 'Property Bathrooms' =>$this->strPropBathrooms ,
				 'Property Asing price' =>$this->strPropAskingPrice,
				 'Property Valuation price' =>$this->strPropValuationPrice,
				 'Quivk sell Price' =>$this->strQuickSellPrice ,
				 'Test Market price' =>$this->strTestMarketPrice ,
				 'Vendor Opinion price' =>$this->strVendoropinionPrice,
				 'Current price' =>$this->strCurrentPrice ,
				 'Branch' =>$this->strBranch ,
				 'Branch phone number' =>$this->strBranchPhoneNum,
				 'Branch fax number'  =>$this->strBranchFaxNum ,
				 'Branch Email' =>$this->strBranchEmail ,
				 'Sales status' =>$this->strSalesStatus ,
				 'Rental Period' =>$this->strRentalPeriod ,
				 'Letting available date' =>$this->strLettingAvailableDate ,
				 'floor numbers' =>$this->strfloorNo ,
				 'Furnished' =>$this->boolFurnished,
				 'lift' =>$this->boolLift,
				 'Property Condition' =>$this->strPropCondition,
				 'Tube' =>$this->strTube,
				 'Allow Smoker' =>$this->boolAllowSmoker,
				 'Allow Student' =>$this->boolAllowStudent,
				 'Allow Children' =>$this->boolAllowChildren,
				 'Allow pets' =>$this->boolAllowPets,
				 'Vnedor Negotiator' =>$this->strVendorNegotiator,
				 'property brief description' =>$this->strpropBrief,
				 'Property description' =>$this->strPropDescription,
				 'Viewing Requirements' =>$this->strViewingRequirements,
				 'property location' =>$this->strPropertyLocation ,
				 'Instructed date' =>$this->strInstructedDate,
				 'Tenure' =>$this->strPopTenure,
				 'Price Description' =>$this->strPriceDescription ,
				 'Vendor position' =>$this->strVendorPosition ,
				 'Property Catergory' =>$this->strPropCategory ,
				 'Property sub Catergory' =>$this->strPropSubCategory,
				 'Advertising description' =>$this->strAdvertDescription,
				 'Solicitor Company Name' =>$this->strSolicitorCompanyName,
				 'Vendor Solicitor' =>$this->strVendorSolicitorAddress,
				 'Vendor Solicitor' =>$this->strVendorSolPhoneNum,
				 'Vendor Solicitor' =>$this->strVendorSolContactName,
				 'Vendor Solicitor' =>$this->strVendorSolName,
				 'Vendor Solicitor' =>$this->strVendorSolFaxNum,
				 'Vendor Solicitor' =>$this->strVendorSolMobileNum,
				 'Vendor Solicitor' =>$this->strVendorSolEmail,
				 'Vendor Solicitor' =>$this->strVendorPropertyAddress,
				 'Joint Vendor' =>$this->strJointVendorAdress,
				 'Vendor Solicitor' => $this->strVendorSolSalutation,
						
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("OutFsVendorLetter");
			}

}
?>