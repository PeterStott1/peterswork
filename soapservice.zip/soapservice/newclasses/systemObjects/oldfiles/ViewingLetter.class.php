<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class ViewingLetter extends EntityBase implements IEntityObject 
{ 
		
		 	public $strViewId ="1"; 
			public $strApId = "1"; 
			public $strPropId="1"; 
			public $strViewDate="01.01.2000"; 
			public $strViewTime ="10:01:10"; 
			public $strViewDuration = "30mins"; 
			public $strApplicantConfirm = "yes"; 
			public $strVendorConfirm ="Yes"; 
			public $strApplicantKey ="100010"; 
			public $strApplicantName = "james gibson";
			public $strApplicantHomePhone = "0120289897564"; 
			public $strApplicantBusPhone = "0129202975786"; 
			public $strApplicantFaxNo = "08934745656233"; 
			public $strApplicantEmail = "someone@somwhere.co.uk"; 
			public $strApplicantAllowEmail = "yes"; 
			public $strApplicantMobile = "082459134613567"; 
			public $strApplicantAllowSms ="yes"; 
			public $strApplicantAllowPost="yes"; 
			public $strApplicantSalutation; 	
			public $strJointApplicantName = "miss,big, b, brid";
			public $strJointApplicantHomePhone = "082459134613567"; 
			public $strJoint_applicantBusPhone = "082459134613567"; 
			public $strJointApplicantEmail= "someone@somwhere.co.uk"; 
			public $strJointApplicantFax_no= "082459134613567"; 
			public $strJointApplicantMobile= "082459134613567"; 
			public $strJointApplicantAllowEmail ="yes"; 
			public $strJointApplicantAllowPost="yes"; 
			public $strApplicantCompanyName="the firm"; 
			public $strApplicantNegotiator = "confirm"; 
			public $strApplicantAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strApplicantBranch = "the branch name"; 
			public $strApplicantBranchPhoneNo= "082459134613567"; 
			public $strApplicantBranchFaxNo= "082459134613567"; 
			public $strApplicantBranchEmail="someone@somwhere.co.uk"; 
			public $strApplicantSolCompanyName = "person here"; 
			public $strApplicantSolAddress ="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strApplicant_solicitor_phoneno= "082459134613567"; 
			public $strApplicant_solicitor_faxno= "082459134613567"; 
			public $strApplicant_solicitor_contact_name = "john"; 
			public $strApplicant_solicitor_mobileno= "082459134613567"; 
			public $strApplicant_solicitor_email="someone@somwhere.co.uk"; 
			public $strApplicant_solicitor_salutation; 
			public $strPropertyKey ="100010"; 	
			public $strVendorName = "mr John j Johnston";
			public $strVendorHomePhone= "082459134613567"; 
			public $strVendorBusPhone= "082459134613567"; 
			public $strVendorMobileNo= "082459134613567"; 
			public $strVendorFaxNo= "082459134613567"; 
			public $strVendorEmail="someone@somwhere.co.uk";
			public $strJointVendorName ="mr,micheal,j, john";
			public $strJointVendorPhoneNo= "082459134613567"; 
			public $strJointVendorBusPhone= "082459134613567"; 
			public $strJointVendorMobileNo= "082459134613567"; 
			public $strJointVendorFaxNo= "082459134613567"; 
			public $strJointVendorEmail="someone@somwhere.co.uk"; 
			public $strVendorSalutation ="dr, johnston"; 
			public $strCompanyName = "the firm";	 
			Public $strPropertyAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strPropertyFor =""; 
			public $strPropertyBedrooms=""; 
			public $strPropertyReceptions=""; 
			public $strPropertyBathrooms=""; 
			public $strPropertyAskingPrice=""; 
			public $strPropertyValuationPrice=""; 
			public $strPropertyQuickSellPrice="";
			public $strPropertyTestMarketPrice=""; 
			public $strPropertyVendorOpinionPrice=""; 
			public $strPropertyCurrentPrice=""; 
			public $strPropertyBranch = "branch name"; 
			public $strPropertyBranchPhoneno= "082459134613567"; 
			public $strPropertyBranchFaxno= "082459134613567"; 
			public $strPropertyBranchEmail="someone@somwhere.co.uk"; 
			public $strPropertySaleStatus=""; 
			public $strPropertyNegotiator=""; 
			public $strPropertyBriefDescription=""; 
			public $strPropertyInstructedDate="";
			public $strVendorSolicitorCompanyName = "the firm"; 
			public $strVendorSolAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strVendor_solicitor_phoneno= "082459134613567"; 
			public $strVendor_solicitor_faxno= "082459134613567"; 
			public $strVendor_solicitor_contact_name ="john"; 
			public $strVendor_solicitor_mobileno= "082459134613567"; 
			public $strVendor_solicitor_email="someone@somwhere.co.uk"; 
			public $strVendor_solicitor_salutation=""; 
			public $strVendorPropertAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strJointVendorAddress="123, fake street,branksome,poole,bh11rp,dorset, england";
			public $strVendor_allow_sms="yes"; 
			public $strVendor_allow_email="yes"; 
			public $strVendor_allow_post="yes"; 
			public $strJoint_vendor_allow_sms="yes"; 
			public $strJoint_vendor_allow_email="yes"; 
			public $strJoint_vendor_allow_post="yes";
//			(
//			public $strApplicantTitle; 
//			public $strApplicantInitials; 
//			public $strApplicantFirstname; 
//			public $strApplicantSurname; 
//			)
			
			
//			(
//			public $strJointApplicantTitle; 
//			public $strJointApplicantFirstname; 
//			public $strJointApplicantInitials; 
//			public $strJoint_applicant_sur_name; 
//			)
			
			
//			(
//			public $strApplicantPropertyNo; 
//			public $strApplicantPropertyName; 
//			public $strApplicantAddress1_no; 
//			public $strApplicant_address1_name; 
//			public $strApplicant_address2; 
//			public $strApplicant_address3; 
//			public $strApplicant_postcode; 
//			public $strApplicant_town; 
//			public $strApplicant_county; 
//			public $strApplicant_country; 
//			)
			
			
//			(
//			public $strApplicantSolicitorAddress1No; 
//			public $strApplicantSolicitorAddress1Name; 
//			public $strApplicantSolicitorAddress2; 
//			public $strApplicant_solicitor_address3; 
//			public $strApplicant_solicitor_town; 
//			public $strApplicant_solicitor_county; 
//			public $strApplicant_solicitor_country; 
//			public $strApplicant_solicitor_postcode;
//			)
			
			
//			(
//			public $strVendorTitle; 
//			public $strVendorInitials; 
//			public $strVendor_first_name; 
//			public $strVendor_sur_name; )
//			
			
			
//			(
//			public $strJointVendor_title; 
//			public $strJoint_vendor_first_name; 
//			public $strJoint_vendor_initials; 
//			public $strJoint_vendor_sur_name; 
//			)
			
			
			
//			(
//			public $strProperty_no; 
//			public $strProperty_name; 
//			public $strProperty_address1_no; 
//			public $strProperty_address1_name; 
//			public $strProperty_address2; 
//			public $strProperty_address3; 
//			public $strProperty_town; 
//			public $strProperty_county; 
//			public $strProperty_country; 
//			public $strProperty_postcode; 
//			)
			
			
//			(
//			public $strVendorSolicitorAddress1No; 
//			public $strVendorSolicitorAddress1Name; 
//			public $strVendor_solicitor_address2; 
//			public $strVendor_solicitor_address3; 
//			public $strVendor_solicitor_town; 
//			public $strVendor_solicitor_county; 
//			public $strVendor_solicitor_country; 
//			public $strVendor_solicitor_postcode;)
//			
			
			
			
//			(
//			public $strVendor_property_no; 
//			public $strVendor_property_name; 
//			public $strVendor_address1_no; 
//			public $strVendor_address1_name; 
//			public $strVendor_address2; 
//			public $strVendor_address3; 
//			public $strVendor_town; 
//			public $strVendor_county; 
//			public $strVendor_country; 
//			public $strVendor_postcode; 
//			)
			
			
//			(
//			public $strJoint_vendor_property_no; 
//			public $strJoint_vendor_property_name; 
//			public $strJoint_vendor_address1_no; 
//			public $strJoint_vendor_address1_name; 
//			public $strJoint_vendor_address2; 
//			public $strJoint_vendor_address3; 
//			public $strJoint_vendor_town; 
//			public $strJoint_vendor_county; 
//			public $strJoint_vendor_country; 
//			public $strJoint_vendor_postcode; 
//			)
			
			

				
		
		 public function getProperties()
			{
				$resultarray = array(
				 	 
					'Viewing Id' => $this->strViewId, 
					'Applicant Id' => $this->strApId, 
					'Property Id' => $this->strPropId, 
					'Viewing Date' => $this->strViewDate, 
					'Viewing Time' => $this->strViewTime, 
					'Viewing Duration' => $this->strViewDuration, 
					'Applicant Confirm' => $this->strApplicantConfirm, 
					'Vendor Confirm' => $this->strVendorConfirm, 
					'Applicant key' => $this->strApplicantKey, 
					'Applicant name' => $this->strApplicantName,
					'Applicant Phone Number' => $this->strApplicantHomePhone, 
					'Applicant business number' => $this->strApplicantBusPhone, 
					'Applicant Fax Number' => $this->strApplicantFaxNo, 
					'Applicant Email' => $this->strApplicantEmail, 
					'Applicant Allow email' => $this->strApplicantAllowEmail, 
					'Applicant Mobils Number' => $this->strApplicantMobile, 
					'Applicant Allow sms' => $this->strApplicantAllowSms, 
					'Applicant Allow post' => $this->strApplicantAllowPost, 
					'Applicant Salutation' => $this->strApplicantSalutation, 	
					'Joint Applicant name' => $this->strJointApplicantName,
					'Joint Applicant Phone Number' => $this->strJointApplicantHomePhone, 
					'Joint Applicant Business Number' => $this->strJoint_applicantBusPhone, 
					'Joint Applicant Email' => $this->strJointApplicantEmail, 
					'Joint Applicant Fax Number' => $this->strJointApplicantFax_no, 
					'Joint Applicant Mobile Number' => $this->strJointApplicantMobile, 
					'Joint Applicant Allow Email' => $this->strJointApplicantAllowEmail, 
					'Joint Applicant Allow Post' => $this->strJointApplicantAllowPost, 
					'Applicant Company Name' => $this->strApplicantCompanyName, 
					'Applicant Negotiator' => $this->strApplicantNegotiator, 
					'Applicant Address' => $this->strApplicantAddress,
					'Applicant Branch' => $this->strApplicantBranch, 
					'Applicant Phone Number' => $this->strApplicantBranchPhoneNo, 
					'Applicant Fax Number' => $this->strApplicantBranchFaxNo, 
					'Applicant branch Email' => $this->strApplicantBranchEmail, 
					'Applicant Solicitor Comapny Name' => $this->strApplicantSolCompanyName, 
					'Applicant Solicitor Address' => $this->strApplicantSolAddress,
					'Applicant Solicitor Phoone Number' => $this->strApplicant_solicitor_phoneno, 
					'Applicant Solicitor fax number' => $this->strApplicant_solicitor_faxno, 
					'Applicant Solicitor Contact Name' => $this->strApplicant_solicitor_contact_name, 
					'Applicant Solicitor Mobile Number' => $this->strApplicant_solicitor_mobileno, 
					'Applicant Solicitor email' => $this->strApplicant_solicitor_email, 
					'Applicant Solicitor salutation' => $this->strApplicant_solicitor_salutation, 
					'Property Key' => $this->strPropertyKey, 	
					'Vendor name' => $this->strVendorName,
					'Vendor Home Phone Number' => $this->strVendorHomePhone, 
					'Vendor Buisness Number' => $this->strVendorBusPhone, 
					'Vendor Mobile Number' => $this->strVendorMobileNo, 
					'Vendor fax Number' => $this->strVendorFaxNo, 
					'Vendor Email' => $this->strVendorEmail,
					'Joint Vendor name' => $this->strJointVendorName,
					'Joint Vendor Phne Number' => $this->strJointVendorPhoneNo, 
					'Joint Vendor Buisness number' => $this->strJointVendorBusPhone, 
					'Joint Vendor Mobile Number' => $this->strJointVendorMobileNo, 
					'Joint Vendor fax Number' => $this->strJointVendorFaxNo, 
					'Joint Vendor email' => $this->strJointVendorEmail, 
					'Joint Vendor salutation' => $this->strVendorSalutation, 
					'Company name' => $this->strCompanyName,	 
					'Property Address' => $this->strPropertyAddress,
					'Property For' => $this->strPropertyFor, 
					'Property Bedrooms' => $this->strPropertyBedrooms, 
					'Property receptions' => $this->strPropertyReceptions, 
					'Property Bathrooms' => $this->strPropertyBathrooms, 
					'Property asking price' => $this->strPropertyAskingPrice, 
					'Property valuation Price' => $this->strPropertyValuationPrice, 
					'Property Quick sell price' => $this->strPropertyQuickSellPrice,
					'Property test market price' => $this->strPropertyTestMarketPrice, 
					'Property vendor opinion' => $this->strPropertyVendorOpinionPrice, 
					'Property current price' => $this->strPropertyCurrentPrice, 
					'Property Branch' => $this->strPropertyBranch, 
					'Property Branch Phone Number'  => $this->strPropertyBranchPhoneno, 
					'Property Branch fax Number' => $this->strPropertyBranchFaxno, 
					'Property Branch email' => $this->strPropertyBranchEmail, 
					'Property sales status' => $this->strPropertySaleStatus, 
					'Property Negotiator' => $this->strPropertyNegotiator, 
					'Property brief description' => $this->strPropertyBriefDescription, 
					'Property Instructed Date' => $this->strPropertyInstructedDate,
					'Vendor Solicitor company name' => $this->strVendorSolicitorCompanyName, 
					'Vendor Solicitor Address' => $this->strVendorSolAddress,
					'Vendor Solicitor Phone Number' => $this->strVendor_solicitor_phoneno, 
					'Vendor Solicitor Fax Number' => $this->strVendor_solicitor_faxno, 
					'Vendor Solicitor contact name' => $this->strVendor_solicitor_contact_name, 
					'Vendor Solicitor Mobile Number' => $this->strVendor_solicitor_mobileno, 
					'Vendor Solicitor email' => $this->strVendor_solicitor_email, 
					'Vendor Solicitor Salutaion' => $this->strVendor_solicitor_salutation, 
					'Vendor porperty address' => $this->strVendorPropertAddress,
					'Joint Vendor address' => $this->strJointVendorAddress,
					'Vendor Allow sms' => $this->strVendor_allow_sms, 
					'Vendor Allow email' => $this->strVendor_allow_email, 
					'Vendor Allow post' => $this->strVendor_allow_post, 
					'Joint Vendor Allow sms' => $this->strJoint_vendor_allow_sms, 
					'Joint Vendor Allow email' => $this->strJoint_vendor_allow_email, 
					'Joint Vendor Allow post' => $this->strJoint_vendor_allow_post,	
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("Viewing Letter");
			}

}
?>