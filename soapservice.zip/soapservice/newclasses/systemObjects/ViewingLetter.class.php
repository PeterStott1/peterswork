<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class ViewingLetter extends EntityBase implements IEntityObject 
{ 

// Please add in Viewing Notes which include Date, time, User and the note itself (these are mulitple notes & must be displayed)
// Please add in Accompanied Y/N
// Please add in Reminder Applicant Y/N - Vendor Y/N
// Please add in Negotiator 

		
		 	public $strViewId ="Viewing ID displayed here"; 
			public $strApId = "Viewing Applicant ID displayed here"; 
			public $strPropId="Viewing Property ID displayed here"; 
			public $strViewDate="Viewing Date displayed here"; 
			public $strViewTime ="Viewing Time displayed here"; 
			public $strViewDuration = "Viewing Duration displayed here"; 
			public $strApplicantConfirm = "Viewing Applicant confirmed displayed here"; 
			public $strVendorConfirm ="Viewing Vendor confirmed displayed here"; 
			public $strCanceled ="Viewing cancelled displayed here";
			public $strCancelDate = "Viewing cancelled date displayed here";
			public $strCancelReason = "Viewing cancelled reason displayed here";
			public $strComplete = "Viewing completed flag displayed here";
			public $strCompleteDate ="Viewing completed date displayed here";
			public $strCompletedNotes  = "Viewing completed notes displayed here";

		 public function getProperties()
			{
				$resultarray = array(
				 	 
					'Viewing ID' => $this->strViewId, 
					'Applicant ID' => $this->strApId, 
					'Property ID' => $this->strPropId, 
					'Viewing Date' => $this->strViewDate, 
					'Viewing Time' => $this->strViewTime, 
					'Viewing Duration' => $this->strViewDuration, 
					'Applicant Confirmed Y/N' => $this->strApplicantConfirm, 
					'Vendor Confirmed Y/N' => $this->strVendorConfirm,
					'Viewing Cancellation Y/N'=>$this->strCanceled,
					'Viewing Cancellation Date' =>$this->strCancelDate,
					'Viewing Cancellation Reason'=>$this->strCancelReason,
					'Viewing Complete Y/N'=>$this->strComplete,
					'Viewing Completion Date' =>$this->strCompleteDate,
					'Viewing Completion Notes'=>$this->strCompletedNotes
				);
				
		
				
				return $resultarray;	
			
			}
		 
		public function getName()
			{
				return("Viewing Details");
			}

}
?>