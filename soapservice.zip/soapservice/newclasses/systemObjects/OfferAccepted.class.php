<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class OfferAccepted extends EntityBase implements IEntityObject 
{
	

	public $dtAccepted="Offer Accepted Date displayed here";
	public $tmAccepted="Offer Accepted Time Entered displayed here";
	public $strOfferNotes="Offer Accepted Notes displayed here";
	public $strDepositPaid = "Deposit Paid displayed here";
	
	
	
 	
	
	public function getProperties()
	{
		$resultArray = array
		(
			'Offer Accepted Date'=>$this->dtAccepted,
			'Offer Accepted Time entered'=>$this->tmAccepted,
			'Offer Accepted Notes'=>$this->strOfferNotes,
			'Deposit Paid'=>$this->strDepositPaid,
		
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Offer Acceptence Details");
	}

	
}
?>