<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Progress extends EntityBase implements IEntityObject 
{
	

	public $curOfferAmount = "Offer Amount displayed here";
	public $dtOfferDate= "Offer Date displayed here";
	public $tmOfferTime= "Offer Time displayed here";
	public $strOfferNotes= "Offer Details displayed here";
	public $strlocalAuthority = "Local authority Info displayed here";
	public $strbuyerPosition= "Buyers Position displayed here";
	public $strFinancialInformation = "Financial Info displayed here";
	public $strType= "Property status displayed here";
	public $strcomp= "Comple";
	
 	
	//@get properties needed to
	public function getProperties()
	{
		$resultArray = array
		(

			'Offer Amount'=>$this->curOfferAmount,
			'Offer Date'=>$this->dtAccepted,
			'Offer Time'=>$this->tmAccepted,
			'Offer Detail'=>$this->strOfferNotes,
			'Local Authority Detail'=>$this->strlocalAuthority,
			'Buyer Position'=>$this->strbuyerPosition,
			'Financial Information'=>$this->strFinancialInformation,
			//'Offer type'=>$this->strType
//			'Complete'=>$this->strcomp
	
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("Offer Made Details");
	}

	
}
?>