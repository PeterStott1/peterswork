<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class ValuationLetter extends EntityBase implements IEntityObject 
{ 
		  
			public $strPropCategory = "Not being used in this class - used in Property.class";
		    public $strPropSubCategory = "Not being used in this class - used in Property.class"; 
			public $strCancelDate = "Cancelled Date displayed here";
			public $strLostToEstateAgent = "Estate Agent Name Lost To displayed here"; // please make sure we pull the value from the contact library **************
			public $strCancelReason = "Cancellation Reason displayed here";
			public $strCancelNotes = "Cancellation Notes displayed here"; // Disputed with the above only 1 needed ??? *****
 			public $strContactDate = "Cancellation Date displayed here";

		 public function getProperties()
			{
				$resultarray = array(

					'Cancellation date'=>$this->strCancelDate,
					'Lost Prospect'=>$this->strLostToEstateAgent,
					'Cancellation Reason'=>$this->strCancelReason,
					'cancellation Notes'=>$this->strCancelNotes, // Disputed with the above only 1 needed ??? *****
					'Contacted Date'=>$this->strContactDate,

// Not being used in this class - used in Property.class

//					'Property catergory' =>$this->strPropCategory ,
//				 	'Property sub catergory' =>$this->strPropSubCategory ,

				);
				return $resultarray;	
			}
		 
		public function getName()
			{
				return("Valuation Letter");
			}
}
?>