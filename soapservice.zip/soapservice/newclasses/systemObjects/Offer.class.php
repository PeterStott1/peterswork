<?php
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');

class Offer extends EntityBase implements IEntityObject 
{
	
	public $strOfferStatus;
	public $intOffer_AcceptId = "Offer Accepted ID displayed here";
	public $intOfferId = "Offer ID displayed here";
	public $intApplicantId = "Applicant ID displayed here";
	public $intPropertyId="Property ID displayed here";
	public $dtDate="Date displayed here";
	public $tmTime="Time displayed here";
	public $strOfferNotes="Offer Accepted Notes displayed here";
	public $strlocalAuthority ="Local Authority displayed here";
	public $strbuyerPosition="Applicant Position displayed here";
	public $strFinancialInformation = "Financial Information displayed here";
	public $strType="???????????????";
	public $strcomp="???????????????";
	public $intOffer_rejId = "Offer Rejected ID displayed here";
	public $intOfferId = "Offer ID displayed here"; //Duplicate of above **********************
	public $intApplicantId = "Applicant ID displayed here"; //Duplicate of above **********************
	public $intPropertyId="Property ID displayed here"; //Duplicate of above **********************
	public $dtRejected="Rejected Date displayed here";
	public $tmrejected="Rejected Time displayed here";
	public $strOfferNotes="Offer Notes displayed here"; //Duplicate of above **********************
	
	public function __construct($Status)
	{
		$this->strOfferStatus=$Status;
	}	
	public function getProperties()
	{
		$resultArray = array
		(

		);
		return $resultArray;	
	
	}
	public function getName()
	{
		if($this->strOfferStatus=="Rejected")
			return("Offer Rejected");
		if($this->strOfferStatus=="Accepted")
			return("Offer Accepted");
		if($this->strOfferStatus=="Standard")
			return("Offer");
			
	}

	
}
?>