<?
include_once('../XMLBUilder/EntityBase.abstract.php');
include_once('../XMLBUilder/IEntityObject.interface.php');
include_once('StringManipulation.class.php');
class JVAddress extends EntityBase implements  IEntityObject 
{
	
	public $strJVendorPropNumber = "JV Property Number displayed here";
	public $strJVendorPropName = "JV Property Name displayed here";
	public $strJVendorAdressLine1 = "JV Road / Street Number displayed here";
	public $strJVendorRoadNo = "JV Road / Street Number displayed here";
	public $strJVendorRoadName = "JV Road / Street Name displayed here";
	public $strJVendorAddressLine2 = "JV Address Line 2 displayed here";
	public $strJVendorAddressLine3 = "JV Address Line 3 displayed here";
	public $strJVendorAddressTown = "JV Town / City displayed here";
	public $strJVendorAddressCounty = "JV County displayed here";
	public $strJVendorAddressCountry = "JV Country displayed here";
	public $strJVendorAddressPostcode = "JV Post Code displayed here";
	public $strJVendorAddress ="JV Address String displayed here";
	public $strJVAddressBlock ="JV Address Block displayed here";
	
	public function getProperties()
	{
		//@@before we go to array set up values or manipulate where necessary
	
	 	$strTemp = $this->strJVendorPropNumber.", ".$this->strJVendorPropName.", ".$this->strJVendorAdressLine1.", ".$this->strJVendorAddressLine2.", ".$this->strJVendorAddressLine3.", ".$this->strJVendorAddressTown.", ".$this->strJVendorAddressCounty.", ".$this->strJVendorAddressCountry.", ".$this->strJVendorAddressPostcode;
		$this->strJVendorAddress = StringManipulation::CheckforCommaFields($strTemp);
		$this->strJVAddressBlock = StringManipulation::MakeBlock($strTemp);
		$resultArray = array
		(
		 	'JV Property No'=>$this->strJVendorPropNumber,	  
			'JV Property '=> $this->strJVendorPropName,
//			'JV Line 1'=>$this->strJVendorAdressLine1,
			'JV RoadStreet No'=>$this->strJVendorRoadNo,
			'JV RoadStreet'=>$this->strJVendorRoadName,
			'JV Address Line 2'=>$this->strJVendorAddressLine2,			
			'JV Address Line 3'=>$this->strJVendorAddressLine3,
			'JV TownCity'=>$this->strJVendorAddressTown,
			'JV County'=>$this->strJVendorAddressCounty,
			'JV Country'=>$this->strJVendorAddressCountry,
			'JV String'=> $this->strJVendorAddress,
			'JV Block'=> $this->strJVendorAddress,
			
			
		);
		return $resultArray;	
	
	}
	
	public function getName()
	{
		return("JV Address");
	}
	
}

?>