<?
$connection=mysql_connect("localhost", "root", "Jac%kEl10")
   or die("Could not connect : " . mysql_error());
 
  $databasename= "ep3-demo"; 
  
 // $databasename= "banbury_test";  
mysql_select_db($databasename) or die("Could not select database");

//********working code*********///

?>