<?php
include_once('../Config.class.php');
//$trigger = 'TzoxOToiV29ya09yZGVyRGVzY3JpcHRvciI6MTk6e3M6MTM6InN0clByb3BlcnR5SWQiO3M6MjoiMTAiO3M6MTE6InN0clZlbmRvcklkIjtzOjI6IjEwIjtzOjIwOiJzdHJWZW5kb3JTb2xpY2l0b3JJZCI7TjtzOjE0OiJzdHJBcHBsaWNhbnRJZCI7czoyOiIxNSI7czoyMzoic3RyQXBwbGljYW50U29saWNpdG9ySWQiO047czo5OiJzdHJVc2VySWQiO047czoxMToic3RyQnJhbmNoSWQiO047czoxMToic3RyVGVtcGxhdGUiO3M6MTE6InRtcDc2YzgudG1wIjtzOjE4OiJzdHJUZXh0ZGVzY3JpcHRpb24iO047czoxOToic3RyUHJvcGVydHlMZXR0ZXJJZCI7TjtzOjE4OiJzdHJWaWV3aW5nTGV0dGVySWQiO047czoxOToic3RyUHJvZ3Jlc3NMZXR0ZXJJZCI7TjtzOjIwOiJzdHJWYWx1YXRpb25MZXR0ZXJJZCI7TjtzOjE4OiJzdHJPZmZlclJlamVjdGVkSWQiO047czoxODoic3RyT2ZmZXJBY2NlcHRlZElkIjtOO3M6MTY6InN0clByaWNlQ2hhbmdlSWQiO047czoxNjoiYm9vbEluY2x1ZGVSb29tcyI7YjowO3M6MTc6ImJvb2xXb3JrT3JkZXJMaXZlIjtiOjE7czoxMDoic3RyRG9jVHlwZSI7czo2OiJMZXR0ZXIiO30=';
$trigger = $_REQUEST['triggerId'];


$path=Config::ServiceUrl();


header("content-type: application/msword");

print '$$$$EstatePro:'.$trigger."#".$path."#".':$$$$';
?>