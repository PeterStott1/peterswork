<?


//@@this can be any function you like as long as it is registered 
//@@step1
function SelectProperty()
{
	//onChange=\"xajax_GetFirstValues(this.value);
	//@@do some stuff based on $arg like query data from a database and
	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	$_SESSION["Property"] = $_GET['prid'];
	$_SESSION["Vendor"] = $_GET['prid'];
	//$recordId .= require_once("property-heading-details1.php");
	//$recordId .= "The property to be asiciated with this letter is: ".$_GET['prid'];
	$recordId .= "<form width=\"100%\" name=\"form1\" action=\"get\" method=Get>";
	
			   //@@first internal soap call for collection of data
				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
					$return = $client->__soapCall("getAllPropDetails",array($_GET['prid']));
				 	//print_r($return);	
				 	$return_array = explode("/",$return);
				 	$address_array = explode(",",$return_array[1]);
						
						$recordId .= "<table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
							$recordId .= "<tbody>";
								$recordId .= "<tr valign=\"top\">";
							      	$recordId .= "<td colspan=\"2\" bgcolor=\"78A3DD\" class=\"eleven-white-bold\">Property associated with this letter!</td>";
							    $recordId .= "<tr>";
								$recordId .= "<tr>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= "The property ref:";
									$recordId .= "</td>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= "100".$return_array[0];
									$recordId .= "</td>";
								$recordId .= "</tr>";
								$recordId .= "<tr>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= "Address number:";
									$recordId .= "</td>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= $address_array[1];
									$recordId .= "</td>";
								$recordId .= "</tr>";
								$recordId .= "<tr>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= "The Address Name";
									$recordId .= "</td>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= $address_array[3];
									$recordId .= "</td>";
								$recordId .= "</tr>";
								$recordId .= "<tr>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .=	"Address line 2";
									$recordId .= "</td>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .=	$address_array[0];
									$recordId .= "</td>";
								$recordId .= "</tr>";
								$recordId .= "<tr>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .=	"The address area";
									$recordId .= "</td>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= $address_array[2];
									$recordId .= "</td>";
								$recordId .= "</tr>";
								$recordId .= "<tr>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= "The Postcode";
									$recordId .= "</td>";
									$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";
										$recordId .= $address_array[4];
									$recordId .= "</td>";
								$recordId .= "</tr>";
							$recordId .= "</tbody>";
						$recordId .= "</table>";
						//$recordId .=$return_array[2];
						//$recordId .=$return_array[3];				
	$recordId .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_GetFirstValues(xajax.getFormValues('form1'));return(false);\">&nbsp;";
	$recordId .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Cancel\" onclick=\"closeWin()\">";
	$recordId .= "</form>";
	//@@Instantiate the xajaxResponse object
	$objResponse = new xajaxResponse();
	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	 //return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@step2
function GetFirstValues($arg)
{
	//@@now add it to the display string &
	// put it into a variable like $recordId
	//$recordId .= "the Value of the property_id is :".$arg."\n<br>";
	$dbconnect = mysql_connect('192.168.13.240','root','letmein');
    mysql_select_db('ep3dev');
	$query = "select * from ven_property_info where property_id =".$arg;
	//results set here
    $result = mysql_query($query,$dbconnect);
	//@@return while loop results
	while($row = mysql_fetch_assoc($result))
	{
		$_SESSION["Property"] = $row['property_id'];
		$_SESSION["Branch"] = $row['branch_id'];
		$_SESSION["Vendor"] = $row['vendorno'];
	}
	
	//@@now add it to the display string &
	//@@put it into a variable like $recordId
	$recordId .= "<form id=\"form1\" name=\"form1\" action=\"get\">";
	$recordId .= "<table width=\"100%\"  border=\"1\" cellspacing=\"0\" cellpadding=\"0\">";
		$recordId .= "<tbody>";
			$recordId .= "<tr>";
					$recordId .= "<td colspan=\"2\"width=\"274\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
						$recordId .= "now select the recipient for the letter to go to";
					$recordId .= "</td>";
			$recordId .= "</tr>";
			$recordId .= "<tr>";
					$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
							$recordId .= "<input id=\"applicant\" name=\"checkbox[]\" type=\"checkbox\" value=\"applicant\" >";
							$recordId .= "<label for=\"applicant\">applicant</label>";
					$recordId .= "</td>";
					$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
						$recordId .= "<input id=\"Vendor\" name=\"checkbox[]\" type=\"checkbox\" value=\"Vendor\">";
						$recordId .= "<label for=\"Vendor\">Vendor</label>";
					$recordId .= "</td>";
			$recordId .= "</tr>";
		$recordId .= "</tbody>";
	$recordId .= "</table>";
	$recordId .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_RecipientCollection(xajax.getFormValues('form1'));return(false);\">&nbsp";
	$recordId .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Cancel\" onclick=\"closeWin()\">";
	$recordId .= "</form>";

	//@@xajax requires this to send a response to the function call you must always use this response object or will not get a response
	//@@Instantiate the xajaxResponse object
		$objResponse = new xajaxResponse();

	//@@add a command to the response to assign the innerHTML attribute of
    //@@the element with id="SomeElementId" to whatever the new content is
	//@@showRec is a function within  the xajax response include file
	//@@retutn it is used to add the html to the xml response
		$objResponse->addAssign("showRec","innerHTML",$recordId);
	
	//@@return the  xajaxResponse object with out this no output will be shown
	return $objResponse;
}
//@@second process to collect the recipient without solicitors
//@@step three
function RecipientCollection($aFormValues)
{
	$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
	$recordId .= "<form id=\"form2\" name=\"form2\" action=\"get\" >";
	$recordId .= "<table width=\"100%\"  border=\"1\" cellspacing=\"0\" cellpadding=\"0\">";
	$recordId .= "<tbody>";
	$_SESSION['Applicant'] = $_GET['apid'];
	if(($aFormValues['checkbox'][0]==applicant)&&($aFormValues['checkbox'][1]==Vendor))
	{
		//@@return if the aplicant slicitor is required then 
		//@@collect the applicant solocitor based on the applicant number if no applecant nnumber exists then
		//@@collect all the applicant solcitor list for selection
		$intId = $aFormValues['VendorNumber'];
		$return = $client->__soapCall("GetVendor",array($_SESSION["Vendor"]));
	    //@@first internal soap call for collection of data
	    $recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
			$recordId .= "The Vendor that is associated with this letter is:<br>";
	    $recordId .= $return."</td>";
		$return1 = $client->__soapCall("GetApplicant",array($_SESSION['Applicant']));
	 	//print_r($return); 	
		$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
			$recordId .= "The applicant that is associated with this letter is:<br>";
		$recordId .= $return1."</td>";				
	}
	else if(($aFormValues['checkbox'][0]==applicant)&&($aFormValues['checkbox'][1]==''))
	{
		//@@first internal soap call for collection of data
		$return1 = $client->__soapCall("GetApplicant",array($_SESSION['Applicant']));
		//print_r($return);		 	
		$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
		$recordId .= "The applicant that is associated with this letter is:<br>";
		$recordId .= $return1."</td>";
		$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
		$recordId .= "Not Required</td>";					
	}
	else if(($aFormValues['checkbox'][0]==Vendor)&&($aFormValues['checkbox'][1]==''))
	{
		//@@return if the aplicant slicitor is required then 
		//@@collect the applicant solocitor based on the applicant number if no applecant nnumber exists then
		//@@collect all the applicant solcitor list for selection
		$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
		$recordId .= "Not Required</td>";
		$intId = $aFormValues['VendorNumber'];
		$return = $client->__soapCall("GetVendor",array($_SESSION["Vendor"]));
		$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
		$recordId .= "The Vendor that is associated with this letter is:<br>";
		$recordId .= $return."</td>";			
	}
	$recordId .= "</tr>";
	$recordId .= "</tbody>";
	$recordId .= "</table>";
	$recordId .= "<br><input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Cancel\" onclick=\"closeWin()\">";
	$recordId .= "<input class=\"bright-blue-btn\" type=\"Submit\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_RecipientSolicitorCollection(xajax.getFormValues('form2'));return(false);\"></button>";
	$recordId .= "</form>";
		
	$objResponse = new xajaxResponse();
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	//$objResponse->addAlert("inputData: " . print_r($aFormValues, true));
	return $objResponse;
}

//@@third process to collect the solicitors
//@@step 4
function RecipientSolicitorCollection($aFormValues)
 {
 	//@@once you have collected the 
 	$recordId .= "<form id=\"form3\"  name=\"form3\" action=\"get\">";
 	$recordId .= "<table width=\"100%\"  border=\"1\" cellspacing=\"0\" cellpadding=\"0\">";
	$recordId .= "<tbody>";
	//@@first internal soap call for collection of data
	$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
	$return = $client->__soapCall("GetAppSolicitor",array($_SESSION['Applicant']));	
	$return1 = $client->__soapCall("GetVenSolicitor",array($_SESSION['Vendor']));	
	if(!empty($return))
	{
		$_SESSION['ApplicantSol'] = $_SESSION['Applicant'];
	}
	else 
	{
		$_SESSION['ApplicantSol'] = '';
		$return = "There is no solicitor associated with this applicant";
		$return .= "<br>Would you like to choose one?";
		$return .= "<input id=\"Yes\" name=\"checkbox[]\" type=\"checkbox\" value=\"Yes\" >";
		$return .= "<label for=\"Yes\">Yes</label>";
	}
	if(!empty($return1))
	{
		$_SESSION['VendorSol'] = $_SESSION['Vendor'];
	}
	else
	{
		$_SESSION['VendorSol'] = '';
		$return1 = "There is no solicitor associated with this Vendor";
		$return1 .= "<br>Would you like to choose one?";
		$return1 .= "<input id=\"Yes\" name=\"checkbox[]\" type=\"checkbox\" value=\"Yes\" >";
		$return1 .= "<label for=\"Yes\">Yes</label>";
	}
				$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
					$recordId .= "Applicant solicitor :<br>".$return."</td>";
				$recordId .= "<td width=\"50%\" height=\"10\" valign=\"top\" bgcolor=\"#E7EBF1\" class=\"text-bold\" style=\"padding-left:8px;\">";	
					$recordId .= "Vendor solicitor :<br>".$return1."</td>";
				$recordId .= "</tr>";
			$recordId .= "</tbody>";
		$recordId .= "</table>";
	$recordId .= "<br><input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Cancel\" onclick=\"closeWin()\">";																			
	$recordId .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_SolicitorSelection(xajax.getFormValues('form3'));return(false);\">";
	//$recordId .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_TemplateSelection(xajax.getFormValues('form3'));return(false);\">";
	$recordId .= "</form>";
	$objResponse = new xajaxResponse();
	$objResponse->addAssign("showRec","innerHTML", $recordId);
	//$objResponse->addAlert("inputData: " . print_r($aFormValues, true));
	return $objResponse;
 }

//@step 5
function SolicitorSelection($aFormValues)
{
	
	$Content .= "<form width=\"100%\"id=\"form4\" name=\"form4\" action=\"get\">";
	if($aFormValues['checkbox'][0]=='Yes')
	{	
		$Content .= "<select name=\"cmbAppSolicitor\" size=\"20\" class=\"box-large\" id=\"cmbdata\" style=\"width:50%;\" >";
		//@@first internal soap call for collection of data
				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
				$return = $client->__soapCall("GetAllAppSolicitor",array());
					$return_array =explode(",",$return);
					$arrayLength = count($return_array);
					for($i = 0; $i <= $arrayLength; $i++)
					{
						$Content .= "<option value=\"$return_array[$i]\">".$return_array[$i]."</option>";
					}								
	$Content .= "</select>";
	$boolActive = false;
	}
	if($aFormValues['checkbox'][1]=='Yes')
	{
		
		$Content .= "<select name=\"cmbVenSolicitor\" size=\"20\" class=\"box-large\" id=\"cmbdata\" style=\"float:left:width:100%;\" >";
		//@@first internal soap call for collection of data
				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
				$return1 = $client->__soapCall("GetAllAppSolicitor",array());
					$return_array1 =explode(",",$return1);
					$arrayLength = count($return_array1);
					for($i = 0; $i <= $arrayLength; $i++)
					{
						$Content .= "<option value=\"$return_array1[$i]\">".$return_array1[$i]."</option>";
					}								
	$Content .= "</select>";
	$boolActive = false;
	}
	if(($aFormValues['checkbox'][1]=='')&&($aFormValues['checkbox'][0]==''))
	{
		$Content .= "You have no Solicitors Selcted for applicant or Vendor";
		$boolActive = true;
	}
	
	//@@now select the applicant solicitor based on the applicant ID suplied earlier
	//@@but only if 
	if($boolActive)
	{
		$Content .= "<br><input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_TemplateSelection(xajax.getFormValues('form4'));return(false);\">";
	}
	else 
	{
	$Content .= "<br><input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_CheckSolSelection(xajax.getFormValues('form4'));return(false);\">";
	}
	$Content .= "</form>";
	$objResponse = new xajaxResponse();
	$objResponse->addAssign("showRec","innerHTML", $Content);
	$objResponse->addAlert("inputData: " . print_r($aFormValues, true));
	return $objResponse;
	
}
function CheckSolSelection($aFormValues)
{
	
	$Content .= "<form id=\"form4\" name=\"form4\" action=\"get\">";
	$TempApp = $aFormValues['cmbAppSolicitor'];
	$TempVen = $aFormValues['cmbVenSolicitor'];
	$TempApp_array= explode("/",$TempApp);
	$TempVen_array = explode("/",$TempVen);
	$_SESSION['ApplicantSol'] = $TempApp_array[0];
	$_SESSION['VendorSol'] = $TempVen_array[0];
	$Content .= $_SESSION['ApplicantSol']."<br>";
	$Content .= $_SESSION['VendorSol']."<br>";
	//@@now select the applicant solicitor based on the applicant ID suplied earlier
	//@@but only if 
	$Content .= "<input type=\"Submit\" class=\"bright-blue-btn\" name=\"Submit\" value=\"Continue\" onclick=\"xajax_TemplateSelection(xajax.getFormValues('form4'));return(false);\">";
	$Content .= "</form>";
	$objResponse = new xajaxResponse();
	$objResponse->addAssign("showRec","innerHTML", $Content);
	$objResponse->addAlert("inputData: " . print_r($aFormValues, true));
	return $objResponse;
	
}
function TemplateSelection($aFormValues)
{
	
	$Content .= "<form id=\"form4\" name=\"form4\" action=\"get\">";
	//@@now select the applicant solicitor based on the applicant ID suplied earlier
	//@@but only if
	$Content .= "<select name=\"cmbTemplate\" size=\"20\" class=\"box-large\" id=\"cmbdata\" style=\"width:50%;\" onclick=\"xajax_FinalStep(xajax.getFormValues('form4'));\">";
	//@@first internal soap call for collection of data
				$client = new SoapClient(null, array('location' => "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/service.php", 'uri' => "urn:http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/req",'trace'=> 1 ));
				$return = $client->__soapCall("GetAllLetterTemplate",array());
					$return_array =explode(",",$return);
					$arrayLength = count($return_array);
					for($i = 0; $i <= $arrayLength; $i++)
					{
						$Content .= "<option value=\"$return_array[$i]\">".$return_array[$i]."</option>";
					}								
	$Content .= "</select>";
	$Content .= "</form>";
	$objResponse = new xajaxResponse();
	$objResponse->addAssign("showRec","innerHTML", $Content);
	$objResponse->addAlert("inputData: " . print_r($aFormValues, true));
	return $objResponse;
	
}

?>