<?php

require_once('../XMLBUilder/mysqlclass.php');
require_once('../XMLBUilder/DataAccess.class.php');
require_once('../XMLBUilder/WorkOrderDescriptor.class.php');
require_once('../XMLBUilder/TriggerEngine.class.php');
require_once('../Config.class.php');

function GetWorkOrder($workOrderId)
{
	
$db=Config::CreateDbConn();	
//$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3-demo'));
		
			
$TestDataAccess = new DataAccess($db);
$TestTrigger = new TriggerEngine($TestDataAccess);
$XmlWorkOrder = $TestTrigger->getWorkOrderFromTriggerId($workOrderId);
return $XmlWorkOrder->getXml()->asXml();

}
function CompleteWorkOrder($id,$TempWordDoc,$TempPdf,$Title)
{
	$db=Config::CreateDbConn();

	$TestDataAccess = new DataAccess($db);
	//insert to fopen here to get temp directory completed word and pdf's to move to actual file system
	//fmove  and rename then insert to data saved url
	//instantiate new object and add the dataccess object to use with it

	$TestTrigger = new TriggerEngine($TestDataAccess);
	$workOrderId= $TestTrigger->getWorkOrderDescriptionFromTriggerId($id);
	//print_r($workOrderId);
	$title =$Title;
	$type=$workOrderId->strDocType;
	$strPrid=$workOrderId->strPropertyId;
	$TemplateDoc=$workOrderId->strTemplate;
	//echo $id;
//	$change = explode('Temp',$TempWordDoc);
//	$change1 = explode('Temp',$TempPdf);
//	$search = '%7f';
//	$replace = "t";
//	$replace1 = "/ ";
//	$newName = str_replace($search,$replace1,$change);
//	$newName1 = str_replace($search,$replace1,$change1);
//	$systWordFileName =$newName[1];
//	$systpdfFilename=$newName1[1];
//	$systWordFileName_ar =explode($replace1 , $systWordFileName);
//	$systpdfFilename_ar=explode($replace1 , $systpdfFilename);
//	$string = substr($systWordFileName_ar[0],1);
//	$string1 = substr($systpdfFilename_ar[0],1);
//	$sysWordFileName =$string;
//	$syspdfFilename = $string1;
//	$sysWordFileName = $TempWordDoc;
//	$syspdfFilename = $TempPdf;
	$TimeZone = "Europe/London";
	$timestamp_array = getDate();
	
		
	if($TemplateDoc!=null)
	{
		if($TempWordDoc!=null)
		{
			$TempWordDoc1 = $Title.".docx";
			$TestDataAccess->InsertCompletedDoc($id,$type,$TempWordDoc,$TempWordDoc1,$strPrid);
			
		}
		if($TempPdf!=null)
		{
	
			$TempPdf1= $Title.".pdf";
			$TestDataAccess->InsertCompletedDoc($id,$type,$TempPdf,$TempPdf1,$strPrid);
			
		}
	}
	else 
	{
		$TestDataAccess->InsertCompletedTempDoc($TempWordDoc,$TempWordDoc,$workOrderId->strDocType,$id,$Title);
	}
		return 'complete';
}
function getAllPropDetails($id)
{
	$db=Config::CreateDbConn();

			$query = "select * from ven_property_info where Property_id =".$id;
			$result = mysql_query($query);
			while($row = mysql_fetch_array($result))
			
				{
						
						$strAddress=$row['prop_name'].",".$row['address1'].",".$row['address2'].",".$row['address3'].",".$row['postcode'];
						$intVendorNo = $row['vendorno'];
				    	$intPropertyId=$row['property_id'];
						$strBranchId =$row['branch_id']; 	
						$ResString .= $intVendorNo."/".$strAddress."/".$intPropertyId."/".$strBranchId."\n\r";	
						
				}
				
		return $ResString;
}
function getAllProps($id)
{
	$db=Config::CreateDbConn();

			$query = "select * from ven_property_info";
			$result = mysql_query($query);
			while($row = mysql_fetch_array($result))
			
				{
						
						$strAddress=$row['prop_name'].",".$row['address1'].",".$row['address2'].",".$row['address3'].",".$row['postcode'];
						$intVendorNo = $row['vendorno'];
				    	$intPropertyId=$row['property_id'];
						$strBranchId =$row['branch_id']; 	
						$ResString .= $intVendorNo."/".$strAddress."/".$intPropertyId."/".$strBranchId."\n";	
						
				}
				
		return $ResString;
}
function GetApplicant($id) {
	

     $db=Config::CreateDbConn();
     
	//build the query that will returnthe response of the soap transaction
    $query = "select title1,first_name1, sur_name1,applicant_id, applicantno from applicant_table where applicantno =".$id;
    $result = mysql_query($query);

	while($newArray = mysql_fetch_array($result)){
			$ApplicantName = $newArray['applicant_id'].",".$newArray['title1'].",".$newArray['first_name1'].",".$newArray['sur_name1'];
			$applicantno = $newArray['applicantno'];
			$ResString = $applicantno."/".$ApplicantName.",\n";
			$row .= $ResString;
		}
		return $row;
}
function GetVendor($id) {
	
 	$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select title1,first_name1, sur_name1, vendorno from vendor_contact where vendorno =".$id;
     $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){
			$VendorName = $newArray['title1'].$newArray['first_name1'].$newArray['sur_name1'];
			$VendorNo = $newArray['vendorno'];
			$ResString .= $VendorNo."/".$VendorName.",\n";
			
		}
		return $ResString;
}
function GetAppSolicitor($id)
{
//	mysql_connect('192.168.1.210','SoapAdmin','Server1');
//     mysql_select_db('ep3-demo');
$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select applicantno, contact_name from viewfor_appsolicitor where applicantno=".$id;
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){
			$applicantno = $newArray['applicantno'];
			$Contact_name = $newArray['contact_name'];
			$ResString = $applicantno.",".$Contact_name.",";
			
		}
		return $ResString;
	
}
function GetAllAppSolicitor($id)
{
//	mysql_connect('192.168.1.210','SoapAdmin','Server1');
//     mysql_select_db('ep3-demo');
$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select contact_id, contact_name from contact_details";
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){
			$ContactId = $newArray['contact_id'];
			$Contact_name = $newArray['contact_name'];
			$ResString .= $ContactId."/".$Contact_name.",";
			
		}
		return $ResString;
	
}
function GetVenSolicitor($id)
{
//	mysql_connect('192.168.1.210','SoapAdmin','Server1');
//     mysql_select_db('ep3-demo');
	$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select property_id, contact_name from viewfor_vensolicitor_new where property_id =".$id;
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){
			$property_id = $newArray['property_id'];
			$Contact_name = $newArray['contact_name'];
			$ResString = $property_id.",".$Contact_name.",";
			$row .= $ResString;
		}
		return $row;
	
}
function GetAllLetterTemplate() {
	//connection string will provide the connection to the database table for that sub-branch in a dynamic way
	$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select strTemplateDescription from Letter_templates";
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){

			$strTemplateTitle = $newArray['strTemplateDescription'];
			$ResString .= $strTemplateTitle.",";
		
		}
		return $ResString;
}
function GetAllLetterTemplateSystemTitles() {
	//connection string will provide the connection to the database table for that sub-branch in a dynamic way
	$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select strTemplateTitle from Letter_templates";
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){
			$FileName = $newArray['strTemplateTitle'];
			$ResString .= $FileName.",";
		
		}
		return $ResString;
}
function GetAllBrochureTemplateSystemTitles() {
	//connection string will provide the connection to the database table for that sub-branch in a dynamic way
	$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select strTemplateTitle from Brochure_templates";
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){
			$FileName = $newArray['strTemplateTitle'];
			$ResString .= $FileName.",";
		
		}
		return $ResString;
}
function GetAllBrochureTemplate() {
	//connection string will provide the connection to the database table for that sub-branch in a dynamic way
	$db=Config::CreateDbConn();
	//build the query that will returnthe response of the soap transaction
    $query = "select strTemplateDescription from Brochure_templates";
    $result = mysql_query($query);

		while($newArray = mysql_fetch_array($result)){

			$strTemplateTitle = $newArray['strTemplateDescription'];
			$ResString .= $strTemplateTitle.",";
		
		}
		return $ResString;
}
function BuildWorkOrder($id)
{
	
	$db=Config::CreateDbConn();
	//$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3-demo'));
	$TestDataAccess = new DataAccess($db);	
	$TestWorkOrderDescriptor = new WorkOrderDescriptor();
	foreach ($id as $key => &$value) {
	  switch ($key) 
	 	{
				case strBoardId:
				    $TestWorkOrderDescriptor->strBoardId =$value;
				    break;
	 			case strVAddressId:
				    $TestWorkOrderDescriptor->strVAddressId =$value;
				    break;
		    	case strJVAddressId:
				    $TestWorkOrderDescriptor->strVAddressId =$value;
				    break;
	 			case strPropertyId:
				    $TestWorkOrderDescriptor->strPropertyId =$value;
				    break;
				case strBranchId:
				    $TestWorkOrderDescriptor->strBranchId =$value;
				    break;
				case strUserId:
				    $TestWorkOrderDescriptor->strUserId =$value;
				    break;
				case strOfferRejectedId:
					$TestWorkOrderDescriptor->strOfferRejectedId =$value;
				    break;
				case strOfferAcceptedId:
				    $TestWorkOrderDescriptor->strOfferAcceptedId =$value;
				    break;
				case strPropertyLetterId:
				    $TestWorkOrderDescriptor->strPropertyLetterId =$value;
				    break;
				case strValuationLetterId:
				    $TestWorkOrderDescriptor->strValuationLetterId =$value;
				    break;
				 case strVendorId:
				    $TestWorkOrderDescriptor->strVendorId =$value;
				    break;
				   case strVendorSolicitorId:
				    $TestWorkOrderDescriptor->strVendorSolicitorId =$value;
				    break;
				case strProgressLetterId:
				    $TestWorkOrderDescriptor->strProgressLetterId =$value;
				    break;
				case strPriceChangeId:
				    $TestWorkOrderDescriptor->strPriceChangeId =$value;
				    break;
				case strViewingLetterId:
				   	$TestWorkOrderDescriptor->strViewingLetterId =$value;
				    break; 
				case strApplicantId:
				    $TestWorkOrderDescriptor->strApplicantId =$value;
				    break;
				case strApplicantSolicitorId:
				    $TestWorkOrderDescriptor->strApplicantSolicitorId =$value;
				    break;
				case strInFSId:
				    $TestWorkOrderDescriptor->strInFSId =$value;
				    break;
				case strOutFSId:
				    $TestWorkOrderDescriptor->strOutFSId =$value;
				    break;
		 		case strOutFSVendorId:
				    $TestWorkOrderDescriptor->strOutFSVendorId =$value;
				    break;
				
				case strInFSVendorId:
				    $TestWorkOrderDescriptor->strInFSVendorId =$value;
				    break;
				case boolWorkOrderLive:
				    $TestWorkOrderDescriptor->boolWorkOrderLive =$value;
				    break;
				case strTemplate:
				    $TestWorkOrderDescriptor->strTemplate =$value;
				    break;
				    case strTextDescription:
				    $TestWorkOrderDescriptor->strTextDescription =$value;
				    break;
				case boolIncludeRooms:
				    $TestWorkOrderDescriptor->boolIncludeRooms =$value;
				    break;
				case strDocType:
				    $TestWorkOrderDescriptor->strDocType =$value;
				    break;
				
				
		}
	}
	$TestTrigger = new TriggerEngine($TestDataAccess);
	$WorkOrderId = $TestTrigger->getTriggerID($TestWorkOrderDescriptor);
	return $WorkOrderId;
}

require('../../lib/nusoap.php'); 
/**instantiate the object for the soap server**/
$server = new Soap_Server();

/** build the webservice decription language for people to consume your service**/
//This could be built seperatley but I have used a class in the nusoap library
//then instantiated the object to build the wsdl from the namespace service with urn retieve
//because essentially we are only goingt o retrieve data with the webservice at the moment
$server->configureWSDL('service', 'urn:retrieve');


/**register the service inside the server script to allow people to use it**/

//***WARNING IF YOU DON'T REGISTER THE SERVICE HERE IT WON'T BE CONFIGURED IN THE WSDL**//
$server->register("GetWorkOrder",array('workOrderId' => 'xsd:string'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetWorkOrder');
$server->register("CompleteWorkOrder",array('id' => 'xsd:string','File1'=>'xsd:string','File2'=>'xsd:string','Title' =>'xsd:string'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#CompleteWorkOrder');
$server->register("getAllPropDetails",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#getAllPropDetails');
$server->register("GetApplicant",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetApplicant');
$server->register("GetVendor",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetVendor');
$server->register("GetAppSolicitor",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetAppSolicitor');
$server->register("GetVenSolicitor",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetVenSolicitor');
$server->register("GetAllLetterTemplate",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetAllLetterTemplate');
$server->register("GetAllAppSolicitor",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetAllAppSolicitor');
$server->register("getAllProps",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#getAllProps');
$server->register("BuildWorkOrder",array('id' => 'xsd:string'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#BuildWorkOrder');
$server->register("GetAllLetterTemplateSystemTitles",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetAllLetterTemplateSystemTitles');
$server->register("GetAllBrochureTemplate",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetAllBrochureTemplate');
$server->register("GetAllBrochureTemplateSystemTitles",array('id' => 'xsd:integer'),array('return' => 'xsd:string'),'urn:service','urn:retrieve#GetAllBrochureTemplateSystemTitles');

 
//check that it exists and then you can use it.
$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA)? $HTTP_RAW_POST_DATA : '';

//make the srvice use the http transport
$server->service($HTTP_RAW_POST_DATA);

?>
