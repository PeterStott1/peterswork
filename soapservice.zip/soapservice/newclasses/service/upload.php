<?php
include_once('../Config.class.php');


$uploadDir = Config::$TemplateDirectory;
$uploadFile = $uploadDir.$_FILES['file']['name'];

if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile))
{
	
    print "success";
    chmod($uploadFile,0777);
}
else
{
    print "fail";
    print_r($_FILES);
    print_r($uploadFile);
}



?>