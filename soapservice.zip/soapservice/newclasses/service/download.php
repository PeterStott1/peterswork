<?

require_once('../Config.class.php');

//look at the security for traversing the directory structure with url of browser

_Download(Config::$TemplateDirectory.$_REQUEST['Name'],$_REQUEST['Name']);



//print '$$$$EstatePro:'.$_REQUEST['workOrderID'].'$$$$';


function _Download($f_location,$f_name){
    header ("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Length: '.filesize($f_location));
    header('Content-Disposition: attachment; filename='.basename($f_name));
    
    readfile($f_location);
 }



?>