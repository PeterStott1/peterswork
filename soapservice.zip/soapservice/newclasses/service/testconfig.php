<?php
include_once('../Config.class.php');

print("This  is the data file storage directory "."'".Config::$TemplateDirectory."'");
echo "<br>\n";

echo "the template directory exits? ".var_dump(is_dir(Config::$TemplateDirectory))."<br>\n";
echo "<br>\n";
echo "the Image directory exits? ".var_dump(is_dir(Config::$ImageDirectory))."<br>\n";
echo "<br>\n";

echo "Template directory file permissions ".substr(sprintf('%o', fileperms(Config::$TemplateDirectory)), -4)."it should 0777!!!<br>\n";
echo "<br>\n";
echo "image file permissions".substr(sprintf('%o', fileperms(Config::$ImageDirectory)), -4)."it should 0777!!!<br>\n";
echo "<br>\n";
print("This  is the data image storage directory "."'".Config::$ImageDirectory."'");
echo "<br>\n";
print("This  is the service url directory "."'".Config::ServiceUrl()."'");


?>
