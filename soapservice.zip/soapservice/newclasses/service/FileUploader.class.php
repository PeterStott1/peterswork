<?php
/************************************************
Purpose: Upload file class
*************************************************/
class FileUpload{
	public $drHostPath = ""; //Gets added to $drUploadDir, helpful when using hosting services
	public $objTmpFile; //Temporary Filename
	public $strFilename; //File Name
	public $strOriginalFilename; //Original File Name
	public $strFileLocation; //File Location
	public $arFileTypes = array(); //File types allowed to be uploaded
	public $arBadFiletypes = array(); //Files types not allowed to be uploaded
	public $strExtension; //strExtension type of file
	public $strErrMsg = ""; //Current Error
	public $dblMaxFileSize = ""; //You can define here as a constant and/or set through SetMaxFileSize public function fn in the class (stored as bytes)
	public $dblFileSize; //File size of uploaded file
	public $boolOverWrite = false; //overwrite if file already exists
	public $drUploadDir = "";//Upload directory str this can be prepended to the 

	

	public function fnSetFileType($ext){
		$this->arFileTypes[] = $ext;
	}

	public function fnSetBadFileType($ext){
		$this->arBadFiletypes[] = $ext;
	}

	public function fnSetMaxFileSize($maxsize){
		$this->dblMaxFileSize = $maxsize;
	}
	
	public function fnSetOverwrite($boolOverWrite){
		$this->boolOverWrite = boolOverWrite;
	}

	public function fnUploadFile($input, $uploadersdir, $newfilename){
		$booli = true;
		set_time_limit(600);
		$this->strFileLocation = $uploadersdir;
		$this->drUploadDir = $uploadersdir;
		$this->objTmpFile = $_FILES[$input]['tmp_name'];
		$this->strOriginalFilename = $_FILES[$input]['name'];
		$this->dblFileSize = $_FILES[$input]['size'];
		$this->strExtension = strtolower(strstr($this->strOriginalFilename,'.'));
		if(count($this->arFileTypes) > 0)
		{
			$booli = array_search($this->strExtension, $this->arFileTypes);
			if($booli === false)
			{
				$this->strErrMsg .= "File type is not allowed!<br>";
				
						}
		}
		if(count($this->arBadFiletypes) > 0)
		{
			$booli = array_search($this->strExtension, $this->arBadFiletypes);
			if($booli === true)
			{
				$this->strErrMsg .= "File type had been blocked!<br>";
			}
		}
		
		$this->strFilename = $newfilename.$this->strExtension;
		//@@condition for empty value
		if(!empty($newfilename))
		{
			//@@assign the value of original file name
			$this->strFileLocation =$this->drUploadDir.$this->strOriginalFilename;
		}
		else
		{
			//@@assign the valuee of the new filename
			$this->strFileLocation = $this->drUploadDir.$newfilename.$this->strExtension;
			
		}
		//local varaible upload file
		$uploadFile = $this->drUploadDir.$_FILES[$input]['name'];
		//@check file size
		if($this->dblMaxFileSize != '')
		{
			//@@condition to check File size against the Maximum size set
			if($this->dblFileSize > $this->dblMaxFileSize)
			{	
				///@@error mesage for not allowed type
				$this->strErrMsg .= "File size is greater than allowable max. file size (" . $this->dblMaxFileSize . " bytes)<br>";
				//@despose of the file 
				unlink($uploadFile);
			}
		}
		if(file_exists($uploadFile))
		{
			//error the exists init
			$this->strErrMsg .= "This Filename already exists in ".$this->drUploadDir." and cannot be overwritten!<br>";
		}
		//@@ if no errors then upload the file
		if($this->strErrMsg=='')
		{
				$uploadFile = $this->drUploadDir.$_FILES[$input]['name'];
				move_uploaded_file($_FILES[$input]['tmp_name'], $uploadFile);
		}
		unlink($this->objTmpFile);
	}

	public function fnGetExtension(){
		//@@ returns the extension of the document
		return $this->strExtension;
	}
	

	public function fnGetFilename(){
		//@@return the file name
		return $this->strFilename;
	}
	public function fnGetUploadDir()
	{
		//@@return the directory to upload to
		return $this->drUploadDir;
		
	}
	public function fnGetOriginalFilename(){
		//@@returns the orignal file name
		return $this->strOriginalFilename;
	}

	public function fnGetFileLocation(){
		///@@return the file size of the current file
		return $this->strFilename;
	}

	public function fnGetFilesize(){
		//@@returns hte file size
		return $this->dblFileSize;
	}
	

	public function fnGetFileTypes(){
		//@@retutns the type array after it is imploded
		return implode(",", $this->arFileTypes);
	}
	

	public function fnGetBadFileTypes(){
		//@@retunr the badtypes array after imploding it
		return implode(",", $this->arBadFiletypes);
	}

	public function fnGetError(){
		//@@returns the error message when requested 
		return $this->strErrMsg;
	}
		
}
?>