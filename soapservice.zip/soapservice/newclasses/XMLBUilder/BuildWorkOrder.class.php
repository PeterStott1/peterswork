<?php
class BuildWorkOrder
{
	
	public $strWorkOrderId;//make 
	public $strTemplateUrl;
	public $boolisLiveWorkOrder;
	public $ObjArray = array();
	public $strTitle;
	
	
	public function __construct($strWorkID, $boolIsLive, $strTemplateUrl,$strTitle)
	{	
		//@@return get the values sent to the contructor
		$this->strWorkOrderId=$strWorkID;
		$this->boolisLiveWorkOrder = $boolIsLive;
		$this->strTemplateUrl = $strTemplateUrl;
		$this->strTitle = $strTitle;
		
	}
	//@@return this method will actual process whether it is a live or templated version of the xml if it is a live verion it should have live data
	//@@return if it is a template it will place dummy data in it 
	public function getXml()
	{
		$simpleXml = new SimpleXMLElement("<workOrder></workOrder>");
		$simpleXml->addAttribute("Title",$this->strTitle);
		$simpleXml->addAttribute("id",$this->strWorkOrderId);
		if ($this->boolisLiveWorkOrder)
			$simpleXml->addAttribute("type","live");
		else 
			$simpleXml->addAttribute("type","template");
		
		if (!empty($this->strTemplateUrl))
			$simpleXml->addAttribute("template",$this->strTemplateUrl);
			
		$templateXml = $simpleXml->addChild("templates");
		//@@return read through the object array and the recursive method 
		foreach($this->ObjArray as $Key )
		{
			//read through array and add to xml structure
			$this->Recurse($templateXml,$Key);
		}
		
		return($simpleXml);
		
	}
	public function addEntity($Obj)
	{
		//get content for add xml method
		array_push($this->ObjArray,$Obj);
		
	}
	public function __get($name)
	{
		return $this->$name;
		
	}
	public function __set($name,$value)
	{
		
		$this->$name=$value;
	}
	
	//@@return this method will take the simplaexmlelement object and the 
	//@@return name of the eleement with the value associated with that name and make the 
	//@@xml document
	private function addProperty($simpleXmlElement,$name,$value)
	{
		//add an element to the workorder 
		$element = $simpleXmlElement->addChild("property",$value);
		$element->addAttribute("type",$name);		
		//return($element);
	}
	private function addImage($simpleXmlElement,$name,$value)
	{
		//add an element to the workorder 
		$element = $simpleXmlElement->addChild("image",$value);
		$element->addAttribute("type",$name);		
		//return($element);
	}

	private function buildXmlForObject($simpleXmlObj,$obj)
	{
		$xml = $simpleXmlObj->addChild("item");
		$xml->addAttribute("type",$obj->getName()); 	
   		
		foreach($obj->getProperties() as $key=>$value)
		{
			$this->addProperty($xml,$key,$value);						
		}
		foreach($obj->getImages() as $key=>$value)
		{
			$this->addImage($xml,$key,$value);						
		}

		return $xml;
	}
	
	
	//@@return an internal method this will be used as the work horse of the object
	//@@return will accept the new simple xmlObj and the xml object that has been 
	//@@built earlier ie porperty or vender or solicitor or applicant!
	private function Recurse($simpleXmlObj, $obj)
	{
		
		//generat xml here!!!!!
		$xml = $this->buildXmlForObject($simpleXmlObj,$obj);
		
	
		foreach($obj->getChildren() as $Child)
		{
			
					
			$this->Recurse($xml,$Child);
		}
		
		//return $Xml;
	}
	
	
}
?>