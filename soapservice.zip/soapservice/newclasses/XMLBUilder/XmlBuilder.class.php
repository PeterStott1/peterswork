<?php
//@Xml builder object adds the property entity
//@and set the item attributes as well collection of the images required in the xml document
class XmlBuilder
{
		
	public function AddProperty($name,$value)
	{
			//@get the property name and value and return them to the workorder builder
		return $this->$name = $value;
	}
	public function AddItem($name,$value)
	{
		//@adds an item with the name and value to be returned
		return $this->$name = $value;
	}
	public function AddImage($name,$value)
	{
		//@image collection again getting the name and value o be return to the workorder builder
		return $this->$name = $value;
		
	}
}


?>