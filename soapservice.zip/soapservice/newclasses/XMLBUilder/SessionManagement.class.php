<?php

class SessionManagement
{
	
	public $strSessionArray = array();
	public $strVendorNo = " ";
	public $strPropertyId = "";
	public $strApplicantId = "";
	public $strUser = "";
	public $strBranchId = "";
	public $boolIsValid;
	
	public function __construct($ObjArray)
	{
		$this->strSessionArray=$ObjArray;
		
	}

	public function SessionStart($name)
	{
		$strMsg = 'your session isn t valid pleae go and log back in';
		if ($boolISValid==true)
			return $name;	
		else 	
			return $msg;
	}
	
	
}

?>