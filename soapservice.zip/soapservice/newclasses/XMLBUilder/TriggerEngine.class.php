<?php
//@@return creates the workorder trigger
require_once('WorkOrderDescriptorEngine.class.php');

class TriggerEngine
{
	private $objDataAccess;
	
	public function __construct($dataAccess)
	{
		$this->objDataAccess = $dataAccess;
	}
	
	
	public function getTriggerID($workOrderDescription)
	{
		// serialize this object
		$strWorkOrderID = serialize($workOrderDescription);
		
		$strEncryptedWorkOrderID = $this->EncryptIt($strWorkOrderID);
		
		return $strEncryptedWorkOrderID ;
	}
	
	public function getWorkOrderDescriptionFromTriggerId($triggerID)
	{
		// Decrypt
		$workOrderSerialized = $this->DecryptIt($triggerID);
		
		// Deserialize the trigger ID which is actually a serialized representation of the a work order description
		$workOrderDescription = unserialize($workOrderSerialized);
			
		// return the work order
		return($workOrderDescription);
	}
	public function getWorkOrderFromTriggerId($triggerID)
	{
		// Deserialize the trigger ID which is actually a serialized representation of the a work order description
		$workOrderDescription = $this->getWorkOrderDescriptionFromTriggerId($triggerID);
			
		// build the work order here
		$workOrderEngine = new WorkOrderDescriptorEngine($this->objDataAccess);
		$workOrder = $workOrderEngine->BuildWorkOrderFromDescriptor($workOrderDescription,$triggerID);
		
		// return the work order
		return($workOrder);
	}
	//@returns the decrypted string
	private function decryptIt($strValue)
	{
		//build string here
		
		return base64_decode($strValue);
	}
	//@@returns encrypted string
	private function encryptIt($strValue)
	{
		//substr sometging here
		return base64_encode($strValue);
	}
}
?>