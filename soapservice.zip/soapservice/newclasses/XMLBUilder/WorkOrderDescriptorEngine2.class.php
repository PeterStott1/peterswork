<?php
include_once("BuildWorkOrder.class.php");
include_once("WorkOrderDescriptor.class.php");
include_once('DataAccess.class.php');
include_once('EntityBase.abstract.php');
include_once('IEntityHierarchy.interface.php');
include_once('../Config.class.php');

//@ Entity classes that are reuqired by the decription engine
include_once('../systemObjects/Vendor.class.php');
include_once('../systemObjects/Room.class.php');
include_once('../systemObjects/Solicitor.class.php');
include_once('../systemObjects/Property.class.php');
include_once('../systemObjects/applicant.class.php');
include_once('../systemObjects/Appsolicitor.class.php');
include_once('../systemObjects/Branch.class.php');
include_once('../systemObjects/User.class.php');
include_once('../systemObjects/OfferAccepted.class.php');
include_once('../systemObjects/OfferRejected.class.php');
include_once('../systemObjects/PriceChange.class.php');
include_once('../systemObjects/OutFsVendorLetter.class.php');
include_once('../systemObjects/InFsVendorLetter.class.php');
include_once('../systemObjects/OutFsLetter.class.php');
include_once('../systemObjects/InFsLetter.class.php');
include_once('../systemObjects/Progress.class.php');
include_once('../systemObjects/PropertyLetter.class.php');
include_once('../systemObjects/ViewingLetter.class.php');
include_once('../systemObjects/ValuationLetter.class.php');
include_once('../systemObjects/JVAddress.class.php');
include_once('../systemObjects/VAddress.class.php');
include_once('../systemObjects/BackTMark.class.php');
include_once('../systemObjects/Memo.class.php');
include_once('../systemObjects/PropertyList.class.php');
//@builds work order based on the values passed by the workorderid
class WorkOrderDescriptorEngine
{	
	private $objDataAccess;
	
	public function __construct($dataAccess)
	{
		$this->objDataAccess = $dataAccess;		
	}
	
	
	public function BuildWorkOrderFromDescriptor($workOrderDescriptor,$workOrderId)
	{
	
		//$workOrderBuilder = new BuildWorkOrder($workOrderId,$workOrderDescriptor->boolWorkOrderLive,$workOrderDescriptor->strTemplate);
		$workOrderBuilder = new BuildWorkOrder($workOrderId,$workOrderDescriptor->boolWorkOrderLive,$workOrderDescriptor->strTemplate,$workOrderDescriptor->strTextDescription);
		// Build and add vendor into work order
		if (!empty($workOrderDescriptor->strVendorId))
		{
			if($workOrderDescriptor->strVendorId=='t')
			{
				$vendor = new vendor();
				$workOrderBuilder->addEntity($vendor);
				
			}
			else 
			{
				
				$vendor = $this->objDataAccess->getVendor($workOrderDescriptor->strVendorId);
				$workOrderBuilder->addEntity($vendor);
				
			}	
			if (!empty($workOrderDescriptor->$strVAddressId))
				{
					if($workOrderDescriptor->$strVAddressId=='t')
					{
						
						
						$VendorAddress = new VAddress();
						$vendor->addChild($VendorAddress);
					}
					else 
					{
						
						$VendorAddress = $this->objDataAccess->GetVendorsAddress($workOrderDescriptor->$strVAddressId);
						$vendor->addChild($VendorAddress);	
					}
				}	
				if (!empty($workOrderDescriptor->$strJVAddressId))
				{
					if($workOrderDescriptor->$strJVAddressId=='t')
					{
						
						$jointVendorAddress = new JVAddress();
						$vendor->addChild($jointVendorAddress);
						
					}
					else 
					{
						
						
						$jointVendorAddress = $this->objDataAccess->GetJVendorsAddress($workOrderDescriptor->$strJVAddressId);
						$vendor->addChild($jointVendorAddress);
						
					}
				}	
			// Build and add vendor solicitor
			if (!empty($workOrderDescriptor->strVendorSolicitorId))
			{
				if($workOrderDescriptor->strVendorSolicitorId=='t')
				{
					$vendorSolicitor = new Solicitor();
					$vendor->addChild($vendorSolicitor);
				}
				else 
				{
					$vendorSolicitor = $this->objDataAccess->getVenSolicitor($workOrderDescriptor->strVendorSolicitorId);
					$vendor->addChild($vendorSolicitor);
				}
			}	
			
		}
		// Build and add applicant
		if (!empty($workOrderDescriptor->strApplicantId))
		{
			if($workOrderDescriptor->strApplicantId=='t')
			{
				$applicant = new applicant();
				$workOrderBuilder->addEntity($applicant);
			}
			else 
			{
				$applicant = $this->objDataAccess->getApplicant($workOrderDescriptor->strApplicantId);
				$workOrderBuilder->addEntity($applicant);
			}
			
			// Build and add vendor solicitor
			if (!empty($workOrderDescriptor->strApplicantSolicitorId))
			{
				if($workOrderDescriptor->strApplicantSolicitorId=='t')
				{
					$applicantSolicitor = new AppSolicitor();
					$applicant->addChild($applicantSolicitor);
				}
				else 
				{
					$applicantSolicitor = $this->objDataAccess->getAppSolicitor($workOrderDescriptor->strApplicantSolicitorId);
					$applicant->addChild($applicantSolicitor);
				}
			}
		}
		
	
		// Build and add property and optionally rooms
		if (!empty($workOrderDescriptor->strPropertyId))
		{
			
			if ($workOrderDescriptor->strPropertyId=='t')
			{
				$property =new Property();
				$property->imgMainImage = Config::$ImageDirectory.'prop-photo.jpg';
				$property->imgFloorPlan= Config::$ImageDirectory.'prop-photo.jpg';
				$workOrderBuilder->addEntity($property);
				
			 		if($workOrderDescriptor->boolIncludeRooms) 
					{	
							for ($i = 1; $i <= 4; $i++)
							{		
							// this is the bit where we get the rooms!
							
							$room = new Room();
							$room->strRoomName="room".$i;
							$room->imgRoomImage = Config::$ImageDirectory.'prop-photo.jpg';
							$property->addChild($room);	
							}
		
					}	
			}
			else 
			{
				$property = $this->objDataAccess->getProperty($workOrderDescriptor->strPropertyId);
				$workOrderBuilder->addEntity($property);
			
				if($workOrderDescriptor->boolIncludeRooms) 
					{			
						// this is the bit where we get the rooms!
						$arrayRoom = $this->objDataAccess->getRooms($workOrderDescriptor->strPropertyId);
						foreach($arrayRoom as $room)
						{
							$property->addChild($room);	
						}	
								
					}	
					// this is the bit where we get the propertylist!
//						$PropList = $this->objDataAccess->getPropertyList($workOrderDescriptor->strPropertyId);
//						foreach($PropList as $prop)
//						{
//							$property->addChild($prop);	
//						}	
			}	

		}
	
		// Build and add branch
		if (!empty($workOrderDescriptor->strBranchId))
		{
			if($workOrderDescriptor->strBranchId=='t')
			{
				$branch = new Branch();
				$workOrderBuilder->addEntity($branch);
			}
			else 
			{
				$branch = $this->objDataAccess->getBranch($workOrderDescriptor->strBranchId);
				$workOrderBuilder->addEntity($branch);
			}
		}
		
		// Build and add user
		if (!empty($workOrderDescriptor->strUserId))
		{
			if($workOrderDescriptor->strUserId=='t')
			{
				$user = new User();
				$user->picSignature =Config::$ImageDirectory.'prop-photo.jpg';
				$user->picImage =Config::$ImageDirectory.'prop-photo.jpg';
				$workOrderBuilder->addEntity($user);
			}
			else 
			{
				$user = $this->objDataAccess->getUser($workOrderDescriptor->strUserId);
				$workOrderBuilder->addEntity($user);
			}
		}
		
		if (!empty($workOrderDescriptor->strOutFSVendorId))
		{
			if($workOrderDescriptor->strOutFSVendorId=='t')
			{
				$OutFSVendor = new OutFsVendorLetter();
				$workOrderBuilder->addEntity($OutFSVendor);
				
			}
			else 
			{
				$OutFSVendor = $this->objDataAccess->getOutFsVendor($workOrderDescriptor->strOutFSVendorId);
				$workOrderBuilder->addEntity($OutFSVendor);
			}
			
			
		}	
		if (!empty($workOrderDescriptor->strInFSVendorId))
		{
			
			if($workOrderDescriptor->strInFSVendorId=='t')
			{
				$InFSVendor = new InFsVendorLetter();
				$workOrderBuilder->addEntity($InFSVendor);
			}
			else 
			{
		
				$InFSVendor = $this->objDataAccess->GetInFsVendorLetter($workOrderDescriptor->strInFSVendorId);
				$workOrderBuilder->addEntity($InFSVendor);
			}
			
			
		}
		if (!empty($workOrderDescriptor->strProgressLetterId))
		{
			if($workOrderDescriptor->strProgessLetterId=='t')
			{
				$Progress = new Progress();
				$workOrderBuilder->addEntity($Progress);
			}
			else 
			{
				$Progress = $this->objDataAccess->getProgress($workOrderDescriptor->strProgressLetterId);
				$workOrderBuilder->addEntity($Progress);	
			}
			
		}
		if (!empty($workOrderDescriptor->strViewingLetterId))
		{
			if($workOrderDescriptor->strViewingLetterId=='t')
			{
				$Viewlet = new ViewingLetter();
				$workOrderBuilder->addEntity($Viewlet);
			}
			else
			{
				$Viewlet = $this->objDataAccess->getViewingLetter($workOrderDescriptor->strViewingLetterId);
				$workOrderBuilder->addEntity($Viewlet);
			}
			
			
		}
		if(!empty($workOrderDescriptor->strPriceChangeId))
		{
			if($workOrderDescriptor->strPriceChangeId=='t')
			{
				$prchange = new PriceChange();
				$workOrderBuilder->addEntity($prchange);
			}
			else 
			{
				$prchange = $this->objDataAccess->getPrChange($workOrderDescriptor->strPriceChangeId);
				$workOrderBuilder->addEntity($prchange);
			}
			
		}	
		
		if(!empty($workOrderDescriptor->strOfferAcceptedId))
		{
			if($workOrderDescriptor->strOfferAcceptedId=='t')
			{
				$OfferAcc = new OfferAccepted();
				$workOrderBuilder->addEntity($OfferAcc);
			}
			else 
			{
				$OfferAcc = $this->objDataAccess->getOfferAcc($workOrderDescriptor->strOfferAcceptedId);
				$workOrderBuilder->addEntity($OfferAcc);
			}
			
		}
		
		if(!empty($workOrderDescriptor->strOfferRejectedId))
		{
			if($workOrderDescriptor->strOfferRejectedId=='t')
			{
				$OfferRej = new OfferRejected();
				$workOrderBuilder->addEntity($OfferRej);
			}
			else 
			{
				$OfferRej = $this->objDataAccess->getOfferRej($workOrderDescriptor->strOfferRejectedId);
				$workOrderBuilder->addEntity($OfferRej);
			}
		}
		
		if(!empty($workOrderDescriptor->strValuationLetterId))
		{
			if($workOrderDescriptor->strValuationLetterId=='t')
			{
				$valLetter = new ValuationLetter();
				$workOrderBuilder->addEntity($valLetter);
			}
			else 
			{
				$valLetter = $this->objDataAccess->getValuationLetter($workOrderDescriptor->strValuationLetterId);
				$workOrderBuilder->addEntity($valLetter);
			}
		}
		if(!empty($workOrderDescriptor->strBTMId))
		{
			if($workOrderDescriptor->strBTMId=='t')
			{
				$BTM = new BackTMark();
				$workOrderBuilder->addEntity($BTM);
			}
			else 
			{
				$BTM = $this->objDataAccess->getBTM($workOrderDescriptor->strBTMId);
				$workOrderBuilder->addEntity($BTM);
			}	
		}
		if(!empty($workOrderDescriptor->strMemoId))
		{
			if($workOrderDescriptor->strMemoId=='t')
			{
				$memo = new Memo();
				$workOrderBuilder->addEntity($memo);
			}
			else 
			{
				$memo = $this->objDataAccess->getMemo($workOrderDescriptor->strMemoId);
				$workOrderBuilder->addEntity($memo);
			}
			
		}
		
		//@return workorderbuilder
		return $workOrderBuilder;
	}
	
}
?>