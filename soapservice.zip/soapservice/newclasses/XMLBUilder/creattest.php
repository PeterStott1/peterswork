<?
$value = $_GET['do'];
require_once('createtables.class.php');
require_once('../Config.class.php');

	$db=Config::CreateDbConn();	
	$create = new setupdb($db);
	$create->CreateDatabase();
	echo "installation complete!";


?>