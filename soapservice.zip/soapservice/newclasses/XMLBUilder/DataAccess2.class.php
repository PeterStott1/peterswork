<?php
//@@dataaccess object will be used to seperate the business logic from the solution and the database layer
class DataAccess
{
	//@@ conDatabase is the database connection string 
	public $conDatabase;
	//@@room array used whenh building the room object array
	public $RoomArray = array();
	public $ImageArray = array();
	//@@ this is set-up for the property array to provide some functionality for the property listing that will need to be produced
	public $PropArray = array();
	//@@object required for building the xml 
	public $Obj;
	//@@return the constructor with a connection to the database 
	//@@return this is a reuqierd object for the object to work hence stored in the contstructor
	public function __construct($conMysql)
	{
		$this->conDatabase=$conMysql;
	}
	//@@return the town based on the id sent to the method
	private function getTown($intTownId)
	{
		//get town calls to other table in the database
		$result=$this->conDatabase->query('SELECT townname FROM lib_town where townid = '.$intTownId);
		$row = $result->fetch($result);
		if($row['townname'])
		return $row['townname'];
		else 
		return $row="n/a";
	}
	private function GetDepartment($Id)
	{
		$result=$this->conDatabase->query('SELECT department FROM lib_department where d_id = '.$Id);
		$row = $result->fetch($result);
		return $row['department'];
	}
	//@@return the data from the table based on the id set to the function
	private function getCounty($intCountyId)
	{
		$result=$this->conDatabase->query('SELECT countyname FROM lib_county where countyid = '.$intCountyId);
		$row = $result->fetch($result);
		
		if($row['countyname'])
		return $row['countyname'];
		else 
		return $row="n/a";
	}
	//@@return country from id in the ven_proeprty_info which is stored as an id in the table
	private function getCountry($intCountryId)
	{
		$result=$this->conDatabase->query('SELECT countryname FROM lib_country where countryid = '.$intCountryId);
		$row = $result->fetch($result);
	
		if($row['countryname'])
		return $row['countryname'];
		else 
		return $row="n/a";
	}
	//@@return gets the florrplan thet is stored as an id in the ven_proeprty_info table in the database
	private function getFloorPlan($intPropID)
	{
		$result=$this->conDatabase->query('SELECT img FROM prop_floor where prop_id = '.$intPropID);
		$row = $result->fetch($result);
		
			$image =Config::$ImageDirectory.$this->CheckForEmptyImages($row['img']);
		
		
		return $image;
		
	}
	private function getBand($Id)
	{
		
		$result=$this->conDatabase->query('SELECT * FROM lib_pr_band where prband_id = '.$Id);
		$row = $result->fetch($result);
		return $row['prband'];
		
		
	}
	private function getPropeDesc($id)
	{
			//get town calls to other table in the database
			$result=$this->conDatabase->query('select heading, details from prop_desc where prop_id='.$id);
			$row = $result->fetch($result);
			while($row = $result->fetch($result))
				{
					$heading = $row['heading'];
					$desc = $row['details'];
					$string .= "\n".$heading."\n".$desc."\n";
				}
			return $string;
	}
	private function GetPropertyType($Id)
			{
				if(!empty($Id))
				{
				$result=$this->conDatabase->query('select lib_prop_type.prop_type, lib_prop_sub_type.prop_sub_type from lib_prop_sub_type inner join lib_prop_type on lib_prop_sub_type.prop_type_id =  lib_prop_type.prop_type_id where lib_prop_sub_type.prop_sub_type_id = '.$Id);
				$row = $result->fetch($result);
				$strPropType = $row['prop_type'];
				$strSubType = $row['prop_sub_type'];
				$strValue =$strPropType.",".$strSubType;
				return $strValue;
				}
				else 
				{
					return $row="";
				}
				
			}	
	private function getRoom1($id)
	{
			//get town calls to other table in the database
			$result=$this->conDatabase->query('select pr_heading, pr_details, pr_length,pr_l_in,pr_width,pr_w_in from prop_room where prop_id='.$id);
			$row = $result->fetch($result);
			while($row = $result->fetch($result))
			{
				$heading = $row['pr_heading'];
				$desc = $row['pr_details'];
				$length = $row['pr_length'];
				$lin = $row['pr_l_in'];
				$width = $row['pr_width'];
				$Win = $row['pr_w_in'];
				$string .= "\n".$heading."\nDIMENSIONS: ".$length."'".$lin." ''"." X ".$width."'".$Win." '' "."\n"."DESCRIPTION: ".$desc."\n";
			}
			return $string;
	}
	private function getPossession($ID)
	{
		
		$result=$this->conDatabase->query('select psdesc from lib_possesion where psid = '.$ID);
		$row= $result->fetch($result);
		return $row['psdesc'];
		
	}
	//@@return function price change table 
	public function getPrChange($intPrId)
	{
		$result=$this->conDatabase->query('select * from price_change where pr_id = '.$intPrId);
		$row= $result->fetch($result);
		$prchange = new PriceChange();
		$prchange->PriceId =$row['pr_id'];
		$prchange->Prop_Id =$row['prop_id'];
		$prchange->dtReqDate =$row['reqdate']; 
		$prchange->tmRegTime =$row['reqtime']; 
		$prchange->OldAmount =$row['oldamt']; 
		$prchange->NewAmount =$row['newamt']; 
		$prchange->strComments =$row['comments']; 
		$prchange->strNotes =$row['notes']; 
		$prchange->inttype =$row['type']; 
		$prchange->intComp =$row['comp'];
		return $prchange;
		
	}
	//@@return function to get offer letter information from the dtabase
	public function getOfferAcc($intOId)
	{
		$result=$this->conDatabase->query('select * from offer_accept where prod_id ='.$intOId);
		$row= $result->fetch($result);	
		$OfferAcc = new OfferAccepted();
		$OfferAcc->intOffer_AcceptId =$row['oa_id']; 
		$OfferAcc->intOfferId =$row['offer_id'];
		$OfferAcc->intApplicantId =$row['ap_id']; 
		$OfferAcc->intPropertyId=$row['prop_id'];
		$OfferAcc->dtAccepted=$row['acc_date'];
		$OfferAcc->tmAccepted=$row['acc_time'];
		$OfferAcc->strOfferNotes=$row['acc_notes'];
		$OfferAcc->strlocalAuthority =$row['local_auth'];
		$OfferAcc->strbuyerPosition=$row['buyer_pos'];
		$OfferAcc->strFinancialInformation =$row['finance_info']; 
		$OfferAcc->strType=$row['dep_paid'];
		$OfferAcc->strType=$row['type'];
		$OfferAcc->strcomp=$row['comp'];
			
		return $OfferAcc;
	}
	//@@return offer rejected data from offer rejected table from 
	public function getOfferRej($intOId)
	{
		$result=$this->conDatabase->query('select * from offer_reject where prop_id = '.$intOId);
		$row=$result->fetch($result);	
		$OfferRej= new OfferRejected();
		$OfferRej->intOffer_rejId =$row['of_rj_id'];
		$OfferRej->intOfferId= $row['offer_id'];
		$OfferRej->intApplicantId =$row['ap_id']; 
		$OfferRej->intPropertyId=$row['prop_id'];
		$OfferRej->dtRejected=$row['rej_date'];
		$OfferRej->tmrejected=$row['rej_time'];
		$OfferRej->strOfferNotes=$row['rej_notes'];
		$OfferRej->strType=$row['type'];
		$OfferRej->strcomp=$row['comp'];
				
		return $OfferRej;
	}
	//@@return property data from ven_property_info table in the database
	public function getProperty($intPId)
	{
	//@getting the property data from the database
		$result=$this->conDatabase->query('SELECT * FROM ven_property_info where property_id ='.$intPId);
		$row = $result->fetch($result);
		$property = new Property();
		$property->intVendorNo=$row['vendorno'];
		$property->intaskingpr=$this->CheckForEmptyValues($row['askingpr']);
		$property->strDescrition=$this->CheckForEmptyValues($row['prop_description'])."\n".$row['prop_advert_desc']."\n".$this->CheckForEmptyValues($row['viewingdesc']).
		"\n".$this->CheckForEmptyValues($row['prop_short_desc'])."\n".$row['prop_advert_desc'];
		$property->strPropertyDescription=$this->getPropeDesc($intPId)."\n".$this->getRoom1($intPId); 
		$property->imgMainImage=Config::$ImageDirectory.$this->CheckForEmptyImages($row['mainimg']);
		$property->strPropertyName=$this->CheckForEmptyValues($row['prop_name']);
		$property->strPropertyNumber=$this->CheckForEmptyValues($row['propertyno']);
		$property->strAddressLine1 = $this->CheckForEmptyValues($row['address1']); 
		$property->strAddressLine2 = $this->CheckForEmptyValues($row['address2']);
		$property->strAddressLine3 = $this->CheckForEmptyValues($row['address3']);
		$property->strTown = $this->getTown($row['town']);
		$property->strCounty = $this->getCounty($row['county']);
		$property->strPostcode = $row['postcode'];
		$property->strCountry= $this->getCounty($row['country']);
		$property->strAddressRoad = $row['road'];
		$property->imgFloorPlan=$this->getFloorPlan($intPId);
		$property->intPropertyId=$row['property_id'];
		$property->strBranchId =$row['branch_id']; 
		$property->strLocality =$this->CheckForEmptyValues($row['locality']);
		$property->strPropertyAreaNumber=$this->CheckForEmptyValues($row['area_no']);
		$property->strPropertyArea =$this->GetArea($row['property_area']); 
		$property->strPropertyDistrict =$this->GetDistrict($row['property_dist']);
		$property->strPropertyType =$this->GetPropertyType($row['property_type']); 
		$property->strCommercialProperty =$this->CheckForEmptyValues($row['commerce_prop']); 
		$property->strPropertyFor =$this->SaleNoSale($row['property_for']);
		$property->strPropertyBedrooms=$this->CheckForEmptyValues($row['no_beds']);
		
		$property->strPropertyReceptions=$this->CheckForEmptyValues($row['no_recep']);
		//$property->strPropertyReceptions=$row['no_recep'];
		//$property->strPropertyBathrooms=$row['no_baths'];
		$property->strPropertyBathrooms=$this->CheckForEmptyValues($row['no_baths']);
		
		$property->strPropertyValuationPrice=$this->CheckForEmptyValues($row['valuationpr']);
		$property->strPropertyQuickSellPrice=$this->CheckForEmptyValues($row['quickspr']);
		$property->strPropertyTestMarketPrice=$this->CheckForEmptyValues($row['testmarpr']);
		$property->strOpinionPrice=$this->CheckForEmptyValues($row['opinionpr']);
		

		$property->strPropertyAge =$row['property_age']; 
		$property->strPropertyView =$row['view'];
//		$property->strPropertyTenure =$this->CheckForEmptyValues($row['tenure']);
//		$property->strPropertyPosseion =$row['possession']; 
		
		//$property->strPropertyAge =$this->CheckForEmptyValues($row['property_age']); 
		//$property->strPropertyView =$this->CheckForEmptyValues($row['view']);
		$property->strPropertyTenure =$this->CheckForEmptyValues($row['tenure']);
		$property->strPropertyPosseion =$this->getPossession($row['possession']); 
		
		
		$property->strBuyersposition =$this->CheckForEmptyValues($row['buyer_pos']); 
		$property->strPropertyClass =$this->valueReplace($row['prop_class']); 
		$property->strCentralHeating=$this->valueReplace($row['central_heating']); 
		$property->strVacant=$this->CheckForEmptyValues($row['vaccant']); 
		$property->strVehicleParking =$this->valueReplace($row['veh_parking']); 
		$property->strParkingSize =$this->CheckForEmptyValues($row['parkingsize']); 
		$property->intmap_ref =$this->CheckForEmptyValues($row['map_ref']);
		$property->strOffRoadParking =$this->valueReplace($row['off_road_park']); 
		$property->strGarage =$this->CheckForEmptyValues($row['garage']); 
		$property->strOutBuilding =$this->CheckForEmptyValues($row['out_building']); 
		$property->strSwimmingPool =$this->valueReplace($row['swim_pool']);
		$property->strSpecialCritiria =$this->GetCriteria($row['spcriteria']); 
		$property->strGarden =$this->CheckForEmptyValues($row['garden']); 
		$property->strLargeGarden =$this->CheckForEmptyValues($row['large_garden']); 
		$property->strAdditionalInformation =$this->CheckForEmptyValues($row['add_info']); 
		$property->SquareFootage =$this->valueReplace($row['sq_footage']); 
		$property->strrentalPeriod =$this->valueReplace($row['rent_period']); 
		$property->strSalesBoardrequired =$this->valueReplace($row['sale_board_req']); 
		$property->strSalesBoard =$this->valueReplace($row['sale_board']); 
		$property->strKeyReference =$this->CheckForEmptyValues($row['key_ref']); 
		$property->strKeyHolder =$this->valueReplace($row['key_holder']); 
		$property->strSendToPropertyList =$this->valueReplace($row['sendtoproplist']); 
		$property->dtCreatedOn =$row['createdon']; 
		$property->strViewingDescription =$this->CheckForEmptyValues($row['viewingdesc']);
		$property->strViewingInformation =$this->CheckForEmptyValues($row['viewinginfo']);
		$property->strEnquirySource =$row['enquiry_source']; 
		$property->strShowPrice =$this->valueReplace($row['showprice']); 
		$property->curCurrency =$row['currency']; 
		$property->strPOA =$row['poa']; 
		
	
		$property->strPropertyBand = $this->getBand($row['pr_band']); 
		$property->strValuationCompleted =$row['val_completed'];
		$property->strLwd =$this->CheckForEmptyValues($row['lwd']);
		$property->dtLwd =$this->CheckForEmptyValues($row['lwd_date']);
		$property->tmLwd =$this->CheckForEmptyValues($row['lwd_time']); 
		$property->strLostTo =$this->CheckForEmptyValues($row['lost_to']);
		$property->strReasonLost =$this->CheckForEmptyValues($row['lost_reason']); 
		$property->strLwdNotes =$this->CheckForEmptyValues($row['lwd_notes']);
		$property->strValutionNotes =$this->CheckForEmptyValues($row['val_notes']); 
		$property->strPropertyTarnsfer =$this->valueReplace($row['prop_transf']);
		$property->strPropertyBranchValuer =$this->CheckForEmptyValues($row['branch_valuer']); 
		$property->strPropertyNegotiator=$this->CheckForEmptyValues($row['negotiator']); 
		$property->strArchive =$this->valueReplace($row['archive']); 
		$property->strSalesStatus =$this->SaleNoSale($row['sale_stat']); 
		$property->strPropertyInMarket =$this->valueReplace($row['propinmarket']); 
		$property->dtPropertyAvailableDate =$this->CheckForEmptyValues($row['prop_avail_date']); 
		$property->strKitchen =$this->valueReplace($row['kitchen']); 
		$property->strFloorNo =$this->valueReplace($row['floorno']); 
		$property->strFlooring =$this->valueReplace($row['Flooring']); 
		$property->boolFurnished  =$this->valueReplace($row['furnished']); 
		$property->boolLift  =$this->valueReplace($row['lift']); 
		$property->strPropCondition =$this->CheckForEmptyValues($row['prop_cond']);
		$property->strTube =$this->CheckForEmptyValues($this->valueReplace($row['tube'])); 
		$property->strPropertyCondition =$this->CheckForEmptyValues($row['prop_cond']);
		$property->strAllowSmoker =$this->CheckForEmptyValues($this->valueReplace($row['allow_smoker']))); 
		$property->strAllowStudent =$this->valueReplace($this->CheckForEmptyValues($this->valueReplace($row['allow_student'])));
		$property->strAllowChildren =$this->valueReplace($this->CheckForEmptyValues($this->valueReplace($row['allow_children'])));
		$property->strAllowPets =$this->valueReplace($this->CheckForEmptyValues($this->valueReplace($row['allow_pets']))); 
		$property->strInstructedDate =$this->CheckForEmptyValues($row['instructed_date']); 
		$property->strpropBrief =$this->CheckForEmptyValues($row['prop_short_desc']); 
		$property->strPropDescription =$row['prop_description']; 
		$property->strPropertyNotes =$this->CheckForEmptyValues($row['notes']); 
		$property->strPropertyLive =$this->valueReplace($row['live']); 
		$property->strAdvertDescription =$row['prop_advert_desc']; 
		$property->strpropertySub =$this->GetPropertyType($row['property_sub']); 
		$property->strPropertyFeature =$this->GetFeature($intPId); 
		$property->strLocalInfo =$this->CheckForEmptyValues($row['local_info']); 
		$property->strFeatureInsertBefore =$row['fet_insert_before'];
		$property->strOtherPl =$this->valueReplace($row['othersPL']);
		$property->dtSoldDate =$this->CheckForEmptyValues($row['sold_date']); 
		$property->tmSoldTime =$this->CheckForEmptyValues($row['sold_time']);
		$property->strCurrentPrice=$this->getCurrentPrice($intPId);	
		return $property;
	}
	private function GetDistrict($string)
	{
		$temp = explode('---',$string);
		if(!empty( $temp[0]))
		{
			$String .= $this->GetDistrictValue($temp[0]);
		}
		
		if(!empty( $temp[1]))
		{
			$String .= $this->GetDistrictValue($temp[1]);
		}
		if(!empty( $temp[2]))
		{
			$String .= $this->GetDistrictValue($temp[2]);
		}
		if(!empty( $temp[3]))
		{
			$String .= $this->GetDistrictValue($temp[3]);
		}
		if(!empty( $temp[4]))
		{
			$String .= $this->GetDistrictValue($temp[4]);
		}
		if(!empty( $temp[5]))
		{
			$String .= $this->GetDistrictValue($temp[5]);
		}
		if(!empty( $temp[6]))
		{
			$String .= $this->GetDistrictValue($temp[6]);
		}
		if(!empty( $temp[7]))
		{
			$String .= $this->GetDistrictValue($temp[7]);
		}
		if(!empty( $temp[8]))
		{
			$String .= $this->GetDistrictValue($temp[8]);
		}
		if(!empty( $temp[9]))
		{
			$String .= $this->GetDistrictValue($temp[9]);
		}
		if(!empty( $temp[10]))
		{
			$String .= $this->GetDistrictValue($temp[10]);
		}
		return $String;
	}
	private function GetDistrictValue($id)
	{
		$result=$this->conDatabase->query("select dist_name from lib_br_district where dist_id =".$id);
		$row = $result->fetch($result);
		return $row['dist_name'];
	}
	private function GetArea($string)
	{
		$temp = explode('---',$string);
		if(!empty( $temp[0]))
		{
			$String .= $this->GetAreaValue($temp[0]);
		}
		
		if(!empty( $temp[1]))
		{
			$String .= $this->GetAreaValue($temp[1]);
		}
		if(!empty( $temp[2]))
		{
			$String .= $this->GetAreaValue($temp[2]);
		}
		if(!empty( $temp[3]))
		{
			$String .= $this->GetAreaValue($temp[3]);
		}
		if(!empty( $temp[4]))
		{
			$String .= $this->GetAreaValue($temp[4]);
		}
		if(!empty( $temp[5]))
		{
			$String .= $this->GetAreaValue($temp[5]);
		}
		if(!empty( $temp[6]))
		{
			$String .= $this->GetAreaValue($temp[6]);
		}
		if(!empty( $temp[7]))
		{
			$String .= $this->GetAreaValue($temp[7]);
		}
		if(!empty( $temp[8]))
		{
			$String .= $this->GetAreaValue($temp[8]);
		}
		if(!empty( $temp[9]))
		{
			$String .= $this->GetAreaValue($temp[9]);
		}
		if(!empty( $temp[10]))
		{
			$String .= $this->GetAreaValue($temp[10]);
		}
		return $String;
	}
	private function GetAreaValue($id)
	{
		$result=$this->conDatabase->query("select ar_name from lib_br_area where area_id =".$id);
		$row = $result->fetch($result);
		return $row['ar_name'];
	}
	private function GetCriteria($string)
	{
		$temp = explode('---',$string);
		if(!empty( $temp[0]))
		{
			$String .= $this->GetCriteriaValue($temp[0]);
		}
		
		if(!empty( $temp[1]))
		{
			$String .= $this->GetCriteriaValue($temp[1]);
		}
		if(!empty( $temp[2]))
		{
			$String .= $this->GetCriteriaValue($temp[2]);
		}
		if(!empty( $temp[3]))
		{
			$String .= $this->GetCriteriaValue($temp[3]);
		}
		if(!empty( $temp[4]))
		{
			$String .= $this->GetCriteriaValue($temp[4]);
		}
		if(!empty( $temp[5]))
		{
			$String .= $this->GetCriteriaValue($temp[5]);
		}
		if(!empty( $temp[6]))
		{
			$String .= $this->GetCriteriaValue($temp[6]);
		}
		if(!empty( $temp[7]))
		{
			$String .= $this->GetCriteriaValue($temp[7]);
		}
		if(!empty( $temp[8]))
		{
			$String .= $this->GetCriteriaValue($temp[8]);
		}
		if(!empty( $temp[9]))
		{
			$String .= $this->GetCriteriaValue($temp[9]);
		}
		if(!empty( $temp[10]))
		{
			$String .= $this->GetCriteriaValue($temp[10]);
		}
		return $String;
	}
	private function GetCriteriaValue($id)
	{
		$result=$this->conDatabase->query("select spcriteria from lib_sp_criteria where spcr_id  =".$id);
		$row = $result->fetch($result);
		return $row['spcriteria'];
	}
	private function GetFeature($id)
	{
		$result=$this->conDatabase->query("select ftdesc from viewfor_prop_feature where prop_id =".$id);
		
		while($row = $result->fetch($result))
		{
			$string .=$row['ftdesc']."\n";
		}
		return $string;
	}
	public function getApplicant($intAId)
	{
	//@this gets the applicant information from the database
		$result=$this->conDatabase->query("SELECT * FROM applicant_table where applicantno =".$intAId);
		$row = $result->fetch($result);
		$applicant = new applicant();
		$applicant->strAddress=$row['property_no'].",".$row['property_name'].",".$row['road'].",".$row['add1'].",".$row['add2'].",".$row['add3'].",".$this->getTown($row['town']).",".$this->getCounty($row['county']).",".$row['postcode'].",".$this->getCountry($row['country']);
		$applicant->strHomePhone=$row['home_phone1'];
		$applicant->strBusPhone = $row['bus_phone1']; 
		$applicant->strFaxNo = $row['fax_no1'];
		
		$applicant->strMobileNo = $row['mobile_no1'];
		$applicant->strEmail = $row['email1'];
		$applicant->strSalutation=$row['salutation1'];
		$applicant->strCompanyName=$row['companyname'];
		$applicant->strNegotiator=$row['negotiator'];
		
		$applicant->strApplicantNo=$row['applicantno'];
		$applicant->strApplicantId=$row['applicant_id'];
		
		$applicant->strApplicantName=$row['title1'].",".$row['first_name1'].",".$row['initials1'].",".$row['sur_name1'];
		$applicant->strApplicantAllowSms = $this->valueReplace($row['allow_sms1']);
		$applicant->strApplicantAllowPost = $this->valueReplace($row['allow_post1']);
		$applicant->strApplicantAllowEmail = $this->valueReplace($row['allow_email1']);
		$applicant->strApplicantNms=$this->valueReplace($row['allow_mms1']); 
		$applicant->strApplicantAllowPhone = $this->valueReplace($row['allow_phone1']);
		$applicant->strAppliacantUsername=$row['username1'];
		$applicant->strApplicantPassword=$row['password1'];
		
		$applicant->strJAHomePhone=$row['home_phone2'];
		$applicant->strJABusPhone = $row['bus_phone2']; 
		$applicant->strJAFaxNo = $row['fax_no2'];
		$applicant->strJAMobileNo = $row['mobile_no2'];
		$applicant->strJAEmail=$row['email2'];
		$applicant->strJASalutation = $row['salutation2'];
		$applicant->strJApplicantName=$row['title2'].",".$row['first_name2'].",".$row['initials2'].",".$row['sur_name2'];
		$applicant->strJApplicantAllowSms = $this->valueReplace($row['allow_sms2']);
		$applicant->strJApplicantAllowPost = $this->valueReplace($row['allow_post2']);
		$applicant->strJApplicantAllowEmail = $this->valueReplace($row['allow_email2']);
		$applicant->strJApplicantNms=$this->valueReplace($row['allow_mms2']);
		$applicant->strJApplicantAllowPhone = $this->valueReplace($row['allow_phone2']);
		$applicant->strJAppliacantUsername=$row['username2'];
		$applicant->strJApplicantPassword=$row['password2'];
		
		$applicant->strNotes=$row['notes'];
		$applicant->dtDateEntered=$row['date_entered'];
		$applicant->dtDateLChanged=$row['date_lchanged'];
		$applicant->strapplicantRefId=$row['applicantrefid'];
		$applicant->strBranchId=$row['branch_id'];
		$applicant->strActive=$this->valueReplace($row['active']);
		$applicant->shareInfo=$row['sharing_info'];
		$applicant->applicantCurrentPosition=$row['current_position'];
		$applicant->strAlert=$row['alerts'];
		$applicant->strAddedPm=$row['addedPM'];
		return $applicant;
		
	}
	public function getPropertyLetter($intPrLid)
	{
		$result=$this->conDatabase->query("SELECT * FROM viewfor_property_letter where property_id = '$intPrLid'");
		$row = $result->fetch($result);
		$propertyletter = new PropertyLetter();	
		 $propertyletter->fltCommisionRate=$row['commision_rate'];
		 $propertyletter->boolsplitCommission=$row['split_commission'];
		 $propertyletter->CurFixedFee=$row['fixed_fee'];
		 $propertyletter->dtLeaseComenceDate=$row['Lease_comence_date'];
		 $propertyletter->IntLeaseNoYears=$row['lease_no_of_years'];
		 $propertyletter->curLeaseGroundRent=$row['lease_ground_rent'];
		 $propertyletter->boolLeasegroundFixed=$row['lease_ground_rent_fixed'];
		 $propertyletter->curLeaseMaintenanceCharge=$row['lease_maintenance_charge'];
		 $propertyletter->boolCopyLeaseAvailable=$row['copy_of_lease_available'];
		 $propertyletter->boolLeaseInsuranceIncluded=$row['lease_insurance_included'];
		 $propertyletter->strLeaseManagementCompany=$row['lease_management_company'];
		 $propertyletter->boolLeaseSittingTenants=$row['lease_sitting_tenants'];
		 $propertyletter->strAgencyType=$row['agency_type'];
		 $propertyletter->strAgencyPeriod=$row['agency_period'];	 
		 
		 return $propertyletter;
	}
	public function getValuationLetter($intVId)
	{
		//use the results obect with te connection object to build the sql query str and fetch results	
		$result=$this->conDatabase->query("SELECT * FROM viewfor_valuation_letter where property_id = ".$intVId);	
		$row = $result->fetch($result);
		$valLetter = new ValuationLetter();
		$valLetter->strVendorPropertyAddress=$row['vendor_property_no'].",".$row['vendor_property_name'].",".$row['vendor_address1_no'].",".$row['vendor_address1_name'].",".$row['vendor_address2'].",".$row['vendor_address3'].",".$row['vendor_town'].",".$row['vendor_county'].",".$row['vendor_country'].",".$row['vendor_postcode'];
		$valLetter->strJointVendorAddress=$row['joint_vendor_property_no'].",".$row['joint_vendor_property_name'].",".$row['joint_vendor_address1_no'].",".$row['joint_vendor_address1_name'].",".$row['joint_vendor_address2'].",".$row['joint_vendor_address3'].",".$row['joint_vendor_town'].",".$row['vendor_county'].",".$row['joint_vendor_country'].",".$row['joint_vendor_postcode'];
		$valLetter->strPropSubCategory =$row['property_sub_category'];
		$valLetter->strPropCategory =$row['property_category'];
		$valLetter->strCancelDate =$row['cancel_date'];
		$valLetter->strLostToEstateAgent =$row['lost_to_estate_agent'];
		$valLetter->strCancelReason=$row['cancel_reason'];
		$valLetter->strCancelNotes =$row['cancel_notes'];
		$valLetter->strContactDate=$row['contacted_date'];
		return $valLetter;
	}
	private function getViewCancel1($id)
	{
		$result=$this->conDatabase->query("select * from cancel_view where view_id =".$id);
		$row = $result->fetch($result);
		return $row['reqdate'];
	}
	private function getViewComplete2($id)
	{
		$result=$this->conDatabase->query("select * from complete_view where view_id =".$id);
		$row = $result->fetch($result);
		return $row['reqdate'];
	}
	private function getViewCancel2($id)
	{
		$result=$this->conDatabase->query("select * from cancel_view where view_id =".$id);
		$row = $result->fetch($result);
		return $rwo['notes'];
	}
	private function getViewComplete3($id)
	{
		$result=$this->conDatabase->query("select * from complete_view where view_id =".$id);
		$row = $result->fetch($result);
		return $row['notes'];
	}	
	public function getViewingLetter($intVId)
	{
		//use the results obect with te connection object to build the sql query str and fetch results	
		//select * from view_details //
		$result=$this->conDatabase->query("SELECT view_id, ap_id, prop_id, view_date, view_time, view_duration, applicant_confirm, vendor_confirm, applicant_key, applicant_title, applicant_initials, applicant_first_name, applicant_sur_name, applicant_home_phone, applicant_bus_phone, applicant_fax_no, applicant_email, applicant_allow_email, applicant_mobile, applicant_allow_sms, applicant_allow_post, applicant_salutation, joint_applicant_title, joint_applicant_first_name, joint_applicant_initials, joint_applicant_sur_name, joint_applicant_home_phone, joint_applicant_bus_phone, joint_applicant_email, joint_applicant_fax_no, joint_applicant_mobile, joint_applicant_allow_email, joint_applicant_allow_post, applicant_company_name, applicant_negotiator, applicant_property_no, applicant_property_name, applicant_address1_no, applicant_address1_name, applicant_address2, applicant_address3, applicant_postcode, applicant_town, applicant_county, applicant_country, applicant_branch, applicant_branch_phone_no, applicant_branch_fax_no, applicant_branch_email, applicant_solicitor_company_name, applicant_solicitor_address1_no, applicant_solicitor_address1_name, applicant_solicitor_address2, applicant_solicitor_address3, applicant_solicitor_town, applicant_solicitor_county, applicant_solicitor_country, applicant_solicitor_postcode, applicant_solicitor_phoneno, applicant_solicitor_faxno, applicant_solicitor_contact_name, applicant_solicitor_mobileno, applicant_solicitor_email, applicant_solicitor_salutation, property_key, vendor_title, vendor_initials, vendor_first_name, vendor_sur_name, vendor_home_phone, vendor_bus_phone, vendor_mobile_no, vendor_fax_no, vendor_email, joint_vendor_title, joint_vendor_first_name, joint_vendor_initials, joint_vendor_sur_name, joint_vendor_home_phone, joint_vendor_bus_phone, joint_vendor_mobile_no, joint_vendor_fax_no, joint_vendor_email, vendor_salutation, company_name, property_no, property_name, property_address1_no, property_address1_name, property_address2, property_address3, property_town, property_county, property_country, property_postcode, property_for, property_bedrooms, property_receptions, property_bathrooms, property_asking_price, property_valuation_price, property_quick_sell_price, property_test_market_price, property_vendor_opinion_price, property_current_price, property_branch, property_branch_phoneno, property_branch_faxno, property_branch_email, property_sale_status, property_negotiator, property_brief_description, property_instructed_date, vendor_solicitor_company_name, vendor_solicitor_address1_no, vendor_solicitor_address1_name, vendor_solicitor_address2, vendor_solicitor_address3, vendor_solicitor_town, vendor_solicitor_county, vendor_solicitor_country, vendor_solicitor_postcode, vendor_solicitor_phoneno, vendor_solicitor_faxno, vendor_solicitor_contact_name, vendor_solicitor_mobileno, vendor_solicitor_email, vendor_solicitor_salutation, vendor_property_no, vendor_property_name, vendor_address1_no, vendor_address1_name, vendor_address2, vendor_address3, vendor_town, vendor_county, vendor_country, vendor_postcode, joint_vendor_property_no, joint_vendor_property_name, joint_vendor_address1_no, joint_vendor_address1_name, joint_vendor_address2, joint_vendor_address3, joint_vendor_town, joint_vendor_county, joint_vendor_country, joint_vendor_postcode, vendor_allow_sms, vendor_allow_email, vendor_allow_post, joint_vendor_allow_sms, joint_vendor_allow_email, joint_vendor_allow_post FROM viewfor_viewingLetter where prop_id = '$intVId'");	
		$row = $result->fetch($result);
		$Viewlet = new ViewingLetter();
		$Viewlet->strViewId = $row['view_id']; 
		$Viewlet->strApId=$row['ap_id']; 
		$Viewlet->strPropId=$row['prop_id']; 
		$Viewlet->strViewDate=$row['view_date']; 
		$Viewlet->strViewTime=$row['view_time']; 
		$Viewlet->strViewDuration=$row['view_duration']; 
		$Viewlet->strApplicantConfirm=$row['applicant_confirm']; 
		$Viewlet->strVendorConfirm=$row['vendor_confirm'];
		$Viewlet->strCancelDate=$this->getViewCancel1($row['view_id']);
		$Viewlet->strCancelReason=$this->getViewCancel2($row['view_id']);
		$Viewlet->strCompleteDate=$this->getViewComplete2($row['view_id']);
		$Viewlet->strCompletedNotes= $this->getViewComplete3($row['view_id']);
		return $Viewlet;
	}
	public function getVendor($intId)
	{
		//use the results obect with te connection object to build the sql query str and fetch results	
		$result=$this->conDatabase->query("select * from vendor_contact where vendorno='$intId'");	
		$row = $result->fetch($result);
		$vendor = new vendor();
		//build address line for vendor	
		$vendor->strVendorNumber=$row['vendorno'];
		$vendor->strCompanyName=$this->CheckForEmptyValues($row['companyname']);	
		//detect and concat second faxno if exists
		$vendor->strSalutation=$this->CheckForEmptyValues($row['salutation1']);
		$vendor->strVendorName=$this->CheckForEmptyValues($row['title1']).",".$this->CheckForEmptyValues($row['first_name1']).",".$this->CheckForEmptyValues($row['initials1']).",".$this->CheckForEmptyValues($row['sur_name1']);
		$vendor->strFaxNo=$this->CheckForEmptyValues($row['fax_no1']);
		$vendor->strHomePhone=$this->CheckForEmptyValues($row['home_phone1']);
		$vendor->strBusPhone=$this->CheckForEmptyValues($row['bus_phone1']);
		$vendor->strMobileNo=$this->CheckForEmptyValues($row['mobile_no1']);
		$vendor->strEmail=$this->CheckForEmptyValues($row['email1']);
		$vendor->strVendorUsername=$this->CheckForEmptyValues($row['username1']);
		$vendor->strVendorPassword=$this->CheckForEmptyValues($row['password1']);
		$vendor->strVendor_allow_sms=$this->valueReplace($row['allow_sms1']);
		$vendor->strVendor_allow_post=$this->valueReplace($row['allow_post1']);
		$vendor->strVendor_allow_MMs=$this->valueReplace($row['allow_mms1']);
		$vendor->strVendor_allow_email=$this->valueReplace($row['allow_email1']);
		$vendor->strVendor_allow_phone=$this->valueReplace($row['allow_phone1']);		
		$vendor->strJVendorName=$this->CheckForEmptyValues($row['title2']).",".$this->CheckForEmptyValues($row['first_name2']).",".$this->CheckForEmptyValues($row['initials2']).",".$this->CheckForEmptyValues($row['sur_name2']);
		$vendor->strJVFaxNo=$this->CheckForEmptyValues($row['fax_no2']);
		$vendor->strJVHomePhone=$this->CheckForEmptyValues($row['home_phone2']);
		$vendor->strJVBusPhone=$this->CheckForEmptyValues($row['bus_phone2']);
		$vendor->strJVMobileNo=$this->CheckForEmptyValues($row['mobile_no2']);
		$vendor->strJVEmail=$this->CheckForEmptyValues($row['email2']);
		$vendor->strJVendorUsername=$this->CheckForEmptyValues($row['username2']);
		$vendor->strJVendorPassword=$this->CheckForEmptyValues($row['password2']);
		$vendor->strJVendor_allow_sms=$this->valueReplace($row['allow_sms2']);
		$vendor->strJVendor_allow_post=$this->valueReplace($row['allow_post2']);
		$vendor->strJVendor_allow_MMs=$this->valueReplace($row['allow_mms2']);
		$vendor->strJVendor_allow_email=$this->valueReplace($row['allow_email2']);
		$vendor->strJVendor_allow_phone=$this->valueReplace($row['allow_phone2']);	
		$vendor->strBranchName = $this->CheckForEmptyValues($row['branch_name']);
		$vendor->strPropFor = $this->SaleNoSale($row['prop_for']);
		$vendor->strVendorNotes = $this->CheckForEmptyValues($row['notes']);
		$vendor->dtDateEntered = $this->CheckForEmptyValues($row['date_entered']);
		$vendor->dtLastChanaged=$this->CheckForEmptyValues($row['date_lchanged']);
		$vendor->strVendorReferenceId =$this->CheckForEmptyValues($row['vendorrefid']);
		$vendor->intBranchId=$this->CheckForEmptyValues($row['branch_id']);
		$vendor->strVendorUserRights = $this->CheckForEmptyValues($row['userright']); 
		return $vendor;
	}
	private function valueReplace($strValue)
	{
		//@@get value check to see if it is 0 or 1 if 0 then it is no 
		//@@if 1 then it is yes
		if($strValue=='0')
		return $strValue ='No';
		else 
		if($strValue='1')
		return $strValue='Yes';
	}
	public function getOutFsVendor($strOutFSVendorId)
	{
		
		//use the results obect with te connection object to build the sql query str and fetch results	
		$result=$this->conDatabase->query("SELECT * FROM viewfor_OutFs_Letter_Vendor where apt_id='$strOutFSVendorId'");	
		$row = $result->fetch($result);
		$OutFsVendor = new OutFsVendorLetter();
		//build address line for vendor
		$OutFsVendor->strAptID=$row['apt_id'];
		$OutFsVendor->strFsContactId=$row['fs_contact_id'];	
		//detect and concat second faxno if exists
		$OutFsVendor->strFsAppoinmantperson=$row['fs_appointment_person'];
		$OutFsVendor->strFsposition=$row['fs_position'];
		$OutFsVendor->strFsPrimaryContact=$row['fs_primary_contact'];
		$OutFsVendor->strFsComanyName=$row['fs_comp_name'];
		$OutFsVendor->strFsComanyAddress=$row['fs_comp_add1']." ".$row['fs_comp_add2']." ".$row['fs_comp_add3']." ".$row['fs_comp_road']." ".$row['fs_comp_town']." ".$row['fs_comp_county']." ".$row['fs_comp_country']." ".$row['fs_comp_postcode'];
		$OutFsVendor->strCompRef=$row['fs_comp_dx_ref'];
		$OutFsVendor->strVendorNegotiator=$row['fs_comp_negotiator'];
		$OutFsVendor->strCompanyContactName=$row['fs_comp_cot_cat'];
		$OutFsVendor->strPropertyId=$row['property_id'];
		
		
		return $OutFsVendor;
	}
	public function getOutFs($strOutFSId)
	{
		//use the results obect with te connection object to build the sql query str and fetch results	
		$result=$this->conDatabase->query("SELECT * FROM viewfor_OutFs_Letter_Vendor where apt_id='$strOutFSId'");	
		$row = $result->fetch($result);
		$OutFs = new OutFsLetter();
		//build address line for vendor
		$OutFs->strAptID=$row['apt_id'];
		$OutFs->strFsContactId=$row['fs_contact_id'];	
		$OutFs->strFsCotid=$row['fs_cot_id'];
		//detect and concat second faxno if exists
		$OutFs->strFsAppoinmantperson=$row['fs_appointment_person'];
		$OutFs->strFsposition=$row['fs_position'];
		$OutFs->strFsBrAddress=$row['fs_br_add1']." ".$row['fs_br_add2']." ".$row['fs_br_add2']." ".$row['fs_br_add3'].
		" ".$row['fs_br_town']." ".$row['fs_br_county']." ".$row['fs_br_county']." ".$row['fs_br_country'].
		",".$row['fs_br_postcode'];
		$OutFs->strPhoneNum=$row['fs_phoneno'];
		$OutFs->strMobileNum=$row['fs_mobile'];
		$OutFs->strSalutation=$row['fs_salutation'];
		$OutFs->strEmail=$row['fs_email'];
		$OutFs->strFsPrimaryContact=$row['fs_primary_contact'];
		$OutFs->strNegotiator=$row['fs_negotiator'];
		$OutFs->strSameCompany=$row['fs_same_commpany'];
		$OutFs->strCotCat=$row['fs_comp_cot_cat'];
		$OutFs->strCompanyName=$row['fs_comp_name'];
		$OutFs->strCompAddress=$row['fs_comp_add1']." ".$row['fs_comp_add2']." ".$row['fs_comp_add3']." ".$row['fs_comp_road']." ".$row['fs_comp_town']." ".$row['fs_comp_county']." ".$row['fs_comp_country']." ".$row['fs_comp_postcode'];
		$OutFs->strCompanyPhoneNum=$row['fs_comp_phoneno'];
		$OutFs->strCompanyFaxNum=$row['fs_comp_faxno'];
		$OutFs->strCompanyDXRef=$row['fs_comp_dx_ref'];
		$OutFs->strCompanyTerms=$row['fs_comp_terms'];
		$OutFs->strCompanyEmail=$row['fs_comp_emails'];
		$OutFs->strCompanyNotes=$row['fs_comp_notes'];
		$OutFs->strCompanyNegotiator=$row['fs_comp_negotiator'];
		$OutFs->ConcatName=$row['fs_concat_name'];
		$OutFs->PropertyKey=$row['property_key'];
		
		
		return $OutFs;
	}
	public function GetInFsVendorLetter($intIFVLid)
	{
		$result=$this->conDatabase->query("SELECT * FROM viewfor_InFs_Letter_Vendor where property_id ='$intIFVLid'");
		$row = $result->fetch($result);
		$InFsVendor = new InFsVendorLetter();
		$InFsVendor->strAptID =$row['apt_id'];
		$InFsVendor->fs_appointment_notes =$row['fs_appointment_notes']; 
		$InFsVendor->fs_appointment_date =$row['fs_appointment_date']; 
		$InFsVendor->fs_appointment_time =$row['fs_appointment_time'];
		$InFsVendor->fs_appointment_duration =$row['fs_appointment_duration']; 
		$InFsVendor->strFsAppoinmantperson =$row['fs_appointment_person']; 
		$InFsVendor->strPropertyId =$row['property_id']; 
		
		return $InFsVendor;
	}
	public function GetInFsLetter($intIFVLid)
	{
		$result=$this->conDatabase->query("SELECT apt_id, ap_id, appointment_notes, appointment_date, appointment_time, appointment_duration, appointment_person, applicant_negotiator FROM viewfor_InFSLetter where ap_id ='$intIFVLid'");
		$row = $result->fetch($result);
		$InFs = new InFsLetter();
		$InFs->strAptID =$row['apt_id'];
		$InFs->strApplicantId=$row['ap_id'];
		$InFs->fs_appointment_notes =$row['fs_appointment_notes']; 
		$InFs->fs_appointment_date =$row['fs_appointment_date']; 
		$InFs->fs_appointment_time =$row['fs_appointment_time'];
		$InFs->fs_appointment_duration =$row['fs_appointment_duration']; 
		$InFs->strFsAppoinmantperson =$row['fs_appointment_person']; 
		return $InFs;
	}
	public function getProgress($intId)
	{
		$result=$this->conDatabase->query("SELECT * FROM viewfor_salesprogress where prop_id ='$intId'");
		$row = $result->fetch($result);

		$progress = new Progress();
		$progress->intOfferId =$row['offer_id']; 
		$progress->intApplicantId =$row['ap_id']; 
		$progress->intPropertyId =$row['prop_id'];
		$progress->curOfferAmount = $row['offer_amount'];
		$progress->dtOfferDate =$row['offer_date'];
		$progress->tmOfferTime =$row['offer_time']; 
		$progress->strOfferNotes =$row['int_notes']; 
		$progress->strlocalAuthority =$row['local_auth']; 
		$progress->strbuyerPosition =$row['buyer_pos']; 
		$progress->strFinancialInformation =$row['finance_info']; 
		$progress->strType =$row['type']; 
		$progress->strcomp =$row['total_commission']; 
		return $progress;
	}
	public function getMemo($id)
	{
		$result=$this->conDatabase->query('SELECT * FROM app_conv_table where prop_id ='.$id);
		$row = $result->fetch($result);
		$Memo = new Memo();
		$Memo->strSubject = $this->CheckForEmptyValues($row['comments']);
		$Memo->tmTime = $this->CheckForEmptyValues($row['reqtime']);
		$Memo->dtDate = $this->CheckForEmptyValues($row['reqdate']);
		$Memo->strNotes = $this->CheckForEmptyValues($row['notes']);
		return $Memo;
	}
	public function GetVendorsAddress($intId)
	{
		$result=$this->conDatabase->query("SELECT * FROM vendor_correspondence where vendorno =".$intId);
		$row=$result->fetch($result);
		if(empty($row))
		{
			$VendorAddress = new VAddress();
		}
		else 
		{
			$VendorAddress = new VAddress();
			$VendorAddress->strVendorPropNumber=$this->CheckForEmptyValues($row['prop_no1']);
		 	$VendorAddress->strVendorPropName=$this->CheckForEmptyValues($row['prop_name1']);
		 	$VendorAddress->strVendorAdressLine1=$this->CheckForEmptyValues($row['add11']);
		 	$VendorAddress->strVendorAddressLine2=$this->CheckForEmptyValues($row['add21']);
		 	$VendorAddress->strVendorAddressLine3=$this->CheckForEmptyValues($row['add31']);
		 	$VendorAddress->strVendorAddressTown=$this->CheckForEmptyValues($this->getTown($row1['town1']));
		 	$VendorAddress->strVendorAddressCounty=$this->CheckForEmptyValues($this->getCounty($row1['county1']));
		 	$VendorAddress->strVendorAddressCountry=$this->CheckForEmptyValues($this->getCountry($row['country1']));
		 	$VendorAddress->strVendorAddressPostcode=$this->CheckForEmptyValues($row['postcode1']);
		}
		return $VendorAddress;
	}
	public function GetJVendorsAddress($intId)
	{
		$result=$this->conDatabase->query("SELECT * FROM vendor_correspondence where vendorno =".$intId);
		$row=$result->fetch($result);
		if(empty($row))
		{
		$jointVendorAddress = new JVAddress();
		}
		else
		{
			$jointVendorAddress = new JVAddress();
			$jointVendorAddress->strJVendorPropNumber=$this->CheckForEmptyValues($row['prop_no2']);
			$jointVendorAddress->strJVendorPropName=$this->CheckForEmptyValues($row['prop_name2']);
	 	$jointVendorAddress->strJVendorAdressLine1=$this->CheckForEmptyValues($row['add21']);
	 	$jointVendorAddress->strJVendorAddressLine2=$this->CheckForEmptyValues($row['add22']);
	 	$jointVendorAddress->strJVendorAddressLine3=$this->CheckForEmptyValues($row['add32']);
	 	$jointVendorAddress->strJVendorAddressTown=$this->CheckForEmptyValues($this->getTown($row['town2']));
	 	$jointVendorAddress->strJVendorAddressCounty=$this->CheckForEmptyValues($this->getCounty($row['county2']));
	 	$jointVendorAddress->strJVendorAddressCountry=$this->CheckForEmptyValues($this->getCountry($row['country2']));
	 	$jointVendorAddress->strJVendorAddressPostcode=$this->CheckForEmptyValues($row['postcode2']);
		
		}
	 	return $jointVendorAddress;
	}
	public function getBTM($id)
	{
		$result=$this->conDatabase->query('SELECT * FROM prop_back where prop_id ='.$id);
		$row = $result->fetch($result);
		$BTM = new BackTMark();
		$BTM->strSubject = $this->CheckForEmptyValues($row['reason']);
		$BTM->tmTime = $this->CheckForEmptyValues($row['reqtime']);
		$BTM->dtDate = $this->CheckForEmptyValues($row['reqdate']);
		$BTM->strNotes = $this->CheckForEmptyValues($row['notes']);
		return $BTM;
		
	}
	public function getVenSolicitor($intSId)
	{
		//@gets vendor information from the database
		$result=$this->conDatabase->query("SELECT property_id, contact_name,br_add1,br_add2, br_add3, br_town,br_county,br_country,br_postcode, br_road,phoneno,mobile,salutation,comp_name FROM viewfor_vensolicitor_new where property_id ='$intSId'");
		
		$row = $result->fetch($result);
		if(empty($row))
		{
			$solicitor = new Solicitor();
		}
		else {
		$solicitor = new Solicitor();
		$solicitor->strContactName=$this->CheckForEmptyValues($row['contact_name']);
		$solicitor->strAddress=$this->CheckForEmptyValues($row['br_add1']).",".$this->CheckForEmptyValues($row['br_add2']).",".$this->CheckForEmptyValues($row['br_add3']).",".$this->CheckForEmptyValues($row['br_town']).",".$this->CheckForEmptyValues($row['br_county']).",".$this->CheckForEmptyValues($row['br_country']).",".$this->CheckForEmptyValues($row['br_road']).",".$this->CheckForEmptyValues($row['br_postcode']);
		$solicitor->strPhoneNumber=$this->CheckForEmptyValues($row['phoneno']);
		}
		return $solicitor;
	}
	public function getAppSolicitor($intId)
	{
		//@gets the applicants solicitors information
		$result=$this->conDatabase->query("SELECT contact_name,br_add1,br_add2, br_add3,br_road, br_town, br_country, br_county, br_postcode, phoneno FROM viewfor_appsolicitor where applicantno =".$intId);
		$row = $result->fetch($result);
		if(empty($row))
		{
			$appsolicitor = new AppSolicitor();
		}
		else
		{
			$appsolicitor = new AppSolicitor();
		$appsolicitor->strContactName=$this->CheckForEmptyValues($row['contact_name']);
		$appsolicitor->strAddress=$this->CheckForEmptyValues($row['br_add1']).",".$this->CheckForEmptyValues($row['br_add2']).",".$this->CheckForEmptyValues($row['br_add3']).","
		.$this->CheckForEmptyValues($row['br_road']).",".$this->CheckForEmptyValues($row['br_postcode']).",".$this->CheckForEmptyValues($row['br_town']).",".$this->CheckForEmptyValues($row['br_county']).",".$this->CheckForEmptyValues($row['br_country']);
		$appsolicitor->strCompanyName=$this->CheckForEmptyValues($row['comp_name']);
		$appsolicitor->strPhoneNumber=$this->CheckForEmptyValues($row['phoneno']);
			
		}
	
		
		return $appsolicitor;
	}
	public function getRooms($intRId)
	{
		//@gets the room details from the database
		$RoomArray = array();
		$result=$this->conDatabase->query("SELECT prop_id, pr_heading,pr_details,pr_length,pr_l_in,pr_width,pr_w_in,img FROM prop_room where prop_id ='$intRId'");
		//@while there is information in the record set then qdd another object to the object array
		while($row = $result->fetch($result))
		{
			
			$room = new Room();
			$room->fltRoomLength=$this->ConditionalConcat($row['pr_length']," X ",$row['pr_l_in']);
			$room->fltRoomWdith=$this->ConditionalConcat($row['pr_width']," X ",$row['pr_w_in']);
			$room->strRoomName=$row['pr_heading'];
			$room->strDescription=$row['pr_details'];
			$room->imgRoomImage=Config::$ImageDirectory.$this->CheckForEmptyImages($row['img']);
			//@now put object in the array its self
			array_push($RoomArray,$room);
		}
		
		return $RoomArray;
	}
	public function getUser($strUserId)
	{
		
	//@get the user from the site database
		$result=$this->conDatabase->query("SELECT * FROM lib_br_staff where username ='$strUserId'");
		$row = $result->fetch($result);
		$User = new User();
		$User->strUser=$row['first_name'].$row['sur_name'];
		$User->strUsername =$row['username'];
		$User->strPosition =$row['position'];
		$User->strMobileNumber =$row['mobile_no'];
		$User->picImage =Config::$staffPhotoUrl.$this->CheckForEmptyImages($row['image']);
		$User->picSignature = Config::$staffSignUrl.$this->CheckForEmptyImages($row['sign']);
		$User->strBranchId = $row['branch_id'];
		$User->strBranchPhone = $row['br_phone'];
		$User->strEmailAddress = $row['email'];
		$User->strDepartment=$this->CheckForEmptyValues($row['department']);
		if($User->strDepartment=="")
		{
			$User->strDepartment = "No Branch Details";
		}
		else 
		{
			$User->strDepartment = $this->GetDepartment($row['department']);
		}
		return $User;
	}
	public function getBranch($branchId)
	{
		//@get the branch from the session variable this will enable the solution to dynamically pick up the header and the footer
		$result=$this->conDatabase->query("SELECT * FROM lib_branch where branch_id ='$branchId'");
		$row = $result->fetch($result);
		$branch = new Branch();
		$branch->strAddress=$row['Address'].$row['town'].$row['county'].$row['country'];
		$branch->strBranchName=$row['branch_name'];
		$branch->strBranchManager=$this->CheckForEmptyValues($row['branch_mng']);
		$branch->strTelePhone=$row['phone_no'];
		$branch->strFax=$this->CheckForEmptyValues($row['fax_no']);
		$branch->strEmailAddress=$this->CheckForEmptyValues($row['email']);
		$branch->strHeader=$this->CheckForEmptyValues($row['header_value']);
		$branch->strFooter=$this->CheckForEmptyValues($row['footer_value']);
		return $branch;
		
	}
	public function getContacts($Id)
	{
		$result = $this->conDatabase->query("SELECT * from viewfor_all_contact_details where ");
		$row = $result->fetch($result);//contact_id,cot_id,mobile,primary_contact,negotiator,same_commpany,comp_cot_cat
		$Contact = new Contact();//comp_phoneno,concat_name
		$Contact->strCompanyName  = $row['comp_name'];
		$Contact->strFaxNo  = $row['comp_faxno'];
		$Contact->strDxRef  = $row['comp_dx_ref'];
		$Contact->strTerms  = $row['comp_terms'];
		$Contact->strNotes  = $row['comp_notes'];
		$Contact->strAddressRoadNo  = $row['br_add1'];
		$Contact->strAddressRoadName  = $row['br_road'];
		$Contact->strAddress2  = $row['br_add2'];
		$Contact->strAddress3  = $row['br_add3'];
		$Contact->strCountry  = $row['br_country'];
		$Contact->strCounty  = $row['br_county'];
		$Contact->strTown  = $row['br_town'];
		$Contact->strPostCode  = $row['br_postcode'];
		$Contact->strPhoneNo  = $row['phoneno'];
		$Contact->strEmailAddress  = $row['email'];
//		$Contact->strAddress  = $row[''];
//		$Contact->strAddressBlock  = $row[''];
		$Contact->strContactName  = $row['contact_name'];
		$Contact->strPosition  = $row['position'];
		$Contact->strContactPhone  = $row[''];
		$Contact->strSalutation  = $row['salutation'];
		return $Contact;
	}
	public function getPropertyList()
	{
		$PropArray = array();
		$result=$this->conDatabase->query("SELECT property_id,prop_short_desc FROM ven_property_info");
		//@while there is information in the record set then qdd another object to the object array
		while($row = $result->fetch($result))
		{
			$PropertyList = new PropertyList();
			$PropertyList->strProperty_id=$row['property_id'];
			$PropertyList->strPropertyDecriptionbrief=$row['prop_short_desc'];
			//@now put object in the array its self
			array_push($PropArray,$PropertyList);
		}
		
		return $PropArray;
		
	}
	private function getCurrentPrice($id)
	{
		$result = $this->conDatabase->query('select currentprice from viewfor_property where vendorno ='.$id);
		$row = $result->fetch($result);
		return $row['currentprice'];
	}
	private function SaleNoSale($strValue)
	{
		if($strValue=='0')
		return $strValue ='Rental';
		else 
		if($strValue='1')
		return $strValue='Sale';
	}
	private function CheckForEmptyValues($strRowValue)
	{
	//@validation for empty record set feilds
		$strTemp = $strRowValue;
		if($strTemp!=null)
		{
			return $strTemp;
		}
		else
		{
			$strTemp = "";
			return $strTemp;
		}
	}
	private function CheckForEmptyImages($strRowValue)
	{
	//@validation for empty record set feilds
		$strTemp = $strRowValue;
		if(($strTemp!=null)||($strTemp!=''))
		{
			return $strTemp;
		}
		else
		{
			$strTemp = "prop-photo.jpg";
			return $strTemp;
		}
	}
	private function ConditionalConcat($strFValue,$strConcat,$strSValue)
	{
	//@ concatinate the joint applicant, solicitor, vendor, solicitor
		$strResult = $strFValue;
		if(strlen($strSValue)>3);
		{
			$strResult .= $strConcat.$strSValue; 	
		}
		return $strResult;
	}
	public function getWorkOrderID($id)
	{
	//@get the work order id from the database 
		$result=$this->conDatabase->query("SELECT * FROM Brochures where WorkOrderEntity='$id'");
		$row = $result->fetch($result);
		$WorkOrderID = $row['WorkOrderEntity'];
		return $WorkOrderID;
		
	}
	//@@get the site based directory fvrom the admin table in the dtaabase table 
	public function getSiteBaseUrl()
	{
		$result=$this->conDatabase->query("SELECT url_path FROM lib_admin");
		$row = $result->fetch($result);
		$Path = $row['url_path'];
		return $Path;
	}
	public function InsertCompletedDoc($id,$DocType,$templateFileName,$sysTitle,$Pid)
	{
		//@@return switch case to support multiple insert of document types to thr relevant database 
		$path = $this->getSiteBaseUrl();
		$timestamp = time();
		$file_array =explode(".",$templateFileName);
		$TempDoc = $templateFileName;
		$timeDate= date("y/m/d : H:i:s", $timestamp);
		//@@return switch statement to select the insert based on the value sent as parameters
		switch($DocType)
		{
			case 'Letter':
							$result=$this->conDatabase->query('insert into Letters SET WorkOrderEntity="'.$id.'", DocFilename = "'.$TempDoc.'", Prid = "'.$Pid.'", strTemplate = "'.$sysTitle.'", tmTmpStamp = "'.$timeDate.'"');
							break;
		   	case 'Brochure':
							$result=$this->conDatabase->query('insert into Brochures SET WorkOrderEntity="'.$id.'", DocFilename = "'.$TempDoc.'", Prid = "'.$Pid.'", strTemplate = "'.$sysTitle.'", tmTmpStamp = "'.$timeDate.'"');
							break;
			case 'default':
							break;
		}
	}
	public function InsertCompletedTempDoc($TempDoc,$sysTitle,$DocType,$id,$Title)
	{
		//@@return switch case to support multiple insert of document types to thr relevant database 
		$path = $this->getSiteBaseUrl();
		$timestamp = time();
		$description=$Title;
		$timeDate= date("y/m/d : H:i:s", $timestamp);

		//@@return switch statement to select the insert based on the value sent as parameters
		switch($DocType)
		{
			case 'Letter_Template':
							$result=$this->conDatabase->query('insert into Letter_templates SET strTemplateTitle = "'.$sysTitle.'", strTemplateDescription = "'.$description.'", tmTmpStamp = "'.$timeDate.'",WorkOrderEntity="'.$id.'"');
							break;
			case 'Brochure_Template':	
							$result=$this->conDatabase->query('insert into Brochure_templates SET strXmlTemplateUrl="'.$path.'", strTemplateTitle = "'.$sysTitle.'", strTemplateDescription = "'.$description.'", tmTmpStamp = "'.$timeDate.'"');
							break;
			case 'default':
							break;
		}
	}
}
?>