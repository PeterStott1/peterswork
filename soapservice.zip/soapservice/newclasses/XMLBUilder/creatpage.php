<?

echo "Welcome to the new table installation object";
echo "<form id=\"frm1\" name=\"frm1\" action=\"creattest.php\" method=\"get\">";
echo "<button type=\"Submit\" name=\"do\"Value=\"Create_DataBase\">";
echo "Create DataBase";
echo "</button>";
echo "</form>";
?>