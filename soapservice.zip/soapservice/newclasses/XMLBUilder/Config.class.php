<?php
//@@return this is a one point of access configuration class built to allow database connection that
//@@return that is used to connect to the database across the solution
require_once('mysqlclass.php');
//@@configuration file requires a static function not to be changed unless you 
//@@return need it to be added it to a new web site
class Config
{
	
	public static $ImageDirectory = "../propphoto/";
	public static $TemplateDirectory= "/Templates/";
	
	
	public static function CreateDbConn()
	{	
		$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3dev'));
		return $db;
	}
	
	public static function __get($name)
	{
		return $this->$name;
		
	}
	
}

?>