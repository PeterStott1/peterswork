<?
//@@tghis will build the tebles into the new database structure
class setupdb 
	{
		//@@this is the type of connection string is stored
		public $mySql;
	
		public function __construct($db)
		{
			//@@the connection is part of the object and is needed so 
			//@@we need to add it to the constructor
			//@@ or the object will not work
			$this->mySql = $db;
		}
		
		public function CreateDatabase()
		{

			$query  = "CREATE TABLE Letters ( ";                                                                                                                                                     
           	$query  .="Le_ID int(10) unsigned NOT NULL auto_increment,";                                                                                                                           
           	$query .="WorkOrderEntity text NOT NULL,   ";                                                                                                                                          
           	$query .="DocFilename text NOT NULL,   ";                                                                                                                                              
           	$query .="PrId int(10) unsigned NOT NULL COMMENT 'This is the proeprty id that will be stored in the database so users can collect past letters that have been sent to recipients',   "; 
           	$query .="strTemplate text NOT NULL,     ";                                                                                                                                              
          	$query .="tmTmpStamp timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, ";                                                                                     
          	$query .=" PRIMARY KEY (Le_ID) ";                                                                                                                                                      
        	$query .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1 ;" ;                                                                                                                                       
			$this->mySql->query($query);
		
			sleep(2);
			$query  = "CREATE TABLE Letter_templates (  ";                                                                                                                                                     
           	$query  .="intTempLetId int(3) NOT NULL auto_increment,";                                                                                                                           
           	$query .="strTemplateTitle text,";                                                                                                                                          
           	$query .="strTemplateDescription text NOT NULL,";                                                                                                                                              
           	$query .="tmTmpstamp timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, "; 
           	$query .="WorkOrderEntity text NOT NULL,";                                                                                                                                              
          	$query .="PRIMARY KEY USING BTREE (intTempLetId)";                                                                                                                                                                                                                                
        	$query .= ") ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;" ;                                                                                                                                       
			$this->mySql->query($query);

			sleep(2);
					
			$query  = "CREATE TABLE Brochures (";
			$query .= "Br_ID int(10) unsigned NOT NULL auto_increment,";
			$query .= "WorkOrderEntity text NOT NULL,";
			$query .= "DocFilename text NOT NULL,";
			$query .= "Prid int(10) unsigned NOT NULL COMMENT 'this is stored to collect archive brochures for the user to select from website interface',  ";
			$query .= "strTemplate text NOT NULL,";
			$query .= "tmTmpStamp timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,";
			$query .= "PRIMARY KEY  (Br_ID)";
			$query .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC";
			$this->mySql->query($query);

			sleep(2);

			$query  = "CREATE TABLE Brochure_templates (    ";
			$query .= "intTempBrId int(3) NOT NULL auto_increment,";
			$query .= "strXmlTemplateUrl varchar(100) default NULL,";
			$query .= "strTemplateTitle tinytext,";
			$query .= "strTemplateDescription text NOT NULL,";
			$query .= "tmTmpStamp timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,";
			$query .= "PRIMARY KEY  USING BTREE (intTempBrId)";
			$query .= ") ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1";
			$this->mySql->query($query);
	
		}
	}
?>