<?
//@object to produce the workoreder id for the word side of the pluggin to be initiated
class WorkOrderIDCreator
{
	//@properties required by the workorder id
	public $strVendorNo = "";
	public $strPropertyId = "";
	public $strApplicantId = "";
	public $strUserId = "";
	public $strBranchId = "";
	public $strTemplate = "";
	public $strVendorSolicitorId= "";	
	public $strOutFSVendorId = "";
	public $strInFsVendorId = "";
	public $boolIncludeRooms;
	public $boolWorkOrderLive;
	public $strProgessLetterId = "";
	public $strPropertyletterId = "";
	public $strViewingLetterId = "";
	public $strPriceChangeId = "";
	public $strOfferRejectedId="";
	public $strOfferAcceptedId="";
	public $strInFSId = "";
	public $strOutFSId = "";
	public $strValuationLetterId = "";
	public $strDocType = "";
	public $strTextDescription = "";
	public $strBTMId = "";
	public $strMemoId = "";
	public $strVAddressId = "";
	public $strJVAddressId = "";
	public $strBoardId = "";	 
	
	//@get the vakues to be added to the workorder
	public function __get($name)
	{
		
		return $this->$name;
	}
	
	
	//@sets the properties for the workorder 
	public function __set($name,$value)
	{
		
		$this->$name=$value;
	}
}
?>