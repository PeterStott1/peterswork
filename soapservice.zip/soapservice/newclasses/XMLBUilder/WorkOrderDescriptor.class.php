<?php
class WorkOrderDescriptor
{
	public $strPropertyId;
	public $strVendorId;
	public $strVendorSolicitorId;	
	public $strApplicantId;
	public $strApplicantSolicitorId;	
	public $strUserId;
	public $strBranchId;
	public $strTemplate;
	public $strOutFSVendorId;
	public $strInFSVendorId;
    public $strTextDescription;
	public $strPropertyLetterId;
	public $strViewingLetterId;
	public $strProgessLetterId;
	public $strValuationLetterId;
	public $strOfferRejectedId;
	public $strOfferAcceptedId;
	public $strPriceChangeId;
	public $strInFSId;
	public $strOutFSId;
	public $boolIncludeRooms;
	public $boolWorkOrderLive;
	public $strDocType;
	public $strBTMId;
	public $strMemoID; 
	public $strVAddressId;
	public $strJVAddressId;
	public $strBoardId;

	

	public function __get($name)
	{
		return $this->$name;
	}		
	
	public function __set($name,$value)
	{	
		$this->$name=$value;
	}
}
?>