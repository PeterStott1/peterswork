<?

interface IXmlView
{
	function getXml();
	
}

?>