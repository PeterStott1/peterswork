<?php

interface IEntityObject
{
	
public function getName();
public function getProperties();
public function getImages();
	
}

	


?>