<?php
include_once("BuildWorkOrder.class.php");
include_once("WorkOrderDescriptor.class.php");
include_once('DataAccess.class.php');
include_once('EntityBase.abstract.php');
include_once('IEntityHierarchy.interface.php');
include_once('../Config.class.php');

//@ Entity classes that are reuqired by the decription engine
include_once('../systemObjects/Vendor.class.php');
include_once('../systemObjects/Room.class.php');
include_once('../systemObjects/Solicitor.class.php');
include_once('../systemObjects/Property.class.php');
include_once('../systemObjects/applicant.class.php');
include_once('../systemObjects/Appsolicitor.class.php');
include_once('../systemObjects/Branch.class.php');
include_once('../systemObjects/User.class.php');
include_once('../systemObjects/OfferAccepted.class.php');
include_once('../systemObjects/OfferRejected.class.php');
include_once('../systemObjects/PriceChange.Class.php');
//include_once('../systemObjects/OutFsVendorLetter.class.php');
//include_once('../systemObjects/InFsVendorLetter.class.php');
//include_once('../systemObjects/PropertyLetter.class.php');
//include_once('../systemObjects/ViewingLetter.class.php');
include_once('../systemObjects/ValuationLetter.class.php');
//@builds work order based on the values passed by the workorderid
class WorkOrderDescriptorEngine
{	
	private $objDataAccess;
	
	public function __construct($dataAccess)
	{
		$this->objDataAccess = $dataAccess;		
	}
	
	
	public function BuildWorkOrderFromDescriptor($workOrderDescriptor,$workOrderId)
	{
	
		$workOrderBuilder = new BuildWorkOrder($workOrderId,$workOrderDescriptor->boolWorkOrderLive,$workOrderDescriptor->strTemplate);
	
		// Build and add vendor into work order
		if (!empty($workOrderDescriptor->strVendorId))
		{
			$vendor = $this->objDataAccess->getVendor($workOrderDescriptor->strVendorId);
			$workOrderBuilder->addEntity($vendor);
						
			// Build and add vendor solicitor
			if (!empty($workOrderDescriptor->strVendorSolicitorId))
			{
				$vendorSolicitor = $this->objDataAccess->getVenSolicitor($workOrderDescriptor->strVendorSolicitorId);
				$vendor->addChild($vendorSolicitor);
			}
			else 
			{
				$vendorSolicitor = new Solicitor();
				$vendor->addChild($vendorSolicitor);
			}
			
		}
		else 
		{
			$vendor = new vendor();
			$workOrderBuilder->addEntity($vendor);
			$vendorSolicitor = new Solicitor();
			$vendor->addChild($vendorSolicitor);
			
		}		
	
		// Build and add applicant
		if (!empty($workOrderDescriptor->strApplicantId))
		{
			$applicant = $this->objDataAccess->getApplicant($workOrderDescriptor->strApplicantId);
			$workOrderBuilder->addEntity($applicant);
			
			// Build and add vendor solicitor
			if (!empty($workOrderDescriptor->strVendorSolicitorId))
			{
				$applicantSolicitor = $this->objDataAccess->getAppSolicitor($workOrderDescriptor->strApplicantSolicitorId);
				$applicant->addChild($applicantSolicitor);
			}
			{
				$applicantSolicitor = new Appsolicitor();
				$applicant->addChild($applicantSolicitor);
			}
		}
		else 
		{
			
			$applicant =new applicant();
			$workOrderBuilder->addEntity($applicant);
			$applicantSolicitor = new Appsolicitor();
			$applicant->addChild($applicantSolicitor);
			
		}
	
		// Build and add property and optionally rooms
		if (!empty($workOrderDescriptor->strPropertyId))
		{
			$property = $this->objDataAccess-> getProperty($workOrderDescriptor->strPropertyId);
			$workOrderBuilder->addEntity($property);
			
			if ($workOrderDescriptor->boolIncludeRooms)
			{
				// this is the bit where we get the rooms!
				$arrayRoom = $this->objDataAccess->getRooms($workOrderDescriptor->strPropertyId);
				
				foreach($arrayRoom as $room)
				{
					$property->addChild($room);	
				}			
			}		
		}
		else 
		{
			$property = new property();
			$workOrderBuilder->addEntity($property);
			$room = new room();
			$workOrderBuilder->addEntity($room);
			
		}
		
	
		// Build and add branch
		if (!empty($workOrderDescriptor->strBranchId))
		{
			$branch = $this->objDataAccess->getBranch($workOrderDescriptor->strBranchId);
			$workOrderBuilder->addEntity($branch);
		}
		else 
		{	
			$branch = new Branch();
			$workOrderBuilder->addEntity($branch);
		}
		// Build and add user
		if (!empty($workOrderDescriptor->strUserId))
		{
			$user = $this->objDataAccess->getUser($workOrderDescriptor->strUserId);
			$workOrderBuilder->addEntity($user);
		}
		else 
		{
			$user = new User();
			$workOrderBuilder->addEntity($user);
		}
			// Build and add OutFSvendor into work order
//		if (!empty($workOrderDescriptor->strOutFSVendorId))
//		{
//			$OutFSVendor = $this->objDataAccess->getOutFsVendor($workOrderDescriptor->strOutFSVendorId);
//			$workOrderBuilder->addEntity($OutFSVendor);
//			
//			
//		}	
//		if (!empty($workOrderDescriptor->strInFSVendorId))
//		{
//			$InFSVendor = $this->objDataAccess->GetInFsVendorLetter($workOrderDescriptor->strInFSVendorId);
//			$workOrderBuilder->addEntity($InFSVendor);
//			
//			
//		}
		if(!empty($workOrderDescriptor->strPriceChangeId))
		{
			$prchange = $this->objDataAccess->getPrChange($workOrderDescriptor->strPriceChangeId);
			$workOrderBuilder->addEntity($prchange);
			
		}	
		else 
		{
			$prchange = new PriceChange();
			$workOrderBuilder->addEntity($prchange);
			
		}
		if(!empty($workOrderDescriptor->strOfferAcceptedId))
		{
			$OfferAcc = $this->objDataAccess->getOfferAcc($workOrderDescriptor->strOfferAcceptedId);
			$workOrderBuilder->addEntity($OfferAcc);
			
		}
		else 
		{
			$OfferAcc = new OfferAccepted();
			$workOrderBuilder->addEntity($OfferAcc);
		}
		if(!empty($workOrderDescriptor->strOfferRejectedId))
		{
			$OfferRej = $this->objDataAccess->getOfferRej($workOrderDescriptor->strOfferRejectedId);
			$workOrderBuilder->addEntity($OfferRej);
		}
		else 
		{
			$OfferRej = new OfferRejected();
			$workOrderBuilder->addEntity($OfferRej);
		}
		if(!empty($workOrderDescriptor->strValuationLetterId))
		{
			$valLetter = $this->objDataAccess->getValuationLetter($workOrderDescriptor->strValuationLetterId);
			$workOrderBuilder->addEntity($valLetter);
		}
		//@return workorderbuilder
		return $workOrderBuilder;
	}
	
}