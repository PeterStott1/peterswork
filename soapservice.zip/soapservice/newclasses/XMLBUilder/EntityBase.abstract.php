<?php
include('IEntityHierarchy.interface.php');
abstract class EntityBase implements IEntityHierarchy 
{
	private $ChildArray = array();
	
	
	public function addChild($ObjChild)
	{
		array_push($this->ChildArray,$ObjChild);
	}
	//@this is here because it is not must entities or in the xml heirrachy
	public function getImages()
	{
		
		return array();	
	}
	public function getChildren()
	{
		return $this->ChildArray;	
	}
	
	public function __get($name)
	{
		return $this->$name;
		
	}
	public function __set($name,$value)
	{
		$this->$name=$value;
		
	}
}

?>