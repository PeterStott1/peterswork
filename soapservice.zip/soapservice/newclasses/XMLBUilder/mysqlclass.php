<?
// define 'MySQL' class

include_once("resultclass.php");

class MySQL{

    private $host;
    private $user;
    private $password;
    private $database;
    private $connId;



    // constructor
    public function __construct($options=array())
    {
        if(!is_array($options)){
            throw new Exception('Connection options must be an array');
        }
        foreach($options as $option=>$value)
        {
            if(empty($option))
            {
                throw new Exception('Connection parameter cannot be empty');
            }
            $this->{$option}=$value;
        }
        $this->connectDb();
    }
    // private 'connectDb()' method
    private function connectDb()
    {
        if(!$this->connId=mysql_connect($this->host,$this->user,$this->password))
        {
            throw new Exception('Error connecting to MySQL');
        }
        if(!mysql_select_db($this->database,$this->connId))
        {
            throw new Exception('Error selecting database');
        }
    }
//**Function: fetchArray,Purpose:get  array of query results**
		public function fetchArray($result)
		{
			return mysql_fetch_array($result);
		}
    // public 'query()' method
    public function query($sql){
        if(!$result=mysql_query($sql))
        {
            throw new Exception('Error running query '.$sql.''.mysql_error());
        }
        return new Result($this,$result);
    }
    public function closeConnection()	{
		return(mysql_close( $this->connId ));
	}
}
?>