<?

interface IEntityHierarchy 
{
	function addChild($ObjChild);
	function getChildren();
	
}

?>