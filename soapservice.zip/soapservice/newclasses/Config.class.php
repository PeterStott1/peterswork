<?php
//@@return this is a one point of access configuration class built to allow database connection that
//@@return that is used to connect to the database across the solution
include_once('XMLBUilder/DataAccess.class.php');
include_once('XMLBUilder/mysqlclass.php');
//@@configuration file requires a static function not to be changed unless you 
//@@return need it to be added it to a new web site
class Config
{
	
	public static $ImageDirectory = "../../../propphoto/";
	public static $TemplateDirectory= "../data/";
	public static $staffSignUrl = "../../../branch/";
	public static $staffPhotoUrl = "../../../branch/";
	private static $InternalServiceUrl;
	private static $boolDevMode=false;
	
	 
	//@@pertaining to the object only!!!!!!!!
	protected static $ServiceSubUrl = "soapservice/newclasses/service/";
	protected static $devServiceUrl = "http://192.168.13.240/wordplugin_dev/testproject3/newclasses/service/";
	
	
	public static function CreateDbConn()
	{
	if(Config::$boolDevMode==true)
		{
				$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3-demo'));
				return $db;
		}
		else 
		{
			$db=new MySQL(array('host'=>'localhost','user'=>'root','password'=>'Jac%kEl10','database'=>'cresidential'));
			//$db=new MySQL(array('host'=>'192.168.13.240','user'=>'root','password'=>'letmein','database'=>'ep3-demo'));
			//$db=new MySQL(array('host'=>'192.168.1.210','user'=>'SoapAdmin','password'=>'Server1','database'=>'ep3-demo'));
			return $db;
		} 
	}

	public static function ServiceUrl()
	{
			if(empty($InternalServiceUrl))
			{
				if(Config::$boolDevMode==true)
					$InternalServiceUrl=Config::$devServiceUrl;
				else 
					$InternalServiceUrl= Config::fetchServiceUrl();
			}	
			
			return($InternalServiceUrl);
		
	}
	
	
	
	
	private static function fetchServiceUrl()
	{
		$db = Config::CreateDbConn();
		$dataAcc = new DataAccess($db);
		//$path = "http://89.234.36.211/";
		$path = $dataAcc->getSiteBaseUrl();
		$path .= Config::$ServiceSubUrl;
		return $path;
	}
	
	
}

?>