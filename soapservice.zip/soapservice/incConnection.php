<?
$connection=mysql_connect("http://89.234.36.210", "peter", "stotti1")
   or die("Could not connect : " . mysql_error());
   $databasename= "ep3-demo";
mysql_select_db($databasename) or die("Could not select database");
echo "your in";
?>
