﻿namespace SpaceInvaders
{
    partial class Form1
    {
        
        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
       

        #endregion
    }
}

