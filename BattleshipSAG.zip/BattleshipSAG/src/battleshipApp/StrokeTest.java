/*
 * StrokeTest.java
 *
 * Created on 03 December 2005, 16:08
 */

/**
 *
 * @author  peters
 * @version 
 */
import java.applet.*;
import java.awt.*;
import java.awt.geom.*;

public class StrokeTest extends Applet {

    public void paint(Graphics g)
    {
        Graphics2D g2d = (Graphics2D)g;
        
        float penWidth = 3.0f;
        
        int endCaps = BasicStroke.CAP_BUTT;
        int liteJoins =BasicStroke.JOIN_MITER;
        
        float trim = 10.0f;
        
        float[] dashPattern = {5.0f, 9.09f, 3.0f };
        
        float dashOffset = 0.0f;
        
        BasicStroke stroke = new BasicStroke(penWidth, endCaps, liteJoins,
        trim, dashPattern, dashOffset);
        
        g2d.setStroke(stroke);
        
        g2d.draw(new Line2D.Float(10.0f,10.0f, 140.0f, 10.0f));
        g2d.draw(new Rectangle2D.Float(20.0f, 60.0f, 100.0f, 50.0f));
    }
  

}//StrokeTest
